<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>Uab League</title>
  <meta content="width=device-width, initial-scale=1.0" name="viewport">
  <meta content="" name="keywords">
  <meta content="" name="description">

  <!-- Favicons -->
  <link href="img/favicon.png" rel="icon">


  <!-- Bootstrap CSS File -->
  <link href="<?php echo base_url('design/lib/bootstrap/css/bootstrap.min.css'); ?>" rel="stylesheet">

  <!-- Libraries CSS Files -->

  <link href="<?php echo base_url('design/lib/font-awesome/font-awesome.min.css'); ?>" rel="stylesheet">
  <link href="<?php echo base_url('design/lib/animate/animate.css'); ?>" rel="stylesheet">

  
  
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.2/css/all.css" integrity="sha384-fnmOCqbTlWIlj8LyTjo7mOUStjsKC4pOpQbqyi7RrhN7udi9RwhKkMHpvLbHG9Sr" crossorigin="anonymous">	


  <!-- Main Stylesheet File -->
  <link href="<?php echo base_url('design/css/style.css'); ?>" rel="stylesheet">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>

<script type="text/javascript">
  var SITE_URL = "<?php echo base_url(''); ?>" ;
</script>  

</head>

<body>