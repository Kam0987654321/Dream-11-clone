<script type="text/javascript">

</script>
      <style>:root{COMMENT:// DEPRECATED: Use jssVariables instead;--color:#323232;--primary-bg-color:#c51d23;--primary-fg-color:#FFF;--primary-selected-bg-color:#ab1a1f;--secondary-fg-color:#888;--button-height:48px;--icon-color:var(--color);--primary-btn-color:#3759a5;--secondary-btn-color:#3759a5;--box-shadow-light:0px 1px 4px 0px rgba(0, 0, 0, 0.2);--box-shadow-dark:0 1px 2px 0 rgba(0, 0, 0, 0.3);--large-button-height:50px;--icon-size:24px;--font-x-small:10px;--font-small:12px;--font-medium:14px;--font-large:24px;--currency-font-color:inherit}</style>

      <style id="app-style">.appContainer_6475d{max-width:550px;height:100%}.appBgImage_fd065{position:fixed;left:550px;right:0;background-size:cover;top:0;bottom:0}.loaderContainer_d2930{display:flex;height:100%;align-items:center}.blockLoader_580b6{margin:12px auto}.loaderCircular_00f73{animation:loader-rotate 2s linear infinite}.loaderPath_00e5f{animation:loader-stroke 1.5s ease-in-out infinite;stroke-dasharray:1, 162;stroke-dashoffset:0;stroke-linecap:round;stroke-width:6}.black_7fbc4{stroke:rgba(0, 0, 0, 0.5)}.fadeIn_73e97{animation:fade-in .25s linear}.contestHome_789e2{padding-top:100px;padding-bottom:50px;background-color:#efeff4;min-height:100%}.headerContainer_199c8{background-color:#c51d23;color:#FFF;z-index:2}.headerFixed_38df7{position:fixed;top:0;max-width:550px;width:100%}.headerRow_c14ad{display:flex;justify-content:space-between;height:50px}.headerLeft_36c4e{display:flex;flex:1 0 0;justify-content:flex-start;align-items:center}.headerCenter_4d6f0{display:flex;flex:1 0 0;justify-content:center;align-items:center}.headerTitle_fd62d{text-transform:uppercase;white-space:nowrap}.headerRight_ba2d2{display:flex;flex:1 0 0;justify-content:flex-end;align-items:center}.infobar_0dc07{background-color:#c51d23;height:50px;padding:8px}.infobarContent_628aa{background-color:#FFF;height:100%;color:#323232;border-radius:2px;display:flex;justify-content:center;align-items:center;padding:8px}.contestsHeader_16599{padding:12px;border-bottom:1px solid #dcdcdc}.playWithFriendsWrapper_3442c{display:flex;justify-content:space-between}.contestCountInfo_cc447{padding-top:16px;color:#969696}.segmentHeaderContainer_54896{position:sticky;top:100px;display:flex;background-color:#efeff4;z-index:1;align-items:center;justify-content:space-between;padding:0 12px}.row_404ce{align-items:center;display:flex;height:60px;text-decoration:none;color:#7b7a7a}.segmentHeaderShell_a64fc{display:flex;height:100%;flex-direction:column;justify-content:space-evenly}.headerTitle_ba6eb{color:#333232;font-weight:bold;font-size:16px}.headerText_d7966{font-size:12px;margin-top:2px}.contestCardWrapper_c83dd{border-radius:4px;display:block;margin:0 12px 16px 12px;box-shadow:0 1px 3px 0 rgba(0, 0, 0, 0.1), 0 4px 6px 0 rgba(0, 0, 0, 0.05);background-color:#fff;text-decoration:none}.contestSpecMoneyInfo_20124{width:100%;display:flex;flex-direction:column;padding:12px}.contestSpecRow_01429{display:flex;justify-content:space-between;align-items:center;padding-bottom:8px}.contestCardLabel_7ca40{font-size:12px;color:#969696}.prizePool_565d2{font-size:20px;font-weight:500;color:#282828}.contestProgressBarContainer_0efc1{padding:0 12px}.contestProgressBar_eba45{height:8px;display:flex;justify-content:flex-end;transform:skew(-20deg);background-image:linear-gradient(to right, #ffc81e, #e10000)}.contestProgressInner_ead13{background-color:#f2f2f2;height:8px}.idleProgressBar_3ec17{width:100%}.spotsContainer_9c427{padding:8px 12px 0 12px}.spotLefts_8d583{font-size:12px;font-weight:500}.totalSpots_b62ba{color:#969696;font-size:12px;font-weight:500}.contestSpec_a3ebb{background-color:#f8f8f8;border-top:1px solid #f4f4f4;padding:12px;font-size:12px;height:32px;display:flex;border-radius:0 0 4px 4px;align-items:center}.iconLabelGroup_f55e1{display:inline-flex;width:50%}.container_607ce{background-color:#3759a5;bottom:0;position:fixed;width:100%;max-width:550px;z-index:3;animation:contest-footer-animate-in 300ms cubic-bezier(0, 0, 0, 1)}.infobarContentRow_7ae93{display:flex;width:100%;font-size:12px}.infobarContentLeft_04a34{flex:1 0 0}.infobarContentCenter_5f791{flex:1 0 0;text-align:center}.timer_1aa54{font-family:monospace;display:flex;justify-content:center;align-items:center;color:#c51d23}.materialIcon_10a4f{font-family:Material Icons;font-weight:normal;font-style:normal;display:inline-block;line-height:1;text-transform:none;letter-spacing:normal;word-wrap:normal;white-space:nowrap;direction:ltr}.timeRemaining_96d65{margin-left:4px}.timer_defb2{color:#c61c23;font-family:monospace}.infobarContentRight_ac9bd{flex:1 0 0;text-align:right}.floatingAnchorButton_fac02{font-weight:600;text-decoration:none;color:#3759a5}.innerContainer_b8f9b{padding:8px}.raisedWhiteButtonNew_08689{background:none;border:0;cursor:pointer;margin:0;text-decoration:none;text-align:center;font-family:inherit;display:flex;justify-content:center;align-items:center;color:inherit;font-weight:500;font-size:12px;height:32px;padding:0 8px;width:156px;border-radius:4px;background-color:#fff;box-shadow:0 1px 3px 0 rgba(0, 0, 0, 0.1), 0 4px 6px 0 rgba(0, 0, 0, 0.05)}.iconLabel_fe3d5{display:flex;align-item:center;justify-content:space-between;font-size:12px;width:100%}.iconContent_3cbfd{padding-left:4px}.flatGreenButton_fb7a7{background:none;border:0;cursor:pointer;margin:0;text-decoration:none;text-align:center;font-family:inherit;display:flex;justify-content:center;align-items:center;color:#fff;font-weight:500;font-size:12px;height:28px;padding:0 8px;width:76px;border-radius:4px;background-color:#00b137}.contestFilling_14509{color:#ffa01e}.iconLabelWrapper_43690{display:flex;justify-content:space-between;color:#969696}.squareWithTwoRoundCorner_1291a{width:20px;height:20px;padding:2px;font-size:12px;color:#969696;border:1px solid #969696;border-radius:2px 0 2px 0;display:flex;justify-content:center}.moreLink_570df{color:#00a0ff;justify-content:space-between;align-items:center;text-decoration:none;height:35px}.flexRow_029e0{display:flex}.allContestsButtonSegment_d9602{padding:10px 0;display:flex;flex-direction:column;align-items:center}.allContestsButtonSegmentHeader_a44f9{margin-bottom:16px;line-height:1.5}.headerContainer_1725f{background:linear-gradient(104deg, #3c3c3c 47%, #323232 47%);display:flex;flex-direction:column;z-index:2}.defaultHeaderContent_00a63{display:flex;justify-content:space-between;color:#FFF;height:48px}.headerRight_d1c5d{display:flex;flex:1 0 0;justify-content:flex-end;align-items:center;margin-right:12px}.guruIcon_0a307{height:24px;width:24px;margin-right:12px}.container_aa549{display:flex;flex-direction:column;height:136px}.maxInfoText_13e5b{font-size:12px;color:#fff;display:flex;align-self:center;margin-bottom:12px}.infoContent_0b612{display:flex;justify-content:space-around}.playerSelectionContainerLoader_68e5b{display:flex;flex-direction:column;justify-content:space-evenly}.flagContainer_029e0{display:flex}.squadOneText_3ad2c{display:flex;flex-direction:column;color:#acacac;margin-left:4px}.squadTwoText_b9766{display:flex;flex-direction:column;color:#acacac;margin-left:4px;align-items:flex-end;margin-right:4px}.infoLoaderProgressContainer_51138{display:flex;justify-content:center;margin:24px 16px 16px}.mainWrapper_8542d{background:#fafafa;padding-bottom:90px;overflow-y:hidden}.tabsMainContainer_a916e{background:#fff;position:fixed;top:184px;z-index:2;max-width:550px;width:100%}.tabsWrapper_43944{max-width:550px;overflow-x:hidden}.createTeamTabsContainer_5ba85{display:flex;flex:1 0 0;justify-content:center;cursor:pointer}.roleTabItem_603ae{height:48px;display:flex;align-items:center;justify-content:center;width:100%;color:#9c9c9c;letter-spacing:1px}.createTeamTabsHelpContainer_ce9c9{height:44px;display:flex;align-items:center;color:#000;justify-content:center;background-color:#efeff4}.ctSortingHeader_a6515{display:flex;height:36px;color:#acacac;font-size:12px;border-bottom:1px solid #e8e8e8;padding-left:16px}.playerCardCell_bf9d8{display:flex;align-items:center;white-space:nowrap;text-overflow:ellipsis;overflow:hidden}.playerCardAvatarCell_2b8d1{flex:0 0 60px}.playerCardInfoCell_ba412{display:flex;flex-grow:1}.playerCardNameCell_50086{flex-grow:3;flex-basis:80px}.playerPointsCell_aa0e3{flex-grow:1;flex-basis:60px;justify-content:center}.activeSortKey_c7202{color:#000}.sortingHeaderIconPlaceHolder_43273{display:flex;flex-basis:70px}.playerListContainer_e09a1{margin-top:312px;overflow-y:scroll}.playerCard_42b9d{background-color:#fff;display:flex;height:72px;padding-left:16px;transition:background-color 300ms cubic-bezier(0, 2, 1, 1)}.playerCardInfoContainer_d41f9{border-bottom:1px solid #e8e8e8}.playerCardIconContainer_65be8{display:flex;flex-basis:70px;justify-content:center;margin:10px 0;border-left:1px solid #e8e8e8}.footer_d9cd3{height:40px;position:fixed;margin-bottom:16px;width:100%;max-width:550px;z-index:3;bottom:0px}.footerButtonContainer_b9ae4{display:flex;justify-content:center}.disabledButton_cf79e{opacity:0.5;cursor:not-allowed}.raisedGreenButton_20c05{background:#25ba38;border:0;cursor:pointer;margin:0;text-decoration:none;text-align:center;font-family:inherit;display:flex;justify-content:center;align-items:center;color:#fff;font-weight:500;font-size:12px;height:32px;padding:8px 8px;text-transform:uppercase;width:120px;border-radius:4px;box-shadow:0 4px 8px 0 rgba(0, 0, 0, 0.2);}.raisedGreenButtonDisabled_e0a23{background:#dcdcdc;color:#969696;opacity:1}.timer_3d48d{color:#fff}.helpLink_4c95c{display:flex;justify-content:center;align-items:center;height:24px;width:24px;border:solid 1px #acacac;border-radius:50%;color:#acacac}.playerSelectionContainer_d8646{display:flex;flex-direction:column;color:#acacac;font-size:12px;margin-left:16px}.squadTextContainer_3e550{display:flex;font-size:12px}.selectedCount_daee8{font-size:24px;color:#fff}.totalCount_c1f66{padding-top:10px}.flagContainer_47acd{display:flex;align-items:center;justify-content:space-around;margin:0 4px}.flag_008b5{width:44px;height:44px;border-radius:50%}.teamName_a2024{font-size:12px}.teamCount_84ce0{font-size:16px;color:#fff;margin-top:4px}.creditsContainer_e7f97{display:flex;flex-direction:column;color:#acacac;font-size:12px;margin-right:16px}.creditsText_a4625{color:#fff;font-size:24px;display:flex;justify-content:flex-end}.progressContainer_00657{margin:24px 16px 16px}.stepperContainer_b9ae4{display:flex;justify-content:center}.stepperBlock_8b62f{width:36px;height:16px;font-size:12px;transform:skew(-20deg);border:1px solid #323232;display:flex;justify-content:center;align-items:center}.inactiveStepper_4d390{background-color:#fff}.lastStepper_2bce1{font-size:12px;color:#000;transform:skew(20deg)}.roleTabWrapper_a3522{display:block;width:100%}.createTeamTabTitle_99a5a{display:flex;justify-content:center;font-weight:600;font-size:16px}.createTeamTabsCount_19658{display:flex;align-items:center;justify-content:center;font-size:12px}.roleTabHighlight_ee4c9{transform:skew(-20deg);height:4px;width:100%}.roleTabHighlightActive_28bb8{background-color:#c51d23}.roleTabHighlightInactive_4d390{background-color:#fff}.imageContainer_029e0{display:flex}.playerImageProfile_43b1b{height:48px;width:48px}.playerImageContainer_6e52e{display:flex;flex-direction:column;overflow:hidden;height:100%;width:100%}.playerImage_f320d{width:100%;flex:1;background-size:cover;background-repeat:no-repeat;border-radius:50%;background-color:#969696}.playerName_73cad{flex-basis:44px;justify-content:center;color:#00a0ff}.playerTeamTitle_a2024{font-size:12px}.playerCardIcon_b8a19{border-radius:50%;color:#24ba38;align-self:center;border:1px solid}.desktopTeamPreviewContainer_61fb1{position:fixed;left:550px;width:550px;height:100%;top:0;max-width:550px}.content_60710{background-repeat:no-repeat;background-size:cover;background-position:center;min-height:100%;display:flex;flex-direction:column;height:100%}.toolbar_650b2{width:100%;background-color:transparent;flex:0;position:fixed;height:48px;z-index:2;max-width:550px}.toolbarElementMain_7948b{flex:1;display:flex}.toolbarElementLeft_19260{justify-content:flex-start;color:#fff;padding:8px}.toolbarElementRight_c98d9{justify-content:flex-end}.toolbarElementIcon_3d48d{color:#fff}.playerArea_eac11{position:relative;height:100%;overflow:scroll}.emptyStateWrapper_1b95a{display:flex;align-items:center;flex-direction:column;padding:8px;background:#00000059;border-radius:4px;position:absolute;left:50%;top:50%;transform:translate(-50%, -50%)}.emptyStateText_2c68c{padding:8px;color:#fff;font-weight:bold;white-space:nowrap}.joinedContest_e8f66{padding-top:112px;min-height:100%;background-color:#efeff4}.headerShadow_22469{box-shadow:0px 1px 4px 0px rgba(0, 0, 0, 0.3)}.sharingBox_d2571{padding:8px 16px;display:flex;justify-content:space-between;color:#969696;background-color:#f8f8f8;font-size:14px;font-weight:normal;align-items:center;border-bottom:1px solid #f4f4f4}.noContestJoined_1d9ed{margin:16px 0}.leaderboard_c97e9{padding-top:100px}.dialog_fe4fb{max-width:550px;z-index:7}.loadingDialog_7ce16{display:flex;align-items:center}.loader_fdaf1{margin-right:12px}.spaceAround_64779{justify-content:space-around}.tall_56497{position:absolute;top:0;left:0;min-height:100%;width:100%;display:flex;flex-direction:column;justify-content:space-evenly;padding:24px 0 60px 0}.teamPreviewRowWrapper_0c54c{width:100%;padding-top:8px}.rowTitle_b91f3{margin-bottom:4px;text-align:center;color:#fff;text-transform:uppercase;font-size:var(--font-small);opacity:0.52}.rowContent_8aa5f{display:flex;justify-content:space-evenly;align-items:center;padding:8px 0;height:85px}.fieldPlayerMain_32975{display:flex;flex-direction:column;align-items:center}.playerImageProfile_0cc1f{height:38px;width:38px;border-radius:10px 0;position:relative}.imageProfileContainer_6e52e{display:flex;flex-direction:column;overflow:hidden;height:100%;width:100%}.fieldPlayerTitle_4ac32{width:65px;overflow:hidden;text-overflow:ellipsis;color:#fff;text-align:center;font-size:var(--font-small);white-space:nowrap;box-shadow:0 2px 2px 0 rgba(0, 0, 0, 0.25);border-radius:2px;padding:0 4px}.playerPoints_d4e06{white-space:nowrap;color:#fff;text-align:center;padding:2px;font-size:var(--font-small)}.activeStepper_2007e{background-color:#00a037}.activeNumber_89478{font-size:12px;color:#fff;transform:skew(20deg)}.playerCardSelected_ae508{background-color:#fff7ec}.playerCardIconSelected_4b666{color:#ffa500}.playerCardDisable_84b1d{opacity:0.5}.playerCardIconDisabled_a0371{color:#888}.wrapper_de051{max-width:550px;z-index:8}.message_d58fc{color:#fff;padding:36px 8px 0px 8px;text-align:center}.error_a70e4{background-color:#f68323}.lastStepperActive_3d48d{color:#fff}</style>



      <style type="text/css">.fb_hidden{position:absolute;top:-10000px;z-index:10001}.fb_reposition{overflow:hidden;position:relative}.fb_invisible{display:none}.fb_reset{background:none;border:0;border-spacing:0;color:#000;cursor:auto;direction:ltr;font-family:"lucida grande", tahoma, verdana, arial, sans-serif;font-size:11px;font-style:normal;font-variant:normal;font-weight:normal;letter-spacing:normal;line-height:1;margin:0;overflow:visible;padding:0;text-align:left;text-decoration:none;text-indent:0;text-shadow:none;text-transform:none;visibility:visible;white-space:normal;word-spacing:normal}.fb_reset>div{overflow:hidden}@keyframes fb_transform{from{opacity:0;transform:scale(.95)}to{opacity:1;transform:scale(1)}}.fb_animate{animation:fb_transform .3s forwards}

         .fb_dialog{background:rgba(82, 82, 82, .7);position:absolute;top:-10000px;z-index:10001}.fb_dialog_advanced{border-radius:8px;padding:10px}.fb_dialog_content{background:#fff;color:#373737}.fb_dialog_close_icon{background:url(https://static.xx.fbcdn.net/rsrc.php/v3/yq/r/IE9JII6Z1Ys.png) no-repeat scroll 0 0 transparent;cursor:pointer;display:block;height:15px;position:absolute;right:18px;top:17px;width:15px}.fb_dialog_mobile .fb_dialog_close_icon{left:5px;right:auto;top:5px}.fb_dialog_padding{background-color:transparent;position:absolute;width:1px;z-index:-1}.fb_dialog_close_icon:hover{background:url(https://static.xx.fbcdn.net/rsrc.php/v3/yq/r/IE9JII6Z1Ys.png) no-repeat scroll 0 -15px transparent}.fb_dialog_close_icon:active{background:url(https://static.xx.fbcdn.net/rsrc.php/v3/yq/r/IE9JII6Z1Ys.png) no-repeat scroll 0 -30px transparent}.fb_dialog_iframe{line-height:0}.fb_dialog_content .dialog_title{background:#6d84b4;border:1px solid #365899;color:#fff;font-size:14px;font-weight:bold;margin:0}.fb_dialog_content .dialog_title>span{background:url(https://static.xx.fbcdn.net/rsrc.php/v3/yd/r/Cou7n-nqK52.gif) no-repeat 5px 50%;float:left;padding:5px 0 7px 26px}body.fb_hidden{height:100%;left:0;margin:0;overflow:visible;position:absolute;top:-10000px;transform:none;width:100%}.fb_dialog.fb_dialog_mobile.loading{background:url(https://static.xx.fbcdn.net/rsrc.php/v3/ya/r/3rhSv5V8j3o.gif) white no-repeat 50% 50%;min-height:100%;min-width:100%;overflow:hidden;position:absolute;top:0;z-index:10001}.fb_dialog.fb_dialog_mobile.loading.centered{background:none;height:auto;min-height:initial;min-width:initial;width:auto}.fb_dialog.fb_dialog_mobile.loading.centered #fb_dialog_loader_spinner{width:100%}.fb_dialog.fb_dialog_mobile.loading.centered .fb_dialog_content{background:none}.loading.centered #fb_dialog_loader_close{clear:both;color:#fff;display:block;font-size:18px;padding-top:20px}#fb-root #fb_dialog_ipad_overlay{background:rgba(0, 0, 0, .4);bottom:0;left:0;min-height:100%;position:absolute;right:0;top:0;width:100%;z-index:10000}#fb-root #fb_dialog_ipad_overlay.hidden{display:none}.fb_dialog.fb_dialog_mobile.loading iframe{visibility:hidden}.fb_dialog_mobile .fb_dialog_iframe{position:sticky;top:0}.fb_dialog_content .dialog_header{background:linear-gradient(from(#738aba), to(#2c4987));border-bottom:1px solid;border-color:#1d3c78;box-shadow:white 0 1px 1px -1px inset;color:#fff;font:bold 14px Helvetica, sans-serif;text-overflow:ellipsis;text-shadow:rgba(0, 30, 84, .296875) 0 -1px 0;vertical-align:middle;white-space:nowrap}.fb_dialog_content .dialog_header table{height:43px;width:100%}.fb_dialog_content .dialog_header td.header_left{font-size:12px;padding-left:5px;vertical-align:middle;width:60px}.fb_dialog_content .dialog_header td.header_right{font-size:12px;padding-right:5px;vertical-align:middle;width:60px}.fb_dialog_content .touchable_button{background:linear-gradient(from(#4267B2), to(#2a4887));background-clip:padding-box;border:1px solid #29487d;border-radius:3px;display:inline-block;line-height:18px;margin-top:3px;max-width:85px;padding:4px 12px;position:relative}.fb_dialog_content .dialog_header .touchable_button input{background:none;border:none;color:#fff;font:bold 12px Helvetica, sans-serif;margin:2px -12px;padding:2px 6px 3px 6px;text-shadow:rgba(0, 30, 84, .296875) 0 -1px 0}.fb_dialog_content .dialog_header .header_center{color:#fff;font-size:16px;font-weight:bold;line-height:18px;text-align:center;vertical-align:middle}.fb_dialog_content .dialog_content{background:url(https://static.xx.fbcdn.net/rsrc.php/v3/y9/r/jKEcVPZFk-2.gif) no-repeat 50% 50%;border:1px solid #4a4a4a;border-bottom:0;border-top:0;height:150px}.fb_dialog_content .dialog_footer{background:#f5f6f7;border:1px solid #4a4a4a;border-top-color:#ccc;height:40px}#fb_dialog_loader_close{float:left}.fb_dialog.fb_dialog_mobile .fb_dialog_close_button{text-shadow:rgba(0, 30, 84, .296875) 0 -1px 0}.fb_dialog.fb_dialog_mobile .fb_dialog_close_icon{visibility:hidden}#fb_dialog_loader_spinner{animation:rotateSpinner 1.2s linear infinite;background-color:transparent;background-image:url(https://static.xx.fbcdn.net/rsrc.php/v3/yD/r/t-wz8gw1xG1.png);background-position:50% 50%;background-repeat:no-repeat;height:24px;width:24px}@keyframes rotateSpinner{0%{transform:rotate(0deg)}100%{transform:rotate(360deg)}}

         .fb_iframe_widget{display:inline-block;position:relative}.fb_iframe_widget span{display:inline-block;position:relative;text-align:justify}.fb_iframe_widget iframe{position:absolute}.fb_iframe_widget_fluid_desktop,.fb_iframe_widget_fluid_desktop span,.fb_iframe_widget_fluid_desktop iframe{max-width:100%}.fb_iframe_widget_fluid_desktop iframe{min-width:220px;position:relative}.fb_iframe_widget_lift{z-index:1}.fb_iframe_widget_fluid{display:inline}.fb_iframe_widget_fluid span{width:100%}

         .fb_customer_chat_bounce_in_v2{animation-duration:300ms;animation-name:fb_bounce_in_v2;transition-timing-function:ease-in}.fb_customer_chat_bounce_out_v2{animation-duration:300ms;animation-name:fb_bounce_out_v2;transition-timing-function:ease-in}.fb_customer_chat_bounce_in_v2_mobile_chat_started{animation-duration:300ms;animation-name:fb_bounce_in_v2_mobile_chat_started;transition-timing-function:ease-in}.fb_customer_chat_bounce_out_v2_mobile_chat_started{animation-duration:300ms;animation-name:fb_bounce_out_v2_mobile_chat_started;transition-timing-function:ease-in}.fb_customer_chat_bubble_pop_in{animation-duration:250ms;animation-name:fb_customer_chat_bubble_bounce_in_animation}.fb_customer_chat_bubble_animated_no_badge{box-shadow:0 3px 12px rgba(0, 0, 0, .15);transition:box-shadow 150ms linear}.fb_customer_chat_bubble_animated_no_badge:hover{box-shadow:0 5px 24px rgba(0, 0, 0, .3)}.fb_customer_chat_bubble_animated_with_badge{box-shadow:-5px 4px 14px rgba(0, 0, 0, .15);transition:box-shadow 150ms linear}.fb_customer_chat_bubble_animated_with_badge:hover{box-shadow:-5px 8px 24px rgba(0, 0, 0, .2)}.fb_invisible_flow{display:inherit;height:0;overflow-x:hidden;width:0}.fb_mobile_overlay_active{background-color:#fff;height:100%;overflow:hidden;position:fixed;visibility:hidden;width:100%}@keyframes fb_bounce_in_v2{0%{opacity:0;transform:scale(0, 0);transform-origin:bottom right}50%{transform:scale(1.03, 1.03);transform-origin:bottom right}100%{opacity:1;transform:scale(1, 1);transform-origin:bottom right}}@keyframes fb_bounce_in_v2_mobile_chat_started{0%{opacity:0;top:20px}100%{opacity:1;top:0}}@keyframes fb_bounce_out_v2{0%{opacity:1;transform:scale(1, 1);transform-origin:bottom right}100%{opacity:0;transform:scale(0, 0);transform-origin:bottom right}}@keyframes fb_bounce_out_v2_mobile_chat_started{0%{opacity:1;top:0}100%{opacity:0;top:20px}}@keyframes fb_customer_chat_bubble_bounce_in_animation{0%{bottom:6pt;opacity:0;transform:scale(0, 0);transform-origin:center}70%{bottom:18pt;opacity:1;transform:scale(1.2, 1.2)}100%{transform:scale(1, 1)}}

      </style>

     

      <style type="text/css" id="qual_style-mzj"></style>

      <style type="text/css" id="qual_style-meu"></style>     

      <div>

         <div class="app-container appContainer_6475d">

            <div class="appBgImage_fd065"></div>

            <div class="lazy-container-create-team">

               <div class="lazy-create-team">

                  <div class="create-team">

                     <div class="js--desktop-team-preview">

                        <div class="team-preview-page js--team-preview desktopTeamPreviewContainer_61fb1">

                           <div class="content_60710" style="background-image: url('<?php echo base_url('uploads/ground.png');?>');">

                              <div>

                                 <div class="toolbar_650b2">

                                    <div class="align-center">

                                       <div class="toolbarElementMain_7948b toolbarElementLeft_19260">

                                          <div class="toolbar-title"></div>

                                       </div>

                                       <div></div>

                                       <div class="toolbarElementMain_7948b toolbarElementRight_c98d9 toolbarElementIcon_3d48d"></div>

                                    </div>

                                 </div>

                              </div>

                              <div class="playerArea_eac11">

                                 <div>



                                    <div class="spaceAround_64779 tall_56497">

                                          <div class="emptyStateWrapper_1b95a" id="no_players" style="display:block;"><div class="emptyStateText_2c68c">No Players Selected yet</div></div>
                                      <div id="show_teams" style="display:none;">
                                       <div class="teamPreviewRowWrapper_0c54c ">

                                          <div class="rowTitle_b91f3">Wicket-Keeper</div>

                                          <div class="spaceAround_64779 rowContent_8aa5f" id="WkTeamPreview">

                                             

                                          </div>

                                       </div>

                                       <div class="teamPreviewRowWrapper_0c54c">

                                          <div class="rowTitle_b91f3">Batsmen</div>

                                          <div class="spaceAround_64779 rowContent_8aa5f" id="BatTeamPreview">

                                             

                                          </div>

                                       </div>

                                       <div class="teamPreviewRowWrapper_0c54c">
                                          <div class="rowTitle_b91f3">All-Rounders</div>
                                          <div class="spaceAround_64779 rowContent_8aa5f" id="ArTeamPreview">

                                          </div>
                                       </div>

                                       <div class="teamPreviewRowWrapper_0c54c">

                                          <div class="rowTitle_b91f3">Bowlers</div>

                                          <div class="spaceAround_64779 rowContent_8aa5f" id="BwlTeamPreview">

                                            

                                          </div>

                                       </div>
                                     </div>

                                    </div>

                                 </div>

                              </div>

                              <div></div>

                           </div>

                        </div>

                     </div>


                     <div>

                        <div class="headerContainer_1725f headerFixed_38df7">

                           <div class="defaultHeaderContent_00a63">

                              <div class="headerLeft_36c4e">

                                 <button class="btn btn--icon">
                                  <a href="<?php echo base_url('website/contest?match='.$match_details['match_id']);?>">
                                    <div class="align-center"><i style="color: #fff;" class="material-icons">keyboard_arrow_left</i> </div>
                                    </a>
                                 </button>


                              </div>

                              <div class="headerCenter_4d6f0">

                                 <span>

                                    <div class="timer_3d48d">1h 21m left</div>

                                 </span>

                              </div>

                              <div class="headerRight_d1c5d">

                                

                                <!--  <a class="floatingAnchorButton_fac02" href="<?php //echo site_url('website/how_to_play') ?>" target="_blank">

                                    <div class="helpLink_4c95c">?</div>

                                 </a> -->

                              </div>

                           </div>

                           <div>
                            

                              <div>

                                 <div class="container_aa549">

                                    <div class="maxInfoText_13e5b">Max 7 players from a team</div>

                                    <div class="infoContent_0b612">

                                       <div class="playerSelectionContainer_d8646">

                                          <div>Players</div>

                                          <div class="squadTextContainer_3e550">

                                             <div class="selectedCount_daee8" id="player_count">11</div>

                                             <div class="totalCount_c1f66">/11</div>

                                          </div>

                                       </div>

                                       <div class="flagContainer_029e0">

                                          <div class="flagContainer_47acd"><img src="<?php echo $match_details['t1_image'];?>" class="flag_008b5"></div>

                                          <div class="squadOneText_3ad2c">

                                             <div class="teamName_a2024" id="FirstTeamNameShow"><?php echo $match_details['t1_sname'];?></div>

                                             <div class="teamCount_84ce0" id="team_first_cnt_show"><?php echo $team_count[0]; ?></div>

                                          </div>

                                       </div>

                                       <div class="flagContainer_029e0">

                                          <div class="squadTwoText_b9766">

                                             <div class="teamName_a2024" id="SecondTeamNameShow" ><?php echo $match_details['t2_sname'];?></div>

                                             <div class="teamCount_84ce0" id="team_second_cnt_show"><?php echo $team_count[1]; ?></div>

                                          </div>

                                          <div class="flagContainer_47acd"><img src="<?php echo $match_details['t2_image'];?>" class="flag_008b5"></div>

                                       </div>

                                       <div class="creditsContainer_e7f97">

                                          <div >Credits Left</div>

                                          <div class="creditsText_a4625">

                                             <div id="totalcreditCountShow"><?php echo $totalpoints; ?></div>

                                          </div>

                                       </div>

                                    </div>

                                    <!--activeStepper_2007e

                                    lastStepperActive_3d48d-->

                                    <div class="progressContainer_00657">

                                       <div class="stepperContainer_b9ae4">

                                          <div class="stepperBlock_8b62f activeStepper_2007e" id="block1"></div>

                                          <div class="stepperBlock_8b62f activeStepper_2007e" id="block2"></div>

                                          <div class="stepperBlock_8b62f activeStepper_2007e" id="block3"></div>

                                          <div class="stepperBlock_8b62f activeStepper_2007e" id="block4"></div>

                                          <div class="stepperBlock_8b62f activeStepper_2007e" id="block5"></div>

                                          <div class="stepperBlock_8b62f activeStepper_2007e" id="block6"></div>

                                          <div class="stepperBlock_8b62f activeStepper_2007e" id="block7"></div>

                                          <div class="stepperBlock_8b62f activeStepper_2007e" id="block8"></div>

                                          <div class="stepperBlock_8b62f activeStepper_2007e" id="block9"></div>

                                          <div class="stepperBlock_8b62f activeStepper_2007e" id="block10"></div>

                                          <div class="stepperBlock_8b62f activeStepper_2007e" id="block11"><span class="lastStepper_2bce1" >11</span></div>

                                       </div>

                                    </div>

                                 </div>

                              </div>

                           </div>

                        </div>

                        <div>
                          <!-- <div id="DivErrorTxtMessage" class="error" style="display:none;">
                            <p id="errorTxtMessage"></p> -->

                           <div class="mainWrapper_8542d">

                              <div class="tabsMainContainer_a916e">

                                 <div class="create-team-tabs tabsWrapper_43944">

                                    <div class="createTeamTabsContainer_5ba85">

                                       <div class="roleTabWrapper_a3522">

                                          <div class="roleTabItem_603ae">

                                            <input type="hidden" name="selectedArea" value="wk" id="selectedArea">

                                             <div class="createTeamTabTitle_99a5a "><a  onclick="show_players('wk'); SelectPlayers(1);">WK</a></div>

                                             <div  class="createTeamTabsCount_19658">(<div id="countWkNo"><?php echo $wkeeper1; ?></div>)</div>

                                          </div>

                                          <div class="wk_high highlight roleTabHighlight_ee4c9 roleTabHighlightActive_28bb8"></div>

                                       </div>

                                    </div>

                                    <div class="createTeamTabsContainer_5ba85">

                                       <div class="roleTabWrapper_a3522">

                                          <div class="roleTabItem_603ae">

                                             <div class="createTeamTabTitle_99a5a"><a onclick="show_players('bat'); SelectPlayers(2);">BAT</a></div>

                                             <div class="createTeamTabsCount_19658">(<div id="countBatNo"><?php echo $bat1; ?></div>)</div>

                                          </div>

                                          <div class="bat_high highlight roleTabHighlight_ee4c9 roleTabHighlightInactive_4d390"></div>

                                       </div>

                                    </div>

                                    <div class="createTeamTabsContainer_5ba85">

                                       <div class="roleTabWrapper_a3522">

                                          <div class="roleTabItem_603ae">

                                             <div class="createTeamTabTitle_99a5a"><a onclick="show_players('ar'); SelectPlayers(3);">AR</a></div>

                                             <div class="createTeamTabsCount_19658">(<div id="countArNo"><?php echo $all1; ?></div>)</div>

                                          </div>

                                          <div class="ar_high highlight roleTabHighlight_ee4c9 roleTabHighlightInactive_4d390"></div>

                                       </div>

                                    </div>

                                    <div class="createTeamTabsContainer_5ba85">

                                       <div class="roleTabWrapper_a3522">

                                          <div class="roleTabItem_603ae">

                                             <div class="createTeamTabTitle_99a5a"><a onclick="show_players('bowl'); SelectPlayers(4);">BOWL</a></div>

                                             <div class="createTeamTabsCount_19658">(<div id="countBwlNo"><?php echo $ball1; ?></div>)</div>

                                          </div>

                                          <div class="bowl_high highlight roleTabHighlight_ee4c9 roleTabHighlightInactive_4d390"></div>

                                       </div>

                                    </div>

                                 </div>

                                 <div class="createTeamTabsHelpContainer_ce9c9" id="SelectPlayers">Pick 1 Wicket-Keeper</div>

                                 <div class="ctSortingHeader_a6515">

                                    <div class="playerCardCell_bf9d8 playerCardAvatarCell_2b8d1"></div>

                                    <div class="playerCardInfoCell_ba412">

                                       <div class="playerCardCell_bf9d8 playerCardNameCell_50086 activeSortKey_c7202"><span>PLAYERS<span><i class="materialIcon_10a4f" style="height: 10px; width: 10px; font-size: 10px;">arrow_upward</i></span></span></div>

                                       <div class="playerCardCell_bf9d8 playerPointsCell_aa0e3"><span>POINTS</span></div>

                                       <div class="playerCardCell_bf9d8 playerPointsCell_aa0e3"><span>CREDITS</span></div>

                                       <div class="sortingHeaderIconPlaceHolder_43273"></div>

                                    </div>

                                 </div>

                              </div>

                              <div class="playerListContainer_e09a1">

                                 <div class="create-team__team-selector__player-list">
                                   <input type="hidden" name="wk" value="" id="selectedWk">

                                     <?php 


                                     foreach ($players as $player) {
                                            $pla[] = $player->player_id;
                                    } 

                                     foreach($wicketkeeper as $keeper){ 

                                     	if(in_array($keeper['playerid'],$pla))
                                      {
                                        $select = $keeper['playerid'];
                                         $minus = 'block';
                                         $plus = 'none'; 
                                         $background ='style="background-color: rgb(254, 255, 209);"';

                                          $select;
                                      }
                                      else
                                      {
                                          $plus = 'block';
                                         $minus = 'none'; 
                                         $background ='';
                                      }

                                      ?>

                             <div class="js--create-team__team-selector__player-card playerCard_42b9d" <?php echo $background; ?> id="wkbg_<?php echo $keeper['playerid'];?>">

                                       <div class="playerCardCell_bf9d8 playerCardAvatarCell_2b8d1">

                                          <div class="imageContainer_029e0">

                                             <div class="playerImageProfile_43b1b">

                                                <div class="playerImageContainer_6e52e">
                                                <div >
                                                	<div >
                                                		
                                                	</div>
                                                </div>
                                                   <div class="playerImage_f320d"  style="background-image: url(<?php echo base_url('uploads/player/'.$keeper['dimage']); ?>);"></div>

                                                </div>

                                             </div>

                                          </div>

                                       </div>

                                       <div class="playerCardInfoCell_ba412 playerCardInfoContainer_d41f9">

                                          <div class="playerCardCell_bf9d8 playerCardNameCell_50086">

                                             <div>

                                                <div class="playerName_73cad"><?php echo $keeper['name'] ?></div>

                                                <div class="playerTeamTitle_a2024"><span><?php echo $keeper['team_short_name']; ?></span><span class="light">- WK</span></div>

                                             </div>

                                          </div>

                                          <div class="playerCardCell_bf9d8 playerPointsCell_aa0e3"><?php echo $keeper['points']; ?></div>

                                          <div class="playerCardCell_bf9d8 playerPointsCell_aa0e3"><?php echo $keeper['credit_points']; ?></div>

                                          <div class="bold playerCardIconContainer_65be8">
                                            <?php
                                              $plyName=$keeper['name'];
                                              $wk="WK";
                                              $TeamShortName=$keeper['team_short_name'];
                                              $image =  base_url('uploads/player/'.$keeper['dimage']);
                                             ?>
                                             <div  class="playerCardIcon_b8a19 "><i class="materialIcon_10a4f keeper_id" style="height: 24px; display: none; width: 24px; font-size: 24px; display: <?php echo $plus; ?>"; id="AddBtn_<?php echo $keeper['playerid']; ?>" onclick="checkplayercount(); addPlayer('<?php echo $plyName; ?>' ,<?php echo $keeper['playerid'] ;?>,'<?php echo $wk; ?>',<?php  echo $keeper['credit_points'];?>,'<?php echo $TeamShortName ;?>','<?php echo $image ?>')">add</i>
                                             	<i class="materialIcon_10a4f" style="height: 24px; width: 24px; font-size: 24px; display: <?php echo $minus; ?>;" onclick="removePlyFromList(1,<?php echo $keeper['playerid']; ?>,<?php echo $keeper['credit_points'];?>,'<?php echo $TeamShortName;?>');"  id="RemoveBtn_<?php echo $keeper['playerid']; ?>" >remove</i>
                                              <span id="remWK_<?php echo $keeper['playerid']; ?>"></span>
                                             </div>
                                            
                                          </div>
                                       </div>

                                    </div>

                                  <?php } ?>

                                    

                                 </div>

                              </div>

                           </div>

                           <div class="footer_d9cd3">
								<div>
									<div class="prompt prompt--enter wrapper_de051" id="DivErrorTxtMessage" style="display: none;">
										<div class="prompt-content js--prompt-content">
											<div  class="js--prompt-content-container message_d58fc error_a70e4"><div id="errorTxtMessage">You can only select upto 1 Wicket-Keeper</div>
												<div class="prompt__close-button">
													<div class="align-center">
														<button class="btn btn--icon">
															<div class="align-center">
																<i class="material-icons">keyboard_arrow_up</i>
															</div>
														</button>
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>
                              <div class="footerButtonContainer_b9ae4">
                                <form method="post" action="<?php echo base_url('website/update_team_record'); ?>" >
                                <input type="hidden" id="teamWkCount" name="teamWkCount" value="1" />
<input type="hidden" id="teamArCount" name="teamArCount" value="<?php echo $all1; ?>" />
<input type="hidden" id="teamBatCount" name="teamBatCount" value="<?php echo $bat1; ?>" />
<input type="hidden" id="teamBwlCount" name="teamBwlCount" value="<?php echo $ball1; ?>" />
<input type="hidden" id="match_id" name="match_id" value="<?php echo $match_details['match_id']?>"  />
<input type="hidden" id="user_id" name="contest_id" value="<?php echo $contest['contest_id']?>"  />
<input type="hidden" id="max_ply_allow" name="max_ply_allow" value="7" />
<input type="hidden" id="team_first_cnt" name="team_first_cnt" value="<?php echo $team_count[0]; ?>" />
<input type="hidden" id="team_second_cnt" name="team_second_cnt" value="<?php echo $team_count[1]; ?>" />
<input type="hidden" id="FirstTeamName" name="FirstTeamName" value="<?php echo $match_details['t1_sname'];?>" />
<input type="hidden" id="SecondTeamName" name="SecondTeamName" value="<?php echo $match_details['t2_sname'];?>" />
<input type="hidden" id="WK1" name="WKeeperID" value="<?php echo $wkeep['player_id']; ?>" />
<input type="hidden" id="BAT1" name="BastmanID1" value="<?php echo $bat[0]['player_id']; ?>" /> 
<input type="hidden" id="BAT2" name="BastmanID2" value="<?php echo $bat[1]['player_id']; ?>" />
<input type="hidden" id="BAT3" name="BastmanID3" value="<?php echo $bat[2]['player_id']; ?>" />
<input type="hidden" id="BAT4" name="BastmanID4" value="<?php echo $bat[3]['player_id']; ?>" />
<input type="hidden" id="BAT5" name="BastmanID5" value="<?php echo $bat[4]['player_id']; ?>" />
<input type="hidden" id="AR1" name="AllRoundersID1" value="<?php echo $all[0]['player_id']; ?>" />
<input type="hidden" id="AR2" name="AllRoundersID2" value="<?php echo $all[1]['player_id']; ?>" />
<input type="hidden" id="AR3" name="AllRoundersID3" value="<?php echo $all[2]['player_id']; ?>" />
<input type="hidden" id="BWL1" name="BowlersID1" value="<?php echo $ball[0]['player_id']; ?>" /> 
<input type="hidden" id="BWL2" name="BowlersID2" value="<?php echo $ball[1]['player_id']; ?>" />
<input type="hidden" id="BWL3" name="BowlersID3" value="<?php echo $ball[2]['player_id']; ?>" />
<input type="hidden" id="BWL4" name="BowlersID4" value="<?php echo $ball[3]['player_id']; ?>" />
<input type="hidden" id="BWL5" name="BowlersID5" value="<?php echo $ball[4]['player_id']; ?>" />
<input type="hidden" name="totalcreditCount" id="totalcreditCount" value="<?php echo $totalpoints; ?>" />
<input type="hidden" name="teamid" id="teamid" value="<?php echo $this->uri->segment('3'); ?>" />
<input type="hidden" name="totalcreditRemain" id="totalcreditRemain" value="<?php echo $totalpoints; ?>" />

                                 <div class="js--create-team-continue-btn">

                                  <input type="submit" value="CONTINUE" name="" id="cont_btn" class="new-button  raisedGreenButton_20c05 raisedGreenButtonDisabled_e0a23">
                                  <!-- <button id="cont_btn" disabled="disabled" class="new-button  raisedGreenButton_20c05 raisedGreenButtonDisabled_e0a23">CONTINUE</button> --></div>
                                 </form>
                              </div>

                           </div>

                        </div>

                        <div id="wk" style="display:none;">

                         

                        </div>

                         <div id="ar" style="display:none;">

                          <?php $aa = 1; foreach($allrounder as $rounder){ 
                            $image =  base_url('uploads/player/'.$rounder['dimage']);

                            	if(in_array($rounder['playerid'],$pla))
                                      {
                                      	$aa ++; 
                                        $select = $rounder['playerid'];
                                         $minus = 'block';
                                         $plus = 'none'; 
                                         $background ='style="background-color: rgb(254, 255, 209);"';

                                          $select;
                                      }
                                      else
                                      {
                                          $plus = 'block';
                                         $minus = 'none'; 
                                         $background ='';
                                      }

                                      ?>

                             <div class="js--create-team__team-selector__player-card playerCard_42b9d " <?php echo $background; ?> id="arbg_<?php  echo $rounder['playerid'];?>">

                                       <div class="playerCardCell_bf9d8 playerCardAvatarCell_2b8d1">

                                          <div class="imageContainer_029e0">

                                             <div class="playerImageProfile_43b1b">

                                                <div class="playerImageContainer_6e52e">

                                                   <div class="playerImage_f320d" style="background-image: url(<?php echo base_url('uploads/player/'.$rounder['dimage']); ?>);"></div>

                                                </div>

                                             </div>

                                          </div>

                                       </div>

                                       <div class="playerCardInfoCell_ba412 playerCardInfoContainer_d41f9">

                                          <div class="playerCardCell_bf9d8 playerCardNameCell_50086">

                                             <div>

                                                <div class="playerName_73cad"><?php echo $rounder['name'] ?></div>

                                                <div class="playerTeamTitle_a2024"><span><?php echo $rounder['team_short_name']; ?></span><span class="light">- ALL</span></div>

                                             </div>

                                          </div>

                                          <div class="playerCardCell_bf9d8 playerPointsCell_aa0e3"><?php echo $rounder['points']; ?></div>

                                          <div class="playerCardCell_bf9d8 playerPointsCell_aa0e3"><?php echo $rounder['credit_points']; ?></div>

                                          <div class="bold playerCardIconContainer_65be8">
                                            <?php
                                              $plyName=$rounder['name'];
                                              $ar="AR";
                                              $TeamShortName=$rounder['team_short_name'];
                                             ?>
                                              <div class="playerCardIcon_b8a19 "><i class="materialIcon_10a4f" style="height: 24px; width: 24px; font-size: 24px; display: <?php echo $plus; ?>"" id="AddBtn_<?php echo $rounder['playerid']; ?>" onclick="checkplayercount(); addPlayer('<?php echo $plyName; ?>' ,<?php echo $rounder['playerid'] ;?>,'<?php echo $ar; ?>',<?php  echo $rounder['credit_points'];?>,'<?php echo $TeamShortName ;?>','<?php echo $image; ?>')">add</i>
                                              	
                                              <span id="remAr_<?php echo $rounder['playerid']; ?>">
                                              	<i class="materialIcon_10a4f" style="height: 24px; width: 24px; font-size: 24px; display: <?php echo $minus; ?>;" onclick="removeArPlyFromList(<?php echo $aa; ?>,<?php echo $rounder['playerid']; ?>,<?php echo $rounder['credit_points'];?>,'<?php echo $TeamShortName;?>');"  id="RemoveBtn_<?php echo $rounder['playerid']; ?>" >remove</i>
                                              </span>
                                             </div>

                                          </div>

                                       </div>

                                    </div>

                                  <?php } ?>

                        </div>

                         <div id="bowl" style="display:none;">

                          <?php $bb = 1; foreach($bowler as $bowl){ 
                            $image =  base_url('uploads/player/'.$bowl['dimage']);

                            if(in_array($bowl['playerid'],$pla))
                                      {
                                      	$bb++;
                                        $select = $bowl['playerid'];
                                         $minus = 'block';
                                         $plus = 'none'; 
                                         $background ='style="background-color: rgb(254, 255, 209);"';

                                          $select;
                                      }
                                      else
                                      {
                                          $plus = 'block';
                                         $minus = 'none'; 
                                         $background ='';
                                      }

                                      ?>
                           

                             <div class="js--create-team__team-selector__player-card playerCard_42b9d " <?php echo $background; ?>  id="bwlbg_<?php  echo $bowl['playerid'];?>">

                                       <div class="playerCardCell_bf9d8 playerCardAvatarCell_2b8d1">

                                          <div class="imageContainer_029e0">

                                             <div class="playerImageProfile_43b1b">

                                                <div class="playerImageContainer_6e52e">

                                                   <div class="playerImage_f320d" style="background-image: url(<?php echo base_url('uploads/player/'.$bowl['dimage']); ?>);"></div>

                                                </div>

                                             </div>

                                          </div>

                                       </div>

                                       <div class="playerCardInfoCell_ba412 playerCardInfoContainer_d41f9">

                                          <div class="playerCardCell_bf9d8 playerCardNameCell_50086">

                                             <div>

                                                <div class="playerName_73cad"><?php echo $bowl['name'] ?></div>

                                                <div class="playerTeamTitle_a2024"><span><?php echo $bowl['team_short_name']; ?></span><span class="light">- BOWL</span></div>

                                             </div>

                                          </div>

                                          <div class="playerCardCell_bf9d8 playerPointsCell_aa0e3"><?php echo $bowl['points']; ?></div>

                                          <div class="playerCardCell_bf9d8 playerPointsCell_aa0e3"><?php echo $bowl['credit_points']; ?></div>

                                          <div class="bold playerCardIconContainer_65be8">

                                             <?php
                                              $plyName=$bowl['name'];
                                              $ar="BOWL";
                                              $TeamShortName=$bowl['team_short_name'];
                                             ?>
                                              <div class="playerCardIcon_b8a19 "><i class="materialIcon_10a4f" style="height: 24px; width: 24px; font-size: 24px;display: <?php echo $plus; ?> " id="AddBtn_<?php echo $bowl['playerid']; ?>" onclick="checkplayercount(); addPlayer('<?php echo $plyName; ?>' ,<?php echo $bowl['playerid'] ;?>,'<?php echo $ar; ?>',<?php  echo $bowl['credit_points'];?>,'<?php echo $TeamShortName ;?>','<?php echo $image; ?>')">add</i>
                                              	
                                              <span id="remBwl_<?php echo $bowl['playerid']; ?>">
                                              	<i class="materialIcon_10a4f" style="height: 24px; width: 24px; font-size: 24px; display: <?php echo $minus; ?>;" onclick="removeBwlPlyFromList(<?php echo $bb; ?>,<?php echo $bowl['playerid']; ?>,<?php echo $bowl['credit_points'];?>,<?php echo $bowl['TeamShortName']; ?>);"  id="RemoveBtn_<?php echo $bowl['playerid']; ?>"  id="RemoveBtn_<?php echo $bowl['playerid']; ?>" >remove</i>
                                              </span>
                                             </div>

                                          </div>

                                       </div>

                                    </div>

                                  <?php  } ?>

                        </div>
                        <input type="hidden" id="teamplayercount" name="teamplayercount" value="11" />
                      



                         <div id="bat" style="display:none;">


                          <?php $cc = 1; foreach($batsman as $bats){ 
                            $image =  base_url('uploads/player/'.$bats['dimage']);

                            if(in_array($bats['playerid'],$pla))
                                      {
                                      	$cc++;
                                        $select = $bats['playerid'];
                                         $minus = 'block';
                                         $plus = 'none'; 
                                         $background ='style="background-color: rgb(254, 255, 209);"';

                                          $select;
                                      }
                                      else
                                      {
                                          $plus = 'block';
                                         $minus = 'none'; 
                                         $background ='';
                                      }

                                      ?>
                           


                             <div class="js--create-team__team-selector__player-card playerCard_42b9d " <?php echo $background; ?>  id="batbg_<?php  echo $bats['playerid'];?>">

                                       <div class="playerCardCell_bf9d8 playerCardAvatarCell_2b8d1">

                                          <div class="imageContainer_029e0">

                                             <div class="playerImageProfile_43b1b">

                                                <div class="playerImageContainer_6e52e">

                                                   <div class="playerImage_f320d" style="background-image: url(<?php echo base_url('uploads/player/'.$bats['dimage']); ?>);"></div>

                                                </div>

                                             </div>

                                          </div>

                                       </div>

                                       <div class="playerCardInfoCell_ba412 playerCardInfoContainer_d41f9">

                                          <div class="playerCardCell_bf9d8 playerCardNameCell_50086">

                                             <div>

                                                <div class="playerName_73cad"><?php echo $bats['name'] ?></div>

                                                <div class="playerTeamTitle_a2024"><span><?php echo $bats['team_short_name']; ?></span><span class="light">- BAT</span></div>

                                             </div>

                                          </div>

                                          <div class="playerCardCell_bf9d8 playerPointsCell_aa0e3"><?php echo $bats['points']; ?></div>

                                          <div class="playerCardCell_bf9d8 playerPointsCell_aa0e3"><?php echo $bats['credit_points']; ?></div>

                                          <div class="bold playerCardIconContainer_65be8">

                                             <?php
                                              $plyName=$bats['name'];
                                              $bat="BAT";
                                              $TeamShortName=$bats['team_short_name'];
                                             ?>
                                              <div class="playerCardIcon_b8a19 "><i class="materialIcon_10a4f" style="height: 24px; width: 24px; font-size: 24px; display: <?php echo $plus; ?>" id="AddBtn_<?php echo $bats['playerid']; ?>" onclick="checkplayercount(); addPlayer('<?php echo $plyName; ?>' ,<?php echo $bats['playerid'] ;?>,'<?php echo $bat; ?>',<?php  echo $bats['credit_points'];?>,'<?php echo $TeamShortName ;?>','<?php echo $image; ?>')">add</i>
                                              <span  id="remBat_<?php echo $bats['playerid']; ?>">
                                              	<i class="materialIcon_10a4f" style="height: 24px; width: 24px; font-size: 24px; display: <?php echo $minus; ?>;" onclick="removeBatPlyFromList(<?php echo $cc; ?>,<?php echo $bats['playerid']; ?>,<?php echo $bats['credit_points'];?>,'<?php echo $TeamShortName;?>');"  id="RemoveBtn_<?php echo $bats['playerid']; ?>" >remove</i>
                                              </span>
                                             </div>
                                          </div>
                                       </div>

                                    </div>

                                  <?php } ?>

                        </div>

                        <div></div>

                        <div></div>

                     </div>

                  </div>

               </div>

            </div>

         </div>

      </div>
      <script>
      
      function checkplayercount()
    {
      var tmplayer11=document.getElementById("teamplayercount").value;

        if(tmplayer11 == '10'){

        $('#cont_btn').removeClass('raisedGreenButton_20c05 raisedGreenButtonDisabled_e0a23');

        $('#cont_btn').removeAttr("disabled");

      }
    }

       function show_players(keyword){
        
        var selectedArea = $('#selectedArea').val();

        $('.highlight').removeClass('roleTabHighlightActive_28bb8');

        $('.highlight').addClass('roleTabHighlightInactive_4d390'); 

        $('.'+keyword+'_high').removeClass('roleTabHighlightInactive_4d390');    

        $('.'+keyword+'_high').addClass('roleTabHighlightActive_28bb8');    

          var oldtemp = $('.create-team__team-selector__player-list').html();

           $('#'+selectedArea).html(oldtemp);

           var newtemp = $('#'+keyword).html();

           $('#selectedArea').val(keyword);   

           $('.create-team__team-selector__player-list').html(newtemp);          

     

    }
 /*   function add_weeket_keeper(val,text) {    
      $('#selectedWk').val(val);
        var keepers = document.getElementsByClassName('keeper_id');
        for (var i = 0; i < keepers.length; i++) {
          keepers[i].onclick = function(target) {
              [].forEach.call(keepers, function(keeper) { 
              keeper.innerHTML = "add" 
            });
            this.innerHTML = "remove";
          }
        }
    }*/
     </script>
     <script type="text/javascript">

function SelectPlayers(selectply)

{

  var selectply2=selectply;

  if(selectply2==1)

  {

    document.getElementById('SelectPlayers').innerHTML='SELECT 1 WICKET-KEEPER';  

  }

  if(selectply2==2)

  {

    document.getElementById('SelectPlayers').innerHTML='SELECT 3-5 BATSMENS'; 

  }

  if(selectply2==3)

  {

    document.getElementById('SelectPlayers').innerHTML='SELECT 1-3 ALL-ROUNDERS'; 

  }

  if(selectply2==4)

  {

    document.getElementById('SelectPlayers').innerHTML='SELECT 3-5 BOWLERS';  

  }

  

} ///////////// end code for select wiket keeper ////////





var teamWkCount=document.getElementById("teamWkCount").value;

var teamArCount=document.getElementById("teamArCount").value;

var teamBatCount=document.getElementById("teamBatCount").value;

var teamBwlCount=document.getElementById("teamBwlCount").value;





function checkMinPlayer()

{

  var teamWkCount1=document.getElementById("teamWkCount").value;

  var teamArCount1=document.getElementById("teamArCount").value;

  var teamBatCount1=document.getElementById("teamBatCount").value;

  var teamBwlCount1=document.getElementById("teamBwlCount").value;

  var tmplayer11=document.getElementById("teamplayercount").value;

  

  if(tmplayer11 == 11){

        $('#cont_btn').removeClass('raisedGreenButton_20c05 raisedGreenButtonDisabled_e0a23');
    $('#cont_btn').removeAttr("disabled");

    //alert(teamWkCount1+"---"+teamArCount1+"---"+teamBatCount1+"---"+teamBwlCount1);

    if(teamWkCount1 < 1)

    {

      var $div2=$("#DivErrorTxtMessage");
      if($div2.is(":visible")) { return; }
      document.getElementById("errorTxtMessage").innerHTML="At lease 1 Wicket-keeper is must.";
      $div2.show();
      setTimeout(function() { $div2.hide();}, 2000); 
      return false;

    }

    if(teamArCount1 < 1)

    {

      var $div2=$("#DivErrorTxtMessage");
      if($div2.is(":visible")) { return; }
      document.getElementById("errorTxtMessage").innerHTML="At lease 1 Allrounder is must.";
      $div2.show();
      setTimeout(function() { $div2.hide();}, 2000); 
      return false;

    }

    if(teamBatCount1 < 3)

    {

    var $div2=$("#DivErrorTxtMessage");
    if($div2.is(":visible")) { return; }
    document.getElementById("errorTxtMessage").innerHTML="At lease 3 Batsmans is must.";
    $div2.show();
    setTimeout(function() { $div2.hide();}, 2000); 
    return false;

    }

    if(teamBwlCount1 < 3)

    {

    var $div2=$("#DivErrorTxtMessage");
    if($div2.is(":visible")) { return; }
    document.getElementById("errorTxtMessage").innerHTML="At lease 3 Bowlers is must.";
    $div2.show();
    setTimeout(function() { $div2.hide();}, 2000); 
    return false;

    }

    return true;

  }

  else{

  //alert("Please select 11 Players to save the team.");

  //return false;


    var $div2=$("#DivErrorTxtMessage");
    if($div2.is(":visible")) { return; }
    document.getElementById("errorTxtMessage").innerHTML="Please select 11 Players to save the team.";
    $div2.show();
    setTimeout(function() { $div2.hide();}, 2000); 
    return false;

  }

  return false;

}



///////////////////////////////// add player ////////////////



function addPlayer(plyname,plyId,plytype,creditpoints,teamname,image) //BAT AR BOWL WK
{
var plyId=plyId;
var plyName=plyname;
var plyType=plytype;
var creditpoints = creditpoints;
var teamName = teamname;

var teamWkCount1=document.getElementById("teamWkCount").value;


var tmplayer=document.getElementById("teamplayercount").value;



if(tmplayer==11) {
  
    var $div2=$("#DivErrorTxtMessage");
    if($div2.is(":visible")) { return; }
    document.getElementById("errorTxtMessage").innerHTML="Max can we 11 players.";
    $div2.show();

    $('#cont_btn').removeClass('raisedGreenButton_20c05 raisedGreenButtonDisabled_e0a23');
    $('#cont_btn').removeAttr("disabled");
    setTimeout(function() { $div2.hide();}, 2000); 
    return false;
    

return true;

}    

var mycount = count7players(teamName);

var valid = validCount10( parseInt(tmplayer)+1,plytype);

var maxlimit = maxLimitValidation(plytype,parseInt(tmplayer)+1);

////////////////// if wk selected ///////////
if(mycount ==0 && valid ==0 && maxlimit ==0){
if(teamWkCount1==1 && plytype=='WK')

{

  var $div2=$("#DivErrorTxtMessage");
  if($div2.is(":visible")) { return; }
  document.getElementById("errorTxtMessage").innerHTML="You can choose only 1 wicket-keeper.";
  $div2.show();
  setTimeout(function() { $div2.hide();}, 2000);  
    return true;  

}


var teamBatCount1=document.getElementById("teamBatCount").value;

if(teamBatCount1==5 && plytype=='BAT')

{


    var $div2=$("#DivErrorTxtMessage");   
    if($div2.is(":visible")) { return; }    
    document.getElementById("errorTxtMessage").innerHTML="Maximum limit of Batsmans is 5 your team is looking good.";   
    $div2.show();   
    setTimeout(function() { $div2.hide();}, 2000);      
    return true; 

}







var teamArCount1=document.getElementById("teamArCount").value;

if(teamArCount1==3 && plytype=='AR')

{

    var $div2=$("#DivErrorTxtMessage");
  if($div2.is(":visible")) { return; }
  document.getElementById("errorTxtMessage").innerHTML="Maximum limit of All Rounder is 3 your team is looking good.";
  $div2.show();
  setTimeout(function() { $div2.hide();}, 2000);  
    return true; 

}

var teamBwlCount1=document.getElementById("teamBwlCount").value;

if(teamBwlCount1==5 && plytype=='BOWL')

{


    var $div2=$("#DivErrorTxtMessage");
  if($div2.is(":visible")) { return; }
  document.getElementById("errorTxtMessage").innerHTML="Maximum limit of Bowlers is 5 your team is looking good.";
  $div2.show();
  setTimeout(function() { $div2.hide();}, 2000); 
    return true; 

}

//////////////////////// for WK //////////

if(plytype=='WK')

{
var wkname=document.getElementById('WK1').value;

var teamWkCount=document.getElementById('teamWkCount').value;

var totalcreditCount=document.getElementById("totalcreditCount").value;

//alert(teamWkCount);

//alert(totalcreditCount);

if(wkname!='')
{ 

   alert('Weeket keeper allready selected..');  
} 
 else if(wkname=='' && ( parseFloat(creditpoints) <= parseFloat(totalcreditCount)))
{ 

document.getElementById('wkbg_'+plyId).style.backgroundColor='rgb(254, 255, 209)';

document.getElementById('AddBtn_'+plyId).style.display='none';
document.getElementById('RemoveBtn_'+plyId).style.display='block';
var teamNameVar = "'"+teamName+"'";
var remTxtWk1='<i class="materialIcon_10a4f" style="height: 24px; width: 24px; font-size: 24px;" class="fa fa-minus" onclick="removePlyFromList(1,'+plyId+','+creditpoints+','+teamNameVar+');"></i>';
show_preview(plyname,plyId,plytype,creditpoints,image,teamname);

//document.getElementById('remWk_'+plyId).innerHTML=remTxtWk1; 


 //////////////// code for count player in team //////
  var team_first_cnt=document.getElementById("team_first_cnt").value;
  var team_second_cnt=document.getElementById("team_second_cnt").value;
  var FirstTeamName=document.getElementById("FirstTeamName").value;
  var SecondTeamName=document.getElementById("SecondTeamName").value;
  if(teamName==FirstTeamName)
  {

  team_first_cnt=document.getElementById("team_first_cnt").value;
  var plus1firstTeam=parseInt(team_first_cnt)+1;
      if(plus1firstTeam>7){
            var $div2=$("#DivErrorTxtMessage");
        if($div2.is(":visible")) { return; }
        document.getElementById("errorTxtMessage").innerHTML="Max can we 7 players allowed from one Team.";
        $div2.show();
        setTimeout(function() { $div2.hide();}, 2000); 
            return false;
      }
      else{
          document.getElementById("team_first_cnt").value=plus1firstTeam;
          document.getElementById('team_first_cnt_show').innerHTML=plus1firstTeam;
      }
  }else if(teamName==SecondTeamName)
  { 

  var team_second_cnt=document.getElementById("team_second_cnt").value;
  var plus1secondTeam=parseInt(team_second_cnt)+1;
  if(plus1secondTeam>7){
            var $div2=$("#DivErrorTxtMessage");
        if($div2.is(":visible")) { return; }
        document.getElementById("errorTxtMessage").innerHTML="Max can we 7 players allowed from one Team.";
        $div2.show();
        setTimeout(function() { $div2.hide();}, 2000); 
            return false;
      }
      else{
  document.getElementById("team_second_cnt").value=plus1secondTeam;
  document.getElementById('team_second_cnt_show').innerHTML=plus1secondTeam;
}
  } else {
  }


  //////////////// code for count player in team //////

var tmplayer2=parseInt(tmplayer)+1;

document.getElementById("teamplayercount").value=tmplayer2;

document.getElementById("player_count").innerHTML=tmplayer2;

var p_count = document.getElementById("player_count").innerHTML; 

$('#block'+tmplayer2).removeClass('inactiveStepper_4d390');
$('#block'+tmplayer2).addClass('activeStepper_2007e');
$('#block'+tmplayer2).html(tmplayer2);

document.getElementById("WK1").value=plyId;

var teamWkCount=document.getElementById("teamWkCount").value;

var teamWkCount=parseInt(teamWkCount)+1;

document.getElementById("teamWkCount").value=teamWkCount;

document.getElementById("countWkNo").innerHTML=teamWkCount;

var totalcreditCount=document.getElementById("totalcreditCount").value;

var totalcreditCount=document.getElementById("totalcreditCount").value;




var totalcreditCount2 = parseFloat(totalcreditCount)-parseFloat(creditpoints);

document.getElementById('totalcreditCountShow').innerHTML=totalcreditCount2;

document.getElementById("totalcreditCount").value=totalcreditCount2; 


// countBatNo countArNo countBwlNo 

} else {

      //alert('You have not sufficient credit points.');  

    var $div2=$("#DivErrorTxtMessage");

    if($div2.is(":visible")) { return; }

    document.getElementById("errorTxtMessage").innerHTML="You have not sufficent credit points.";

    $div2.show();

    setTimeout(function() { $div2.hide();}, 2000); 

  }

  //SelectCapWiseCap

}

//////////////////////// for WK //////////







//////////////////////// for BAT //////////

if(plytype=='BAT')
{ 

var bat1=document.getElementById('BAT1').value; 

var bat2=document.getElementById('BAT2').value;

var bat3=document.getElementById('BAT3').value;

var bat4=document.getElementById('BAT4').value;

var bat5=document.getElementById('BAT5').value;

var totalcreditCount=document.getElementById("totalcreditCount").value;

if(bat1=='' && ( parseFloat(creditpoints) <= parseFloat(totalcreditCount)))
{ 

document.getElementById('batbg_'+plyId).style.backgroundColor='rgb(254, 255, 209)';

document.getElementById('BAT1').value=plyId;

document.getElementById('AddBtn_'+plyId).style.display='none';
//document.getElementById('RemoveBtn_'+plyId).style.display='block';

var teamNameVar = "'"+teamName+"'";
var remTxtBAT1='<i class="materialIcon_10a4f" style="height: 24px; width: 24px; font-size: 24px;" class="fa fa-minus" onclick="removeBatPlyFromList(1,'+plyId+','+creditpoints+','+teamNameVar+');">remove</i>'; 

document.getElementById('remBat_'+plyId).innerHTML=remTxtBAT1;
show_preview(plyname,plyId,plytype,creditpoints,image,teamname);

////////////// for team member /////////////////////  

var tmplayer2=parseInt(tmplayer)+1;

document.getElementById("teamplayercount").value=tmplayer2;

document.getElementById("player_count").innerHTML=tmplayer2;
$('#block'+tmplayer2).removeClass('inactiveStepper_4d390');
$('#block'+tmplayer2).addClass('activeStepper_2007e');
$('#block'+tmplayer2).html(tmplayer2);

///////////////// for for total batsman count ///////////////////

document.getElementById("BAT1").value=plyId;  

var teamBatCount=document.getElementById("teamBatCount").value;

var teamBatCount=parseInt(teamBatCount)+1;

document.getElementById("teamBatCount").value=teamBatCount; 

document.getElementById("countBatNo").innerHTML=teamBatCount; 

/////////////////// for credit points //////////////

var totalcreditCount=document.getElementById("totalcreditCount").value;

var totalcreditCount2 = parseFloat(totalcreditCount)-parseFloat(creditpoints);

document.getElementById('totalcreditCountShow').innerHTML=totalcreditCount2;

document.getElementById("totalcreditCount").value=totalcreditCount2; 
  //////////////// code for count player in team //////
  var team_first_cnt=document.getElementById("team_first_cnt").value;
  var team_second_cnt=document.getElementById("team_second_cnt").value;
  var FirstTeamName=document.getElementById("FirstTeamName").value;
  var SecondTeamName=document.getElementById("SecondTeamName").value;
  if(teamName==FirstTeamName)
  {
  team_first_cnt=document.getElementById("team_first_cnt").value;
  var plus1firstTeam=parseInt(team_first_cnt)+1;
  document.getElementById("team_first_cnt").value=plus1firstTeam;
  document.getElementById('team_first_cnt_show').innerHTML=plus1firstTeam;
  }else if(teamName==SecondTeamName)
  { 
  var team_second_cnt=document.getElementById("team_second_cnt").value;
  var plus1secondTeam=parseInt(team_second_cnt)+1;
  document.getElementById("team_second_cnt").value=plus1secondTeam;
  document.getElementById('team_second_cnt_show').innerHTML=plus1secondTeam;
  } else {
  }
  //////////////// code for count player in team //////

} 

else if(bat2=='' && ( parseFloat(creditpoints) <= parseFloat(totalcreditCount))) 

{   

document.getElementById('batbg_'+plyId).style.backgroundColor='rgb(254, 255, 209)';

document.getElementById('BAT2').value=plyId;

document.getElementById('AddBtn_'+plyId).style.display='none';
//document.getElementById('RemoveBtn_'+plyId).style.display='block';
var teamNameVar = "'"+teamName+"'";
var remTxtBAT1='<i class="materialIcon_10a4f" style="height: 24px; width: 24px; font-size: 24px;" class="fa fa-minus" onclick="removeBatPlyFromList(2,'+plyId+','+creditpoints+','+teamNameVar+');">remove</i>'; 
document.getElementById('remBat_'+plyId).innerHTML=remTxtBAT1;
show_preview(plyname,plyId,plytype,creditpoints,image,teamname);
////////////// for team member /////////////////////  

var tmplayer2=parseInt(tmplayer)+1;

document.getElementById("teamplayercount").value=tmplayer2;

document.getElementById("player_count").innerHTML=tmplayer2;

$('#block'+tmplayer2).removeClass('inactiveStepper_4d390');
$('#block'+tmplayer2).addClass('activeStepper_2007e');
$('#block'+tmplayer2).html(tmplayer2);
///////////////// for for total batsman count ///////////////////

document.getElementById("BAT2").value=plyId;  

var teamBatCount=document.getElementById("teamBatCount").value;

var teamBatCount=parseInt(teamBatCount)+1;

document.getElementById("teamBatCount").value=teamBatCount; 

document.getElementById("countBatNo").innerHTML=teamBatCount; 

/////////////////// for credit points //////////////

var totalcreditCount=document.getElementById("totalcreditCount").value;

var totalcreditCount2 = parseFloat(totalcreditCount)-parseFloat(creditpoints);

document.getElementById('totalcreditCountShow').innerHTML=totalcreditCount2;

document.getElementById("totalcreditCount").value=totalcreditCount2; 

  //////////////// code for count player in team //////
  var team_first_cnt=document.getElementById("team_first_cnt").value;
  var team_second_cnt=document.getElementById("team_second_cnt").value;
  var FirstTeamName=document.getElementById("FirstTeamName").value;
  var SecondTeamName=document.getElementById("SecondTeamName").value;
  if(teamName==FirstTeamName)
  {
  team_first_cnt=document.getElementById("team_first_cnt").value;
  var plus1firstTeam=parseInt(team_first_cnt)+1;
  document.getElementById("team_first_cnt").value=plus1firstTeam;
  document.getElementById('team_first_cnt_show').innerHTML=plus1firstTeam;
  }else if(teamName==SecondTeamName)
  { 
  var team_second_cnt=document.getElementById("team_second_cnt").value;
  var plus1secondTeam=parseInt(team_second_cnt)+1;
  document.getElementById("team_second_cnt").value=plus1secondTeam;
  document.getElementById('team_second_cnt_show').innerHTML=plus1secondTeam;
  } else {
  }
  //////////////// code for count player in team //////


} 

else if(bat3=='' && ( parseFloat(creditpoints) <= parseFloat(totalcreditCount))) 
{
document.getElementById('batbg_'+plyId).style.backgroundColor='rgb(254, 255, 209)';
document.getElementById('BAT3').value=plyId;
document.getElementById('AddBtn_'+plyId).style.display='none';
//document.getElementById('RemoveBtn_'+plyId).style.display='block';
var teamNameVar = "'"+teamName+"'";
var remTxtBAT1='<i class="materialIcon_10a4f" style="height: 24px; width: 24px; font-size: 24px;" class="fa fa-minus" onclick="removeBatPlyFromList(3,'+plyId+','+creditpoints+','+teamNameVar+');">remove</i>'; 

document.getElementById('remBat_'+plyId).innerHTML=remTxtBAT1;
show_preview(plyname,plyId,plytype,creditpoints,image,teamname);
////////////// for team member /////////////////////  

var tmplayer2=parseInt(tmplayer)+1;

document.getElementById("teamplayercount").value=tmplayer2;

document.getElementById("player_count").innerHTML=tmplayer2;

$('#block'+tmplayer2).removeClass('inactiveStepper_4d390');
$('#block'+tmplayer2).addClass('activeStepper_2007e');
$('#block'+tmplayer2).html(tmplayer2);

///////////////// for for total batsman count ///////////////////

document.getElementById("BAT3").value=plyId;  

var teamBatCount=document.getElementById("teamBatCount").value;

var teamBatCount=parseInt(teamBatCount)+1;

document.getElementById("teamBatCount").value=teamBatCount; 

document.getElementById("countBatNo").innerHTML=teamBatCount; 

/////////////////// for credit points //////////////

var totalcreditCount=document.getElementById("totalcreditCount").value;

var totalcreditCount2 = parseFloat(totalcreditCount)-parseFloat(creditpoints);

document.getElementById('totalcreditCountShow').innerHTML=totalcreditCount2;

document.getElementById("totalcreditCount").value=totalcreditCount2;  

  //////////////// code for count player in team //////
  var team_first_cnt=document.getElementById("team_first_cnt").value;
  var team_second_cnt=document.getElementById("team_second_cnt").value;
  var FirstTeamName=document.getElementById("FirstTeamName").value;
  var SecondTeamName=document.getElementById("SecondTeamName").value;
  if(teamName==FirstTeamName)
  {
  team_first_cnt=document.getElementById("team_first_cnt").value;
  var plus1firstTeam=parseInt(team_first_cnt)+1;
  document.getElementById("team_first_cnt").value=plus1firstTeam;
  document.getElementById('team_first_cnt_show').innerHTML=plus1firstTeam;
  }else if(teamName==SecondTeamName)
  { 
  var team_second_cnt=document.getElementById("team_second_cnt").value;
  var plus1secondTeam=parseInt(team_second_cnt)+1;
  document.getElementById("team_second_cnt").value=plus1secondTeam;
  document.getElementById('team_second_cnt_show').innerHTML=plus1secondTeam;
  } else {
  }
  //////////////// code for count player in team //////


}

else if(bat4=='' && ( parseFloat(creditpoints) <= parseFloat(totalcreditCount))) 

{   

document.getElementById('batbg_'+plyId).style.backgroundColor='rgb(254, 255, 209)';

document.getElementById('BAT4').value=plyId;

document.getElementById('AddBtn_'+plyId).style.display='none';
//document.getElementById('RemoveBtn_'+plyId).style.display='block';

var teamNameVar = "'"+teamName+"'";
var remTxtBAT1='<i class="materialIcon_10a4f" style="height: 24px; width: 24px; font-size: 24px;" class="fa fa-minus" onclick="removeBatPlyFromList(4,'+plyId+','+creditpoints+','+teamNameVar+');">remove</i>'; 

document.getElementById('remBat_'+plyId).innerHTML=remTxtBAT1;
show_preview(plyname,plyId,plytype,creditpoints,image,teamname);
////////////// for team member /////////////////////  

var tmplayer2=parseInt(tmplayer)+1;

document.getElementById("teamplayercount").value=tmplayer2;

document.getElementById("player_count").innerHTML=tmplayer2;

$('#block'+tmplayer2).removeClass('inactiveStepper_4d390');
$('#block'+tmplayer2).addClass('activeStepper_2007e');
$('#block'+tmplayer2).html(tmplayer2);

///////////////// for for total batsman count ///////////////////

document.getElementById("BAT4").value=plyId;  

var teamBatCount=document.getElementById("teamBatCount").value;

var teamBatCount=parseInt(teamBatCount)+1;

document.getElementById("teamBatCount").value=teamBatCount; 

document.getElementById("countBatNo").innerHTML=teamBatCount; 

/////////////////// for credit points //////////////

var totalcreditCount=document.getElementById("totalcreditCount").value;

var totalcreditCount2 = parseFloat(totalcreditCount)-parseFloat(creditpoints);

document.getElementById('totalcreditCountShow').innerHTML=totalcreditCount2;

document.getElementById("totalcreditCount").value=totalcreditCount2; 

  //////////////// code for count player in team //////
  var team_first_cnt=document.getElementById("team_first_cnt").value;
  var team_second_cnt=document.getElementById("team_second_cnt").value;
  var FirstTeamName=document.getElementById("FirstTeamName").value;
  var SecondTeamName=document.getElementById("SecondTeamName").value;
  if(teamName==FirstTeamName)
  {
  team_first_cnt=document.getElementById("team_first_cnt").value;
  var plus1firstTeam=parseInt(team_first_cnt)+1;
  document.getElementById("team_first_cnt").value=plus1firstTeam;
  document.getElementById('team_first_cnt_show').innerHTML=plus1firstTeam;
  }else if(teamName==SecondTeamName)
  { 
  var team_second_cnt=document.getElementById("team_second_cnt").value;
  var plus1secondTeam=parseInt(team_second_cnt)+1;
  document.getElementById("team_second_cnt").value=plus1secondTeam;
  document.getElementById('team_second_cnt_show').innerHTML=plus1secondTeam;
  } else {
  }
  //////////////// code for count player in team //////


}

else if(bat5=='' && ( parseFloat(creditpoints) <= parseFloat(totalcreditCount))) 

{   

document.getElementById('batbg_'+plyId).style.backgroundColor='rgb(254, 255, 209)';

document.getElementById('BAT5').value=plyId;

document.getElementById('AddBtn_'+plyId).style.display='none';
//document.getElementById('RemoveBtn_'+plyId).style.display='block';

var teamNameVar = "'"+teamName+"'";
var remTxtBAT5='<i class="materialIcon_10a4f" style="height: 24px; width: 24px; font-size: 24px;" class="fa fa-minus" onclick="removeBatPlyFromList(1,'+plyId+','+creditpoints+','+teamNameVar+');">remove</i>'; 

document.getElementById('remBat_'+plyId).innerHTML=remTxtBAT5;
show_preview(plyname,plyId,plytype,creditpoints,image,teamname);
////////////// for team member /////////////////////  

var tmplayer2=parseInt(tmplayer)+1;

document.getElementById("teamplayercount").value=tmplayer2;

document.getElementById("player_count").innerHTML=tmplayer2;

$('#block'+tmplayer2).removeClass('inactiveStepper_4d390');
$('#block'+tmplayer2).addClass('activeStepper_2007e');
$('#block'+tmplayer2).html(tmplayer2);

///////////////// for for total batsman count ///////////////////

document.getElementById("BAT5").value=plyId;  

var teamBatCount=document.getElementById("teamBatCount").value;

var teamBatCount=parseInt(teamBatCount)+1;

document.getElementById("teamBatCount").value=teamBatCount; 

document.getElementById("countBatNo").innerHTML=teamBatCount; 

/////////////////// for credit points //////////////

var totalcreditCount=document.getElementById("totalcreditCount").value;

var totalcreditCount2 = parseFloat(totalcreditCount)-parseFloat(creditpoints);

document.getElementById('totalcreditCountShow').innerHTML=totalcreditCount2;

document.getElementById("totalcreditCount").value=totalcreditCount2; 

  //////////////// code for count player in team //////
  var team_first_cnt=document.getElementById("team_first_cnt").value;
  var team_second_cnt=document.getElementById("team_second_cnt").value;
  var FirstTeamName=document.getElementById("FirstTeamName").value;
  var SecondTeamName=document.getElementById("SecondTeamName").value;
  if(teamName==FirstTeamName)
  {
  team_first_cnt=document.getElementById("team_first_cnt").value;
  var plus1firstTeam=parseInt(team_first_cnt)+1;
  document.getElementById("team_first_cnt").value=plus1firstTeam;
  document.getElementById('team_first_cnt_show').innerHTML=plus1firstTeam;
  }else if(teamName==SecondTeamName)
  { 
  var team_second_cnt=document.getElementById("team_second_cnt").value;
  var plus1secondTeam=parseInt(team_second_cnt)+1;
  document.getElementById("team_second_cnt").value=plus1secondTeam;
  document.getElementById('team_second_cnt_show').innerHTML=plus1secondTeam;
  } else {
  }
  //////////////// code for count player in team //////


}  else { 

        //alert('you have not sufficent credit points...');

    var $div2=$("#DivErrorTxtMessage");

    if($div2.is(":visible")) { return; }

    document.getElementById("errorTxtMessage").innerHTML="You have not sufficent credit points.";

    $div2.show();

    setTimeout(function() { $div2.hide();}, 2000); 

}

}

//////////////////////// for BAT //////////





//////////////////////// for AR //////////

if(plytype=='AR')

{

var ar1=document.getElementById('AR1').value;

var ar2=document.getElementById('AR2').value;

var ar3=document.getElementById('AR3').value;

var totalcreditCount=document.getElementById("totalcreditCount").value;



if(ar1=='' && ( parseFloat(creditpoints) <= parseFloat(totalcreditCount)))

{

document.getElementById('arbg_'+plyId).style.backgroundColor='rgb(254, 255, 209)';

document.getElementById('AR1').value=plyId;

document.getElementById('AddBtn_'+plyId).style.display='none';
//document.getElementById('RemoveBtn_'+plyId).style.display='block';

var teamNameVar = "'"+teamName+"'";
var remTxtAR1='<i class="materialIcon_10a4f" style="height: 24px; width: 24px; font-size: 24px;" class="fa fa-minus" onclick="removeArPlyFromList(1,'+plyId+','+creditpoints+','+teamNameVar+');">remove</i>'; 

document.getElementById('remAr_'+plyId).innerHTML=remTxtAR1;
show_preview(plyname,plyId,plytype,creditpoints,image,teamname);
////////////// for team member /////////////////////  

var tmplayer2=parseInt(tmplayer)+1;

document.getElementById("teamplayercount").value=tmplayer2;

document.getElementById("player_count").innerHTML=tmplayer2;

$('#block'+tmplayer2).removeClass('inactiveStepper_4d390');
$('#block'+tmplayer2).addClass('activeStepper_2007e');
$('#block'+tmplayer2).html(tmplayer2);

///////////////// for for total batsman count ///////////////////

document.getElementById("AR1").value=plyId; 

var teamArCount=document.getElementById("teamArCount").value;

teamArCount=parseInt(teamArCount)+1;

document.getElementById("teamArCount").value=teamArCount; 

document.getElementById("countArNo").innerHTML=teamArCount; 

/////////////////// for credit points //////////////

var totalcreditCount=document.getElementById("totalcreditCount").value;

var totalcreditCount2 = parseFloat(totalcreditCount)-parseFloat(creditpoints);

document.getElementById('totalcreditCountShow').innerHTML=totalcreditCount2;

document.getElementById("totalcreditCount").value=totalcreditCount2; 

  //////////////// code for count player in team //////
  var team_first_cnt=document.getElementById("team_first_cnt").value;
  var team_second_cnt=document.getElementById("team_second_cnt").value;
  var FirstTeamName=document.getElementById("FirstTeamName").value;
  var SecondTeamName=document.getElementById("SecondTeamName").value;
  if(teamName==FirstTeamName)
  {
  team_first_cnt=document.getElementById("team_first_cnt").value;
  var plus1firstTeam=parseInt(team_first_cnt)+1;
  document.getElementById("team_first_cnt").value=plus1firstTeam;
  document.getElementById('team_first_cnt_show').innerHTML=plus1firstTeam;
  }else if(teamName==SecondTeamName)
  { 
  var team_second_cnt=document.getElementById("team_second_cnt").value;
  var plus1secondTeam=parseInt(team_second_cnt)+1;
  document.getElementById("team_second_cnt").value=plus1secondTeam;
  document.getElementById('team_second_cnt_show').innerHTML=plus1secondTeam;
  } else {
  }
  //////////////// code for count player in team //////


} 

else if(ar2=='' && ( parseFloat(creditpoints) <= parseFloat(totalcreditCount))) 

{

document.getElementById('arbg_'+plyId).style.backgroundColor='rgb(254, 255, 209)';

document.getElementById('AR2').value=plyId;

document.getElementById('AddBtn_'+plyId).style.display='none';
//document.getElementById('RemoveBtn_'+plyId).style.display='block';

var teamNameVar = "'"+teamName+"'";
var remTxtAr2='<i class="materialIcon_10a4f" style="height: 24px; width: 24px; font-size: 24px;" class="fa fa-minus" onclick="removeArPlyFromList(2,'+plyId+','+creditpoints+','+teamNameVar+');">remove</i>'; 

document.getElementById('remAr_'+plyId).innerHTML=remTxtAr2;
show_preview(plyname,plyId,plytype,creditpoints,image,teamname);
////////////// for team member /////////////////////  

var tmplayer2=parseInt(tmplayer)+1;

document.getElementById("teamplayercount").value=tmplayer2;

document.getElementById("player_count").innerHTML=tmplayer2;

$('#block'+tmplayer2).removeClass('inactiveStepper_4d390');
$('#block'+tmplayer2).addClass('activeStepper_2007e');
$('#block'+tmplayer2).html(tmplayer2);
///////////////// for for total batsman count ///////////////////

document.getElementById("AR2").value=plyId; 

var teamArCount=document.getElementById("teamArCount").value;

teamArCount=parseInt(teamArCount)+1;

document.getElementById("teamArCount").value=teamArCount; 

document.getElementById("countArNo").innerHTML=teamArCount; 

/////////////////// for credit points //////////////

var totalcreditCount=document.getElementById("totalcreditCount").value;

var totalcreditCount2 = parseFloat(totalcreditCount)-parseFloat(creditpoints);

document.getElementById('totalcreditCountShow').innerHTML=totalcreditCount2;

document.getElementById("totalcreditCount").value=totalcreditCount2; 

  //////////////// code for count player in team //////
  var team_first_cnt=document.getElementById("team_first_cnt").value;
  var team_second_cnt=document.getElementById("team_second_cnt").value;
  var FirstTeamName=document.getElementById("FirstTeamName").value;
  var SecondTeamName=document.getElementById("SecondTeamName").value;
  if(teamName==FirstTeamName)
  {
  team_first_cnt=document.getElementById("team_first_cnt").value;
  var plus1firstTeam=parseInt(team_first_cnt)+1;
  document.getElementById("team_first_cnt").value=plus1firstTeam;
  document.getElementById('team_first_cnt_show').innerHTML=plus1firstTeam;
  }else if(teamName==SecondTeamName)
  { 
  var team_second_cnt=document.getElementById("team_second_cnt").value;
  var plus1secondTeam=parseInt(team_second_cnt)+1;
  document.getElementById("team_second_cnt").value=plus1secondTeam;
  document.getElementById('team_second_cnt_show').innerHTML=plus1secondTeam;
  } else {
  }
  //////////////// code for count player in team //////



} 

else if(ar3=='' && ( parseFloat(creditpoints) <= parseFloat(totalcreditCount))) 

{

document.getElementById('arbg_'+plyId).style.backgroundColor='rgb(254, 255, 209)';

document.getElementById('AR3').value=plyId;

document.getElementById('AddBtn_'+plyId).style.display='none';
//document.getElementById('RemoveBtn_'+plyId).style.display='block';

var teamNameVar = "'"+teamName+"'";
var remTxtAr3='<i class="materialIcon_10a4f" style="height: 24px; width: 24px; font-size: 24px;" class="fa fa-minus" onclick="removeArPlyFromList(3,'+plyId+','+creditpoints+','+teamNameVar+');">remove</i>'; 

document.getElementById('remAr_'+plyId).innerHTML=remTxtAr3;
show_preview(plyname,plyId,plytype,creditpoints,image,teamname);
////////////// for team member /////////////////////  

var tmplayer2=parseInt(tmplayer)+1;

document.getElementById("teamplayercount").value=tmplayer2;

document.getElementById("player_count").innerHTML=tmplayer2;

$('#block'+tmplayer2).removeClass('inactiveStepper_4d390');
$('#block'+tmplayer2).addClass('activeStepper_2007e');
$('#block'+tmplayer2).html(tmplayer2);

///////////////// for for total batsman count ///////////////////

document.getElementById("AR3").value=plyId; 

var teamArCount=document.getElementById("teamArCount").value;

teamArCount=parseInt(teamArCount)+1;

document.getElementById("teamArCount").value=teamArCount; 

document.getElementById("countArNo").innerHTML=teamArCount; 

/////////////////// for credit points //////////////

var totalcreditCount=document.getElementById("totalcreditCount").value;

var totalcreditCount2 = parseFloat(totalcreditCount)-parseFloat(creditpoints);

document.getElementById('totalcreditCountShow').innerHTML=totalcreditCount2;

document.getElementById("totalcreditCount").value=totalcreditCount2; 

  //////////////// code for count player in team //////
  var team_first_cnt=document.getElementById("team_first_cnt").value;
  var team_second_cnt=document.getElementById("team_second_cnt").value;
  var FirstTeamName=document.getElementById("FirstTeamName").value;
  var SecondTeamName=document.getElementById("SecondTeamName").value;
  if(teamName==FirstTeamName)
  {
  team_first_cnt=document.getElementById("team_first_cnt").value;
  var plus1firstTeam=parseInt(team_first_cnt)+1;
  document.getElementById("team_first_cnt").value=plus1firstTeam;
  document.getElementById('team_first_cnt_show').innerHTML=plus1firstTeam;
  }else if(teamName==SecondTeamName)
  { 
  var team_second_cnt=document.getElementById("team_second_cnt").value;
  var plus1secondTeam=parseInt(team_second_cnt)+1;
  document.getElementById("team_second_cnt").value=plus1secondTeam;
  document.getElementById('team_second_cnt_show').innerHTML=plus1secondTeam;
  } else {
  }
  //////////////// code for count player in team //////



} else {

       //alert('you have not sufficent credit points...');

      var $div2=$("#DivErrorTxtMessage");

    if($div2.is(":visible")) { return; }

    document.getElementById("errorTxtMessage").innerHTML="You have not sufficent credit points.";

    $div2.show();

    setTimeout(function() { $div2.hide();}, 2000); 

}

}

//////////////////////// for AR //////////



/////////////////////// for BOWL //////////

if(plytype=='BOWL')

{

var bwl1=document.getElementById('BWL1').value; 

var bwl2=document.getElementById('BWL2').value;

var bwl3=document.getElementById('BWL3').value;

var bwl4=document.getElementById('BWL4').value;

var bwl5=document.getElementById('BWL5').value;

var totalcreditCount=document.getElementById("totalcreditCount").value;

if(bwl1=='' && ( parseFloat(creditpoints) <= parseFloat(totalcreditCount)))

{

document.getElementById('bwlbg_'+plyId).style.backgroundColor='rgb(254, 255, 209)';

document.getElementById('BWL1').value=plyId;

document.getElementById('AddBtn_'+plyId).style.display='none';
//document.getElementById('RemoveBtn_'+plyId).style.display='block';
show_preview(plyname,plyId,plytype,creditpoints,image,teamname);

var teamNameVar = "'"+teamName+"'";
var remTxtBwl1='<i class="materialIcon_10a4f" style="height: 24px; width: 24px; font-size: 24px;" class="fa fa-minus" onclick="removeBwlPlyFromList(1,'+plyId+','+creditpoints+','+teamNameVar+');">remove</i>'; 

document.getElementById('remBwl_'+plyId).innerHTML=remTxtBwl1;

////////////// for team member /////////////////////  

var tmplayer2=parseInt(tmplayer)+1;

document.getElementById("teamplayercount").value=tmplayer2;

document.getElementById("player_count").innerHTML=tmplayer2;

$('#block'+tmplayer2).removeClass('inactiveStepper_4d390');
$('#block'+tmplayer2).addClass('activeStepper_2007e');
$('#block'+tmplayer2).html(tmplayer2);

///////////////// for for total batsman count ///////////////////

document.getElementById("BWL1").value=plyId;  

var teamBwlCount=document.getElementById("teamBwlCount").value;

teamBwlCount=parseInt(teamBwlCount)+1;

document.getElementById("teamBwlCount").value=teamBwlCount; 

document.getElementById("countBwlNo").innerHTML=teamBwlCount; 

/////////////////// for credit points //////////////

var totalcreditCount=document.getElementById("totalcreditCount").value;

var totalcreditCount2 = parseFloat(totalcreditCount)-parseFloat(creditpoints);

document.getElementById('totalcreditCountShow').innerHTML=totalcreditCount2;

document.getElementById("totalcreditCount").value=totalcreditCount2;

  //////////////// code for count player in team //////
  var team_first_cnt=document.getElementById("team_first_cnt").value;
  var team_second_cnt=document.getElementById("team_second_cnt").value;
  var FirstTeamName=document.getElementById("FirstTeamName").value;
  var SecondTeamName=document.getElementById("SecondTeamName").value;
  if(teamName==FirstTeamName)
  {
  team_first_cnt=document.getElementById("team_first_cnt").value;
  var plus1firstTeam=parseInt(team_first_cnt)+1;
  document.getElementById("team_first_cnt").value=plus1firstTeam;
  document.getElementById('team_first_cnt_show').innerHTML=plus1firstTeam;
  }else if(teamName==SecondTeamName)
  { 
  var team_second_cnt=document.getElementById("team_second_cnt").value;
  var plus1secondTeam=parseInt(team_second_cnt)+1;
  document.getElementById("team_second_cnt").value=plus1secondTeam;
  document.getElementById('team_second_cnt_show').innerHTML=plus1secondTeam;
  } else {
  }
  //////////////// code for count player in team //////



} 

else if(bwl2=='' && ( parseFloat(creditpoints) <= parseFloat(totalcreditCount))) 

{

document.getElementById('bwlbg_'+plyId).style.backgroundColor='rgb(254, 255, 209)';

document.getElementById('BWL2').value=plyId;

document.getElementById('AddBtn_'+plyId).style.display='none';
//document.getElementById('RemoveBtn_'+plyId).style.display='block';
var teamNameVar = "'"+teamName+"'";
var remTxtBwl2='<i class="materialIcon_10a4f" style="height: 24px; width: 24px; font-size: 24px;" class="fa fa-minus" onclick="removeBwlPlyFromList(2,'+plyId+','+creditpoints+','+teamNameVar+');">remove</i>'; 

document.getElementById('remBwl_'+plyId).innerHTML=remTxtBwl2;
show_preview(plyname,plyId,plytype,creditpoints,image,teamname);
////////////// for team member /////////////////////  

var tmplayer2=parseInt(tmplayer)+1;

document.getElementById("teamplayercount").value=tmplayer2;

document.getElementById("player_count").innerHTML=tmplayer2;

$('#block'+tmplayer2).removeClass('inactiveStepper_4d390');
$('#block'+tmplayer2).addClass('activeStepper_2007e');
$('#block'+tmplayer2).html(tmplayer2);

///////////////// for for total batsman count ///////////////////

document.getElementById("BWL2").value=plyId;  

var teamBwlCount=document.getElementById("teamBwlCount").value;

teamBwlCount=parseInt(teamBwlCount)+1;

document.getElementById("teamBwlCount").value=teamBwlCount; 

document.getElementById("countBwlNo").innerHTML=teamBwlCount; 

/////////////////// for credit points //////////////

var totalcreditCount=document.getElementById("totalcreditCount").value;

var totalcreditCount2 = parseFloat(totalcreditCount)-parseFloat(creditpoints);

document.getElementById('totalcreditCountShow').innerHTML=totalcreditCount2;

document.getElementById("totalcreditCount").value=totalcreditCount2;

  //////////////// code for count player in team //////
  var team_first_cnt=document.getElementById("team_first_cnt").value;
  var team_second_cnt=document.getElementById("team_second_cnt").value;
  var FirstTeamName=document.getElementById("FirstTeamName").value;
  var SecondTeamName=document.getElementById("SecondTeamName").value;
  if(teamName==FirstTeamName)
  {
  team_first_cnt=document.getElementById("team_first_cnt").value;
  var plus1firstTeam=parseInt(team_first_cnt)+1;
  document.getElementById("team_first_cnt").value=plus1firstTeam;
  document.getElementById('team_first_cnt_show').innerHTML=plus1firstTeam;
  }else if(teamName==SecondTeamName)
  { 
  var team_second_cnt=document.getElementById("team_second_cnt").value;
  var plus1secondTeam=parseInt(team_second_cnt)+1;
  document.getElementById("team_second_cnt").value=plus1secondTeam;
  document.getElementById('team_second_cnt_show').innerHTML=plus1secondTeam;
  } else {
  }
  //////////////// code for count player in team //////



} 

else if(bwl3=='' && ( parseFloat(creditpoints) <= parseFloat(totalcreditCount))) 

{

document.getElementById('bwlbg_'+plyId).style.backgroundColor='rgb(254, 255, 209)';

document.getElementById('BWL3').value=plyId;

document.getElementById('AddBtn_'+plyId).style.display='none';
//document.getElementById('RemoveBtn_'+plyId).style.display='block';

var teamNameVar = "'"+teamName+"'";
var remTxtBwl3='<i class="materialIcon_10a4f" style="height: 24px; width: 24px; font-size: 24px;" class="fa fa-minus" onclick="removeBwlPlyFromList(3,'+plyId+','+creditpoints+','+teamNameVar+');">remove</i>'; 

document.getElementById('remBwl_'+plyId).innerHTML=remTxtBwl3;
show_preview(plyname,plyId,plytype,creditpoints,image,teamname);
////////////// for team member /////////////////////  

var tmplayer2=parseInt(tmplayer)+1;

document.getElementById("teamplayercount").value=tmplayer2;

document.getElementById("player_count").innerHTML=tmplayer2;

$('#block'+tmplayer2).removeClass('inactiveStepper_4d390');
$('#block'+tmplayer2).addClass('activeStepper_2007e');
$('#block'+tmplayer2).html(tmplayer2);

///////////////// for for total batsman count ///////////////////

document.getElementById("BWL3").value=plyId;  

var teamBwlCount=document.getElementById("teamBwlCount").value;

teamBwlCount=parseInt(teamBwlCount)+1;

document.getElementById("teamBwlCount").value=teamBwlCount; 

document.getElementById("countBwlNo").innerHTML=teamBwlCount; 

/////////////////// for credit points //////////////

var totalcreditCount=document.getElementById("totalcreditCount").value;

var totalcreditCount2 = parseFloat(totalcreditCount)-parseFloat(creditpoints);

document.getElementById('totalcreditCountShow').innerHTML=totalcreditCount2;

document.getElementById("totalcreditCount").value=totalcreditCount2;

  //////////////// code for count player in team //////
  var team_first_cnt=document.getElementById("team_first_cnt").value;
  var team_second_cnt=document.getElementById("team_second_cnt").value;
  var FirstTeamName=document.getElementById("FirstTeamName").value;
  var SecondTeamName=document.getElementById("SecondTeamName").value;
  if(teamName==FirstTeamName)
  {
  team_first_cnt=document.getElementById("team_first_cnt").value;
  var plus1firstTeam=parseInt(team_first_cnt)+1;
  document.getElementById("team_first_cnt").value=plus1firstTeam;
  document.getElementById('team_first_cnt_show').innerHTML=plus1firstTeam;
  }else if(teamName==SecondTeamName)
  { 
  var team_second_cnt=document.getElementById("team_second_cnt").value;
  var plus1secondTeam=parseInt(team_second_cnt)+1;
  document.getElementById("team_second_cnt").value=plus1secondTeam;
  document.getElementById('team_second_cnt_show').innerHTML=plus1secondTeam;
  } else {
  }
  //////////////// code for count player in team //////



}

else if(bwl4=='' && ( parseFloat(creditpoints) <= parseFloat(totalcreditCount))) 

{

document.getElementById('bwlbg_'+plyId).style.backgroundColor='rgb(254, 255, 209)';

document.getElementById('BWL4').value=plyId;

document.getElementById('AddBtn_'+plyId).style.display='none';
//document.getElementById('RemoveBtn_'+plyId).style.display='block';

var teamNameVar = "'"+teamName+"'";
var remTxtBwl4='<i class="materialIcon_10a4f" style="height: 24px; width: 24px; font-size: 24px;" class="fa fa-minus" onclick="removeBwlPlyFromList(4,'+plyId+','+creditpoints+','+teamNameVar+');">remove</i>'; 

document.getElementById('remBwl_'+plyId).innerHTML=remTxtBwl4;
show_preview(plyname,plyId,plytype,creditpoints,image,teamname);
////////////// for team member /////////////////////  

var tmplayer2=parseInt(tmplayer)+1;

document.getElementById("teamplayercount").value=tmplayer2;

document.getElementById("player_count").innerHTML=tmplayer2;

$('#block'+tmplayer2).removeClass('inactiveStepper_4d390');
$('#block'+tmplayer2).addClass('activeStepper_2007e');
$('#block'+tmplayer2).html(tmplayer2);

///////////////// for for total batsman count ///////////////////

document.getElementById("BWL4").value=plyId;  

var teamBwlCount=document.getElementById("teamBwlCount").value;

teamBwlCount=parseInt(teamBwlCount)+1;

document.getElementById("teamBwlCount").value=teamBwlCount; 

document.getElementById("countBwlNo").innerHTML=teamBwlCount; 

/////////////////// for credit points //////////////

var totalcreditCount=document.getElementById("totalcreditCount").value;

var totalcreditCount2 = parseFloat(totalcreditCount)-parseFloat(creditpoints);

document.getElementById('totalcreditCountShow').innerHTML=totalcreditCount2;

document.getElementById("totalcreditCount").value=totalcreditCount2;

  //////////////// code for count player in team //////
  var team_first_cnt=document.getElementById("team_first_cnt").value;
  var team_second_cnt=document.getElementById("team_second_cnt").value;
  var FirstTeamName=document.getElementById("FirstTeamName").value;
  var SecondTeamName=document.getElementById("SecondTeamName").value;
  if(teamName==FirstTeamName)
  {
  team_first_cnt=document.getElementById("team_first_cnt").value;
  var plus1firstTeam=parseInt(team_first_cnt)+1;
  document.getElementById("team_first_cnt").value=plus1firstTeam;
  document.getElementById('team_first_cnt_show').innerHTML=plus1firstTeam;
  }else if(teamName==SecondTeamName)
  { 
  var team_second_cnt=document.getElementById("team_second_cnt").value;
  var plus1secondTeam=parseInt(team_second_cnt)+1;
  document.getElementById("team_second_cnt").value=plus1secondTeam;
  document.getElementById('team_second_cnt_show').innerHTML=plus1secondTeam;
  } else {
  }
  //////////////// code for count player in team //////



}

else if(bwl5=='' && ( parseFloat(creditpoints) <= parseFloat(totalcreditCount))) 

{

document.getElementById('bwlbg_'+plyId).style.backgroundColor='rgb(254, 255, 209)';

document.getElementById('BWL5').value=plyId;

document.getElementById('AddBtn_'+plyId).style.display='none';
//document.getElementById('RemoveBtn_'+plyId).style.display='block';

var teamNameVar = "'"+teamName+"'";
var remTxtBwl5='<i class="materialIcon_10a4f" style="height: 24px; width: 24px; font-size: 24px;" class="fa fa-minus" onclick="removeBwlPlyFromList(5,'+plyId+','+creditpoints+','+teamNameVar+');">remove</i>'; 

document.getElementById('remBwl_'+plyId).innerHTML=remTxtBwl5;
show_preview(plyname,plyId,plytype,creditpoints,image,teamname);
////////////// for team member /////////////////////  

var tmplayer2=parseInt(tmplayer)+1;

document.getElementById("teamplayercount").value=tmplayer2;

document.getElementById("player_count").innerHTML=tmplayer2;

$('#block'+tmplayer2).removeClass('inactiveStepper_4d390');
$('#block'+tmplayer2).addClass('activeStepper_2007e');
$('#block'+tmplayer2).html(tmplayer2);

///////////////// for for total batsman count ///////////////////

document.getElementById("BWL5").value=plyId;  

var teamBwlCount=document.getElementById("teamBwlCount").value;

teamBwlCount=parseInt(teamBwlCount)+1;

document.getElementById("teamBwlCount").value=teamBwlCount; 

document.getElementById("countBwlNo").innerHTML=teamBwlCount; 

/////////////////// for credit points //////////////

var totalcreditCount=document.getElementById("totalcreditCount").value;

var totalcreditCount2 = parseFloat(totalcreditCount)-parseFloat(creditpoints);

document.getElementById('totalcreditCountShow').innerHTML=totalcreditCount2;

document.getElementById("totalcreditCount").value=totalcreditCount2;

  //////////////// code for count player in team //////
  var team_first_cnt=document.getElementById("team_first_cnt").value;
  var team_second_cnt=document.getElementById("team_second_cnt").value;
  var FirstTeamName=document.getElementById("FirstTeamName").value;
  var SecondTeamName=document.getElementById("SecondTeamName").value;
  if(teamName==FirstTeamName)
  {
  team_first_cnt=document.getElementById("team_first_cnt").value;
  var plus1firstTeam=parseInt(team_first_cnt)+1;
  document.getElementById("team_first_cnt").value=plus1firstTeam;
  document.getElementById('team_first_cnt_show').innerHTML=plus1firstTeam;
  }else if(teamName==SecondTeamName)
  { 
  var team_second_cnt=document.getElementById("team_second_cnt").value;
  var plus1secondTeam=parseInt(team_second_cnt)+1;
  document.getElementById("team_second_cnt").value=plus1secondTeam;
  document.getElementById('team_second_cnt_show').innerHTML=plus1secondTeam;
  } else {
  }
  //////////////// code for count player in team //////



} else {

        //alert('you have not sufficent credit points...');

      var $div2=$("#DivErrorTxtMessage");

    if($div2.is(":visible")) { return; }

    document.getElementById("errorTxtMessage").innerHTML="You have not sufficent credit points.";

    $div2.show();

    setTimeout(function() { $div2.hide();}, 2000); 

}

}

//////////////////////// for BOWL //////////

}

}


/////////////////////////////////////////////////////////////////////
/////////////////////// code for delete wk from list ///////////////

function removePlyFromList(WkFldID,plyId,creditpoints,teamName)

{

document.getElementById("wkbg_"+plyId).style.backgroundColor='#ffffff';

document.getElementById("WK"+WkFldID).value=''; 

document.getElementById('AddBtn_'+plyId).style.display='block';
document.getElementById('RemoveBtn_'+plyId).style.display='none';
//document.getElementById("remWk_"+plyId).innerHTML=''; 

///////////// for teammenber count //////////////////  

var tmplayer=document.getElementById("teamplayercount").value;

var tmplayer2=tmplayer-1;

document.getElementById("teamplayercount").value=tmplayer2;

document.getElementById("player_count").innerHTML=tmplayer2;

$('#block'+tmplayer).addClass('inactiveStepper_4d390');
$('#block'+tmplayer).removeClass('activeStepper_2007e');
$('#block'+tmplayer).html('');

/////////////////// for batman count ////////////// 

var teamWkCount=document.getElementById("teamWkCount").value;

var teamWkCount=parseInt(teamWkCount)-1;

document.getElementById("teamWkCount").value=teamWkCount;

document.getElementById("countWkNo").innerHTML=teamWkCount;
remove_player_preview(plyId,'WK');
/////////////////// for credit points /////////////////

var totalcreditCount=document.getElementById("totalcreditCount").value;

var totalcreditCount2 = parseFloat(totalcreditCount)+parseFloat(creditpoints);

document.getElementById('totalcreditCountShow').innerHTML=totalcreditCount2;

document.getElementById("totalcreditCount").value=totalcreditCount2; 

  //////////////// code for count player in team //////
  var team_first_cnt=document.getElementById("team_first_cnt").value;
  var team_second_cnt=document.getElementById("team_second_cnt").value;
  var FirstTeamName=document.getElementById("FirstTeamName").value;
  var SecondTeamName=document.getElementById("SecondTeamName").value;
  if(teamName==FirstTeamName)
  {
  team_first_cnt=document.getElementById("team_first_cnt").value;
  var plus1firstTeam=parseInt(team_first_cnt)-1;
  document.getElementById("team_first_cnt").value=plus1firstTeam;
  document.getElementById('team_first_cnt_show').innerHTML=plus1firstTeam;
  }else if(teamName==SecondTeamName)
  { 
  var team_second_cnt=document.getElementById("team_second_cnt").value;
  var plus1secondTeam=parseInt(team_second_cnt)-1;
  document.getElementById("team_second_cnt").value=plus1secondTeam;
  document.getElementById('team_second_cnt_show').innerHTML=plus1secondTeam;
  } else {
  }
  //////////////// code for count player in team //////


}

/////////////////////// code for delete wk from list ///////////////


/////////////////////////////////////////////////////////////////////
/////////////////////// code for delete bat from list ///////////////

function removeBatPlyFromList(BatFldID,plyId,creditpoints,teamName)

{ 
	
document.getElementById("batbg_"+plyId).style.backgroundColor='#ffffff';

document.getElementById("BAT"+BatFldID).value=''; 

document.getElementById('AddBtn_'+plyId).style.display='block';

//document.getElementById('RemoveBtn_'+plyId).style.display='none';

document.getElementById("remBat_"+plyId).innerHTML='';  
remove_player_preview(plyId,'BAT');
///////////// for teammenber count //////////////////  

var tmplayer=document.getElementById("teamplayercount").value;

var tmplayer2=tmplayer-1;

document.getElementById("teamplayercount").value=tmplayer2;

document.getElementById("player_count").innerHTML=tmplayer2;

$('#block'+tmplayer).addClass('inactiveStepper_4d390');
$('#block'+tmplayer).removeClass('activeStepper_2007e');
$('#block'+tmplayer).html('');

/////////////////// for batman count ////////////// 

var teamBatCount=document.getElementById("teamBatCount").value;

var teamBatCount=parseInt(teamBatCount)-1;

document.getElementById("teamBatCount").value=teamBatCount;

document.getElementById("countBatNo").innerHTML=teamBatCount;

/////////////////// for credit points /////////////////

var totalcreditCount=document.getElementById("totalcreditCount").value;

var totalcreditCount2 = parseFloat(totalcreditCount)+parseFloat(creditpoints);

document.getElementById('totalcreditCountShow').innerHTML=totalcreditCount2;

document.getElementById("totalcreditCount").value=totalcreditCount2; 

  //////////////// code for count player in team //////
  var team_first_cnt=document.getElementById("team_first_cnt").value;
  var team_second_cnt=document.getElementById("team_second_cnt").value;
  var FirstTeamName=document.getElementById("FirstTeamName").value;
  var SecondTeamName=document.getElementById("SecondTeamName").value;
  if(teamName==FirstTeamName)
  {
  team_first_cnt=document.getElementById("team_first_cnt").value;
  var plus1firstTeam=parseInt(team_first_cnt)-1;
  document.getElementById("team_first_cnt").value=plus1firstTeam;
  document.getElementById('team_first_cnt_show').innerHTML=plus1firstTeam;
  }else if(teamName==SecondTeamName)
  { 
  var team_second_cnt=document.getElementById("team_second_cnt").value;
  var plus1secondTeam=parseInt(team_second_cnt)-1;
  document.getElementById("team_second_cnt").value=plus1secondTeam;
  document.getElementById('team_second_cnt_show').innerHTML=plus1secondTeam;
  } else {
  }
  //////////////// code for count player in team //////
}
/////////////////////// code for delete bat from list ///////////////



/////////////////////// code for delete ar from list ///////////////



function removeArPlyFromList(ArFldID,plyId,creditpoints,teamName)

{ 

document.getElementById("arbg_"+plyId).style.backgroundColor='#ffffff';

document.getElementById("AR"+ArFldID).value=''; 

document.getElementById('AddBtn_'+plyId).style.display='block';

//document.getElementById('RemoveBtn_'+plyId).style.display='none';

document.getElementById("remAr_"+plyId).innerHTML=''; 
remove_player_preview(plyId,'AR');
///////////// for teammenber count //////////////////  

var tmplayer=document.getElementById("teamplayercount").value;

var tmplayer2=tmplayer-1;

document.getElementById("teamplayercount").value=tmplayer2;

document.getElementById("player_count").innerHTML=tmplayer2;

$('#block'+tmplayer).addClass('inactiveStepper_4d390');
$('#block'+tmplayer).removeClass('activeStepper_2007e');
$('#block'+tmplayer).html('');

/////////////////// for batman count ////////////// 

var teamArCount=document.getElementById("teamArCount").value;

var teamArCount=parseInt(teamArCount)-1;

document.getElementById("teamArCount").value=teamArCount;

document.getElementById("countArNo").innerHTML=teamArCount;

/////////////////// for credit points /////////////////

var totalcreditCount=document.getElementById("totalcreditCount").value;

var totalcreditCount2 = parseFloat(totalcreditCount)+parseFloat(creditpoints);

document.getElementById('totalcreditCountShow').innerHTML=totalcreditCount2;

document.getElementById("totalcreditCount").value=totalcreditCount2;    

  //////////////// code for count player in team //////
  var team_first_cnt=document.getElementById("team_first_cnt").value;
  var team_second_cnt=document.getElementById("team_second_cnt").value;
  var FirstTeamName=document.getElementById("FirstTeamName").value;
  var SecondTeamName=document.getElementById("SecondTeamName").value;
  if(teamName==FirstTeamName)
  {
  team_first_cnt=document.getElementById("team_first_cnt").value;
  var plus1firstTeam=parseInt(team_first_cnt)-1;
  document.getElementById("team_first_cnt").value=plus1firstTeam;
  document.getElementById('team_first_cnt_show').innerHTML=plus1firstTeam;
  }else if(teamName==SecondTeamName)
  { 
  var team_second_cnt=document.getElementById("team_second_cnt").value;
  var plus1secondTeam=parseInt(team_second_cnt)-1;
  document.getElementById("team_second_cnt").value=plus1secondTeam;
  document.getElementById('team_second_cnt_show').innerHTML=plus1secondTeam;
  } else {
  }
  //////////////// code for count player in team //////
}

/////////////////////// code for delete ar from list ///////////////

/////////////////////// code for delete bwl from list ///////////////



function removeBwlPlyFromList(BwlFldID,plyId,creditpoints,teamName)

{

document.getElementById("bwlbg_"+plyId).style.backgroundColor='#ffffff';

document.getElementById("BWL"+BwlFldID).value=''; 

document.getElementById('AddBtn_'+plyId).style.display='block';
//document.getElementById('RemoveBtn_'+plyId).style.display='none';

document.getElementById("remBwl_"+plyId).innerHTML='';  
remove_player_preview(plyId,'BOWL');
///////////// for teammenber count //////////////////  

var tmplayer=document.getElementById("teamplayercount").value;

var tmplayer2=tmplayer-1;

document.getElementById("teamplayercount").value=tmplayer2;

document.getElementById("player_count").innerHTML=tmplayer2;

$('#block'+tmplayer).addClass('inactiveStepper_4d390');
$('#block'+tmplayer).removeClass('activeStepper_2007e');
$('#block'+tmplayer).html('');

/////////////////// for batman count ////////////// 

var teamBwlCount=document.getElementById("teamBwlCount").value;

var teamBwlCount=parseInt(teamBwlCount)-1;

document.getElementById("teamBwlCount").value=teamBwlCount;

document.getElementById("countBwlNo").innerHTML=teamBwlCount;

/////////////////// for credit points /////////////////

var totalcreditCount=document.getElementById("totalcreditCount").value;

var totalcreditCount2 = parseFloat(totalcreditCount)+parseFloat(creditpoints);

document.getElementById('totalcreditCountShow').innerHTML=totalcreditCount2;

document.getElementById("totalcreditCount").value=totalcreditCount2;      

  //////////////// code for count player in team //////
  var team_first_cnt=document.getElementById("team_first_cnt").value;
  var team_second_cnt=document.getElementById("team_second_cnt").value;
  var FirstTeamName=document.getElementById("FirstTeamName").value;
  var SecondTeamName=document.getElementById("SecondTeamName").value;
  if(teamName==FirstTeamName)
  {
  team_first_cnt=document.getElementById("team_first_cnt").value;
  var plus1firstTeam=parseInt(team_first_cnt)-1;
  document.getElementById("team_first_cnt").value=plus1firstTeam;
  document.getElementById('team_first_cnt_show').innerHTML=plus1firstTeam;
  }else if(teamName==SecondTeamName)
  { 
  var team_second_cnt=document.getElementById("team_second_cnt").value;
  var plus1secondTeam=parseInt(team_second_cnt)-1;
  document.getElementById("team_second_cnt").value=plus1secondTeam;
  document.getElementById('team_second_cnt_show').innerHTML=plus1secondTeam;
  } else {
  }
  //////////////// code for count player in team //////
}

/////////////////////// code for delete bwl from list ///////////////

 function validCount10( TotalCount,plytype){
  var result = 0;
        if (TotalCount==10) {
      var teamBatCount=document.getElementById("teamBatCount").value;
      var teamBwlCount=document.getElementById("teamBwlCount").value;
      var teamWkCount=document.getElementById("teamWkCount").value;
      var teamArCount=document.getElementById("teamArCount").value;


            if (plytype=="WK") {
                if (teamBatCount < 3&&teamArCount < 1&&teamBwlCount < 3) {

                    if (teamArCount<1){
            var $div2=$("#DivErrorTxtMessage");
              if($div2.is(":visible")) { return; }
              document.getElementById("errorTxtMessage").innerHTML="All Rounder Should be 1-3";
              $div2.show();
              setTimeout(function() { $div2.hide();}, 2000); 
                        
                        result = 2;
                    }
                    else if (teamBatCount<3){
            var $div2=$("#DivErrorTxtMessage");
              if($div2.is(":visible")) { return; }
              document.getElementById("errorTxtMessage").innerHTML="Batsman Should be 3-5";
              $div2.show();
              setTimeout(function() { $div2.hide();}, 2000); 
                        result = 2;
                    }
                    else if (teamBwlCount<3){
            var $div2=$("#DivErrorTxtMessage");
              if($div2.is(":visible")) { return; }
              document.getElementById("errorTxtMessage").innerHTML="Bowler Should be 3-5";
              $div2.show();
              setTimeout(function() { $div2.hide();}, 2000); 
                        
                       result = 2;
                    }
                    else {
                        
                    }

                }else

                {
                    
                }
            } else if (plytype=="BAT") {

                if (teamArCount < 1||teamWkCount < 1||teamBwlCount < 3) {


                    if (teamArCount<1){
            var $div2=$("#DivErrorTxtMessage");
              if($div2.is(":visible")) { return; }
              document.getElementById("errorTxtMessage").innerHTML="All Rounder Should be 1-3";
              $div2.show();
              setTimeout(function() { $div2.hide();}, 2000);
                       result = 2;
                    }
                    else if (teamWkCount<1){
            var $div2=$("#DivErrorTxtMessage");
              if($div2.is(":visible")) { return; }
              document.getElementById("errorTxtMessage").innerHTML="Wicket Keeper Should be 1";
              $div2.show();
              setTimeout(function() { $div2.hide();}, 2000); 
                        result = 2;
                    }
                    else if (teamBwlCount<3){
            var $div2=$("#DivErrorTxtMessage");
              if($div2.is(":visible")) { return; }
              document.getElementById("errorTxtMessage").innerHTML="Bowler Should be 3-5";
              $div2.show();
              setTimeout(function() { $div2.hide();}, 2000); 
                        result = 2;
                    }
                    else {
                        
                    }

                }else

                {
                   
                }
            } else if (plytype=="AR") {
                if (teamBatCount < 3||teamWkCount < 1||teamBwlCount < 3) {

                    if (teamBatCount<3){
            var $div2=$("#DivErrorTxtMessage");
              if($div2.is(":visible")) { return; }
              document.getElementById("errorTxtMessage").innerHTML="Batsman Should be 3-5";
              $div2.show();
              setTimeout(function() { $div2.hide();}, 2000); 
                       result = 2;
                    }
                    else if (teamWkCount<1){
            var $div2=$("#DivErrorTxtMessage");
              if($div2.is(":visible")) { return; }
              document.getElementById("errorTxtMessage").innerHTML="Wicket Keeper Should be 1";
              $div2.show();
              setTimeout(function() { $div2.hide();}, 2000); 
                        result = 2;
                    }
                    else if (teamBwlCount<3){
            var $div2=$("#DivErrorTxtMessage");
              if($div2.is(":visible")) { return; }
              document.getElementById("errorTxtMessage").innerHTML="Bowler Should be 3-5";
              $div2.show();
              setTimeout(function() { $div2.hide();}, 2000); 
                        result = 2;
                    }
                    else {
                        
                    }


                }else

                {
                    
                }
            } else {
                if (teamBatCount<3||teamWkCount<1||teamArCount<1) {

                    if (teamBatCount<3){
            var $div2=$("#DivErrorTxtMessage");
              if($div2.is(":visible")) { return; }
              document.getElementById("errorTxtMessage").innerHTML="Batsman Should be 3-5";
              $div2.show();
              setTimeout(function() { $div2.hide();}, 2000); 
                        result = 2;
                    }
                    else if (teamWkCount<1){
            var $div2=$("#DivErrorTxtMessage");
              if($div2.is(":visible")) { return; }
              document.getElementById("errorTxtMessage").innerHTML="Wicket Keeper Should be 1";
              $div2.show();
              setTimeout(function() { $div2.hide();}, 2000); 
                        result = 2;
                    }
                    else if (teamArCount<1){
            var $div2=$("#DivErrorTxtMessage");
              if($div2.is(":visible")) { return; }
              document.getElementById("errorTxtMessage").innerHTML="All Rounder Should be 1-3";
              $div2.show();
              setTimeout(function() { $div2.hide();}, 2000); 
                        result = 2;
                    }
                    else {
                        
                    }


                }else {
                    
                }
            }

        }
        return result;

    }


function count7players(teamName){

   //////////////// code for count player in team //////
  var team_first_cnt=document.getElementById("team_first_cnt").value;
  var team_second_cnt=document.getElementById("team_second_cnt").value;
  var FirstTeamName=document.getElementById("FirstTeamName").value;
  var SecondTeamName=document.getElementById("SecondTeamName").value;
  var result = 0;
  if(teamName==FirstTeamName)
  {

  team_first_cnt=document.getElementById("team_first_cnt").value;
  var plus1firstTeam=parseInt(team_first_cnt)+1;
      if(plus1firstTeam>7){
            var $div2=$("#DivErrorTxtMessage");
        if($div2.is(":visible")) { return; }
        document.getElementById("errorTxtMessage").innerHTML="Max can we 7 players allowed from one Team.";
        $div2.show();
        setTimeout(function() { $div2.hide();}, 2000); 
            result = 2;
      }
      
  }else if(teamName==SecondTeamName)
  { 

  var team_second_cnt=document.getElementById("team_second_cnt").value;
  var plus1secondTeam=parseInt(team_second_cnt)+1;
  if(plus1secondTeam>7){
            var $div2=$("#DivErrorTxtMessage");
        if($div2.is(":visible")) { return; }
        document.getElementById("errorTxtMessage").innerHTML="Max can we 7 players allowed from one Team.";
        $div2.show();
        setTimeout(function() { $div2.hide();}, 2000); 
            result = 2;
      }
    
  } else {
    result = 2;
  }
  return result;
}

  function maxLimitValidation(plytype,TotalCount) {
    var result = 0;
      var teamBatCount=document.getElementById("teamBatCount").value;
      var teamBwlCount=document.getElementById("teamBwlCount").value;
      var teamWkCount=document.getElementById("teamWkCount").value;
      var teamArCount=document.getElementById("teamArCount").value;

        if (plytype=="BAT") {

            if (teamBatCount == 4 && teamBwlCount == 5) {

                if (teamWkCount < 1) {
                    var $div2=$("#DivErrorTxtMessage");
              if($div2.is(":visible")) { return; }
              document.getElementById("errorTxtMessage").innerHTML="Wicket Keeper Should be 1";
              $div2.show();
              setTimeout(function() { $div2.hide();}, 2000); 
                    result = 2;
                } else if (teamArCount < 1) {
                   var $div2=$("#DivErrorTxtMessage");
              if($div2.is(":visible")) { return; }
              document.getElementById("errorTxtMessage").innerHTML="All Rounder Should be 1-3";
              $div2.show();
              setTimeout(function() { $div2.hide();}, 2000); 
                    result = 2;
                }
                else {
                    
                }

            } else if (teamBatCount == 4 && teamArCount == 3) {

                var $div2=$("#DivErrorTxtMessage");
              if($div2.is(":visible")) { return; }
              document.getElementById("errorTxtMessage").innerHTML="Batsman Should be 3-5";
              $div2.show();
              setTimeout(function() { $div2.hide();}, 2000); 
                result = 2;

            } else {

                

            }

        }
        else if (plytype=="BOWL") {

            if (teamBatCount == 5 && teamBwlCount == 4) {
                if (teamWkCount < 1) {
                    var $div2=$("#DivErrorTxtMessage");
              if($div2.is(":visible")) { return; }
              document.getElementById("errorTxtMessage").innerHTML="Wicket Keeper Should be 1";
              $div2.show();
              setTimeout(function() { $div2.hide();}, 2000); 
                    result = 2;
                } else if (teamArCount < 1) {
                    var $div2=$("#DivErrorTxtMessage");
              if($div2.is(":visible")) { return; }
              document.getElementById("errorTxtMessage").innerHTML="All Rounder Should be 1-3";
              $div2.show();
              setTimeout(function() { $div2.hide();}, 2000); 
                    result = 2;
                }
                else {
                    
                }



            } else if (teamBwlCount == 4 && teamArCount == 3) {
                var $div2=$("#DivErrorTxtMessage");
              if($div2.is(":visible")) { return; }
              document.getElementById("errorTxtMessage").innerHTML="Bowler Should be 3-5";
              $div2.show();
              setTimeout(function() { $div2.hide();}, 2000); 
                result = 2;
            } else {
                
            }

        } else if (plytype=="AR") {
            if (teamBwlCount == 5 && teamArCount == 2) {
                var $div2=$("#DivErrorTxtMessage");
              if($div2.is(":visible")) { return; }
              document.getElementById("errorTxtMessage").innerHTML="Batsman Should be 3-5";
              $div2.show();
              setTimeout(function() { $div2.hide();}, 2000); 
                result = 2;
            } else if (teamBatCount == 5 && teamArCount == 2) {
                var $div2=$("#DivErrorTxtMessage");
              if($div2.is(":visible")) { return; }
              document.getElementById("errorTxtMessage").innerHTML="Bowler Should be 3-5";
              $div2.show();
              setTimeout(function() { $div2.hide();}, 2000); 
                result = 2;
            } else

            {
                
            }


        } else {
            
        }
    return result;

    }

     function show_preview(plyname,plyId,plytype,creditpoints,image,teamname)
     {      
     	//alert(image);
        document.getElementById('no_players').style.display='none';
        document.getElementById('show_teams').style.display='block';
        var FirstTeamName=document.getElementById("FirstTeamName").value;
        if(teamname != FirstTeamName){
          $style = "background-color: rgb(55, 89, 165);";
        }else{
          $style = "background-color: rgb(196, 63, 45);";
        }
        $html = '<div class="spaceAround_64779 rowContent_8aa5f" id="playerPreview'+plytype+plyId+'"><div class="js--field-player fieldPlayerMain_32975"><div><div class="playerImageProfile_0cc1f"><div class="imageProfileContainer_6e52e"><div class="player-image-profile__image" style="background-image:url('+image+');" ></div></div></div></div><div class="fieldPlayerTitle_4ac32" style="'+$style+'">'+plyname+'</div><div class="playerPoints_d4e06">'+creditpoints+' Cr</div></div></div>';      
          if(plytype == 'WK'){
            $('#WkTeamPreview').append($html);
          }
          else if(plytype == 'AR'){
            $('#ArTeamPreview').append($html);
          }
          else if(plytype == 'BOWL'){
            $('#BwlTeamPreview').append($html);
          }
          else if(plytype == 'BAT'){
            $('#BatTeamPreview').append($html);
          }else{

          }
          return true;
      }

      function remove_player_preview(plyId,plytype)
      {
        $('#playerPreview'+plytype+plyId).remove();
      }


      var  array  =<?php echo json_encode($selected_players);?>;
      	var length  = array.length;
      	for (var i = 0 ; i < length ; i++) {
      		show_preview(array[i]['name'],array[i]['id'],array[i]['short_term'],array[i]['credit_points'],"<?php echo base_url('uploads/player/')?>" +array[i]['image'],array[i]['team_short_name']);
      	}

</script>
</body>

</html>