      <style>


@media screen and (min-width: 400px) {
  .appBgImage_fd065 {
    display: none;
   
   }

   .appContainer_6475d {
    max-width: 960px!important;
    height: 100%;
}

  .appToolbar_1ea26 {
    max-width: 100%!important;
    left: 0;
    top: 0;
    width: 100%;
    position: fixed;
    box-shadow: 0px 1px 4px 0px rgba(0, 0, 0, 0.3);
    z-index: 2;
  }

  .matchListContainer_ca5d2 {
    display: flex;
    flex-direction: column;
    max-width: 36%!important;
    -webkit-overflow-scrolling: touch;
    width: 100%;
    height: 100%;
    overflow-y: scroll;
    overflow-x: hidden;
    padding:5px!important;
    margin-left:5px;
    }

    .bottom-nav {
      max-width:100%!important;
      bottom: 0;
      position: fixed;
      width: 100%;
      background-color: #fff;
      box-shadow: 0 1px 4px 0 rgba(0, 0, 0, 0.5);
    }


}

@media screen and (min-width: 1200px) {
  .appBgImage_fd065 {
    display: block;
  }

  .appToolbar_1ea26 {
    max-width: 550px!important;
    left: 0;
    top: 0;
    width: 100%;
    position: fixed;
    box-shadow: 0px 1px 4px 0px rgba(0, 0, 0, 0.3);
    z-index: 2
  }

  .matchListContainer_ca5d2 {
    display: flex;
    flex-direction: column;
    max-width: 550px!important;
    -webkit-overflow-scrolling: touch;
    width: 100%;
    height: 100%;
    overflow-y: scroll;
    overflow-x: hidden
  }
  .bottom-nav {
    max-width:34.23%!important;
    bottom: 0;
    position: fixed;
    width: 100%;
    background-color: #fff;
    box-shadow: 0 1px 4px 0 rgba(0, 0, 0, 0.5);
    }

    .appContainer_6475d {
    max-width: 550px!important;
    height: 100%;
	}
}
</style>






      <style>/*  :root{COMMENT:// DEPRECATED: Use jssVariables instead;--color:#323232;--primary-bg-color:#c51d23;--primary-fg-color:#FFF;--primary-selected-bg-color:#ab1a1f;--secondary-fg-color:#888;--button-height:48px;--icon-color:var(--color);--primary-btn-color:#3759a5;--secondary-btn-color:#3759a5;--box-shadow-light:0px 1px 4px 0px rgba(0, 0, 0, 0.2);--box-shadow-dark:0 1px 2px 0 rgba(0, 0, 0, 0.3);--large-button-height:50px;--icon-size:24px;--font-x-small:10px;--font-small:12px;--font-medium:14px;--font-large:24px;--currency-font-color:inherit}  */</style>
      <style id="app-style"> /* .appContainer_6475d{ max-width:550px;height:100%}.appBgImage_fd065{position:fixed;left:550px;right:0;background-size:cover;top:0;bottom:0; }.home_fed50{height:100%}.appToolbar_1ea26{max-width:550px;left:0;top:0;width:100%;position:fixed;box-shadow:0px 1px 4px 0px rgba(0, 0, 0, 0.3);z-index:2}.homeToolbar_7b795{display:flex;align-items:center;justify-content:space-between}.headerElement_af700{display:flex;flex:1}.left_a1d14{justify-content:flex-start}.logo_32840{height:48px;padding:8px}.right_c98d9{justify-content:flex-end}.tab_4e2e6{color:#fff;display:flex;flex-wrap:nowrap;overflow-x:auto;width:100%;max-width:550px;margin:auto;padding:0 8px}./*tabItemSelected_765ac{border-bottom:solid 2px #fff !important;opacity:1 !important}*/  /*.tabItem_66759{align-items:center;display:flex;flex:1 0 auto;height:48px;min-width:80px;justify-content:center;cursor:pointer;transition:all ease-in 300ms;opacity:0.6}.siteTab_56f2f{display:flex;justify-content:center;align-items:center}.siteTabText_ce5fe{text-transform:uppercase}.homeListContainer_55b59{padding-top:96px;height:100%}.carouselContainer_cbc2d{position:relative}.carousel_db1fc{overflow:hidden}.carouselContent_4b30b{transition:all 300ms 0ms}.carouselContentStopAnimation_1677b{transition:none;will-change:transform}.homeList_029e0{display:flex}.matchListContainer_ca5d2{display:flex;flex-direction:column;max-width:550px;-webkit-overflow-scrolling:touch;width:100%;height:100%;overflow-y:scroll;overflow-x:hidden}.feedBannerShell_6873c{display:flex;align-items:center;justify-content:center;background-color:#f4f4f4;background-clip:content-box;padding:12px}.feedBannerDesktop_fee7d{height:240px}.blockLoader_580b6{margin:12px auto}.loaderCircular_00f73{animation:loader-rotate 2s linear infinite}.loaderPath_00e5f{animation:loader-stroke 1.5s ease-in-out infinite;stroke-dasharray:1, 162;stroke-dashoffset:0;stroke-linecap:round;stroke-width:6}.black_7fbc4{stroke:rgba(0, 0, 0, 0.5)}.headerContainer_b77fa{padding-left:8px;width:100%}.header_e8b8b{width:100%;display:flex;justify-content:space-between;align-items:center;height:40px}.card_690e1{background-color:#fff;margin:8px;box-shadow:0 1px 2px 0 rgba(0, 0, 0, 0.3);border-radius:2px;overflow:hidden}.matchCardDetail_c54ac{display:flex;justify-content:space-around;height:120px;width:100%}.matchCardInfo_9f857{display:flex;flex-direction:column;align-items:center;height:65px;justify-content:space-between}.empty_c9042{height:10px}.matchCard_868db{text-decoration:none;color:inherit}.gradient_28499{background:linear-gradient(132deg, white 49%, #f4f4f4 49%)}.bigFlag_78f81{max-width:68px;max-height:68px}.tourNameLabel_d619f{color:#9b9b9b;font-size:10px;width:150px;text-align:center}.timer_defb2{color:#c61c23;font-family:monospace}.filterContainer_17b8d{display:flex;font-size:10px}.feedbannerContainer_c08f0{display:flex;flex-direction:row;padding:8px}.feedBanner_52d71{-webkit-overflow-scrolling:touch;overflow-x:hidden;padding:12px}.feedBannerImage_01eb7{height:100%;width:100%;border-radius:8px}.carouselNavigatorButton_46966{width:36px;height:36px;border-radius:50%;display:flex;justify-content:center;align-items:center;position:absolute;top:50%;transform:translateY(-50%);background-color:rgba(255, 255, 255, 0.5);margin:0 4%;cursor:pointer}.carouselNavigatorButtonNext_b9b75{right:0}.carouselNavigationIndicatorContainer_b9ae4{display:flex;justify-content:center}.carouselNavigationIndicator_5b004{width:12px;height:2px;margin:2px}.carouselNavigationIndicatorActive_21990{background-color:rgb(123, 122, 122)}.carouselNavigationIndicatorInactive_43a73{background-color:rgba(123, 122, 122, 0.3)}.loaderContainer_d2930{display:flex;height:100%;align-items:center}.fadeIn_73e97{animation:fade-in .25s linear}.headerContainer_1725f{background:linear-gradient(104deg, #3c3c3c 47%, #323232 47%);display:flex;flex-direction:column;z-index:2}.headerFixed_38df7{position:fixed;top:0;max-width:550px;width:100%}.defaultHeaderContent_00a63{display:flex;justify-content:space-between;color:#FFF;height:48px}.headerLeft_36c4e{display:flex;flex:1 0 0;justify-content:flex-start;align-items:center}.headerCenter_4d6f0{display:flex;flex:1 0 0;justify-content:center;align-items:center}.headerRight_d1c5d{display:flex;flex:1 0 0;justify-content:flex-end;align-items:center;margin-right:12px}.guruIcon_0a307{height:24px;width:24px;margin-right:12px}.container_aa549{display:flex;flex-direction:column;height:136px}.maxInfoText_13e5b{font-size:12px;color:#fff;display:flex;align-self:center;margin-bottom:12px}.infoContent_0b612{display:flex;justify-content:space-around}.playerSelectionContainerLoader_68e5b{display:flex;flex-direction:column;justify-content:space-evenly}.flagContainer_029e0{display:flex}.squadOneText_3ad2c{display:flex;flex-direction:column;color:#acacac;margin-left:4px}.squadTwoText_b9766{display:flex;flex-direction:column;color:#acacac;margin-left:4px;align-items:flex-end;margin-right:4px}.infoLoaderProgressContainer_51138{display:flex;justify-content:center;margin:24px 16px 16px}.mainWrapper_8542d{background:#fafafa;padding-bottom:90px;overflow-y:hidden}.tabsMainContainer_a916e{background:#fff;position:fixed;top:184px;z-index:2;max-width:550px;width:100%}.tabsWrapper_43944{max-width:550px;overflow-x:hidden}.createTeamTabsContainer_5ba85{display:flex;flex:1 0 0;justify-content:center;cursor:pointer}.roleTabItem_603ae{height:48px;display:flex;align-items:center;justify-content:center;width:100%;color:#9c9c9c;letter-spacing:1px}.createTeamTabsHelpContainer_ce9c9{height:44px;display:flex;align-items:center;color:#000;justify-content:center;background-color:#efeff4}.ctSortingHeader_a6515{display:flex;height:36px;color:#acacac;font-size:12px;border-bottom:1px solid #e8e8e8;padding-left:16px}.playerCardCell_bf9d8{display:flex;align-items:center;white-space:nowrap;text-overflow:ellipsis;overflow:hidden}.playerCardAvatarCell_2b8d1{flex:0 0 60px}.playerCardInfoCell_ba412{display:flex;flex-grow:1}.playerCardNameCell_50086{flex-grow:3;flex-basis:80px}.playerPointsCell_aa0e3{flex-grow:1;flex-basis:60px;justify-content:center}.activeSortKey_c7202{color:#000}.materialIcon_10a4f{font-family:Material Icons;font-weight:normal;font-style:normal;display:inline-block;line-height:1;text-transform:none;letter-spacing:normal;word-wrap:normal;white-space:nowrap;direction:ltr}.sortingHeaderIconPlaceHolder_43273{display:flex;flex-basis:70px}.playerListContainer_e09a1{margin-top:312px;overflow-y:scroll}.playerCard_42b9d{background-color:#fff;display:flex;height:72px;padding-left:16px;transition:background-color 300ms cubic-bezier(0, 2, 1, 1)}.playerCardInfoContainer_d41f9{border-bottom:1px solid #e8e8e8}.playerCardIconContainer_65be8{display:flex;flex-basis:70px;justify-content:center;margin:10px 0;border-left:1px solid #e8e8e8}.footer_d9cd3{height:40px;position:fixed;margin-bottom:16px;width:100%;max-width:550px;z-index:3;bottom:0px}.footerButtonContainer_b9ae4{display:flex;justify-content:center}.disabledButton_cf79e{opacity:0.5;cursor:not-allowed}.raisedGreenButton_20c05{background:#25ba38;border:0;cursor:pointer;margin:0;text-decoration:none;text-align:center;font-family:inherit;display:flex;justify-content:center;align-items:center;color:#fff;font-weight:500;font-size:12px;height:32px;padding:8px 8px;text-transform:uppercase;width:120px;border-radius:4px;box-shadow:0 4px 8px 0 rgba(0, 0, 0, 0.2);}.raisedGreenButtonDisabled_e0a23{background:#dcdcdc;color:#969696;opacity:1}.timer_3d48d{color:#fff}.floatingAnchorButton_fac02{font-weight:600;text-decoration:none;color:#3759a5}.helpLink_4c95c{display:flex;justify-content:center;align-items:center;height:24px;width:24px;border:solid 1px #acacac;border-radius:50%;color:#acacac}.playerSelectionContainer_d8646{display:flex;flex-direction:column;color:#acacac;font-size:12px;margin-left:16px}.squadTextContainer_3e550{display:flex;font-size:12px}.selectedCount_daee8{font-size:24px;color:#fff}.totalCount_c1f66{padding-top:10px}.flagContainer_47acd{display:flex;align-items:center;justify-content:space-around;margin:0 4px}.flag_008b5{width:44px;height:44px;border-radius:50%}.teamName_a2024{font-size:12px}.teamCount_84ce0{font-size:16px;color:#fff;margin-top:4px}.creditsContainer_e7f97{display:flex;flex-direction:column;color:#acacac;font-size:12px;margin-right:16px}.creditsText_a4625{color:#fff;font-size:24px;display:flex;justify-content:flex-end}.progressContainer_00657{margin:24px 16px 16px}.stepperContainer_b9ae4{display:flex;justify-content:center}.stepperBlock_8b62f{width:36px;height:16px;font-size:12px;transform:skew(-20deg);border:1px solid #323232;display:flex;justify-content:center;align-items:center}.inactiveStepper_4d390{background-color:#fff}.lastStepper_2bce1{font-size:12px;color:#000;transform:skew(20deg)}.roleTabWrapper_a3522{display:block;width:100%}.createTeamTabTitle_99a5a{display:flex;justify-content:center;font-weight:600;font-size:16px}.createTeamTabsCount_19658{display:flex;align-items:center;justify-content:center;font-size:12px}.roleTabHighlight_ee4c9{transform:skew(-20deg);height:4px;width:100%}.roleTabHighlightActive_28bb8{background-color:#c51d23}.roleTabHighlightInactive_4d390{background-color:#fff}.imageContainer_029e0{display:flex}.playerImageProfile_43b1b{height:48px;width:48px}.playerImageContainer_6e52e{display:flex;flex-direction:column;overflow:hidden;height:100%;width:100%}.playerImage_f320d{width:100%;flex:1;background-size:cover;background-repeat:no-repeat;border-radius:50%;background-color:#969696}.playerName_73cad{flex-basis:44px;justify-content:center;color:#00a0ff}.playerTeamTitle_a2024{font-size:12px}.playerCardIcon_b8a19{border-radius:50%;color:#24ba38;align-self:center;border:1px solid}.desktopTeamPreviewContainer_61fb1{position:fixed;left:550px;width:550px;height:100%;top:0;max-width:550px}.content_60710{background-repeat:no-repeat;background-size:cover;background-position:center;min-height:100%;display:flex;flex-direction:column;height:100%}.toolbar_650b2{width:100%;background-color:transparent;flex:0;position:fixed;height:48px;z-index:2;max-width:550px}.toolbarElementMain_7948b{flex:1;display:flex}.toolbarElementLeft_19260{justify-content:flex-start;color:#fff;padding:8px}.toolbarElementRight_c98d9{justify-content:flex-end}.toolbarElementIcon_3d48d{color:#fff}.playerArea_eac11{position:relative;height:100%;overflow:scroll}.emptyStateWrapper_1b95a{display:flex;align-items:center;flex-direction:column;padding:8px;background:#00000059;border-radius:4px;position:absolute;left:50%;top:50%;transform:translate(-50%, -50%)}.emptyStateText_2c68c{padding:8px;color:#fff;font-weight:bold;white-space:nowrap}    /*</style>
     
      <style type="text/css">/*.fb_hidden{position:absolute;top:-10000px;z-index:10001}.fb_reposition{overflow:hidden;position:relative}.fb_invisible{display:none}.fb_reset{background:none;border:0;border-spacing:0;color:#000;cursor:auto;direction:ltr;font-family:"lucida grande", tahoma, verdana, arial, sans-serif;font-size:11px;font-style:normal;font-variant:normal;font-weight:normal;letter-spacing:normal;line-height:1;margin:0;overflow:visible;padding:0;text-align:left;text-decoration:none;text-indent:0;text-shadow:none;text-transform:none;visibility:visible;white-space:normal;word-spacing:normal}.fb_reset>div{overflow:hidden}@keyframes fb_transform{from{opacity:0;transform:scale(.95)}to{opacity:1;transform:scale(1)}}.fb_animate{animation:fb_transform .3s forwards}
         .fb_dialog{background:rgba(82, 82, 82, .7);position:absolute;top:-10000px;z-index:10001}.fb_dialog_advanced{border-radius:8px;padding:10px}.fb_dialog_content{background:#fff;color:#373737}.fb_dialog_close_icon{background:url(https://static.xx.fbcdn.net/rsrc.php/v3/yq/r/IE9JII6Z1Ys.png) no-repeat scroll 0 0 transparent;cursor:pointer;display:block;height:15px;position:absolute;right:18px;top:17px;width:15px}.fb_dialog_mobile .fb_dialog_close_icon{left:5px;right:auto;top:5px}.fb_dialog_padding{background-color:transparent;position:absolute;width:1px;z-index:-1}.fb_dialog_close_icon:hover{background:url(https://static.xx.fbcdn.net/rsrc.php/v3/yq/r/IE9JII6Z1Ys.png) no-repeat scroll 0 -15px transparent}.fb_dialog_close_icon:active{background:url(https://static.xx.fbcdn.net/rsrc.php/v3/yq/r/IE9JII6Z1Ys.png) no-repeat scroll 0 -30px transparent}.fb_dialog_iframe{line-height:0}.fb_dialog_content .dialog_title{background:#6d84b4;border:1px solid #365899;color:#fff;font-size:14px;font-weight:bold;margin:0}.fb_dialog_content .dialog_title>span{background:url(https://static.xx.fbcdn.net/rsrc.php/v3/yd/r/Cou7n-nqK52.gif) no-repeat 5px 50%;float:left;padding:5px 0 7px 26px}body.fb_hidden{height:100%;left:0;margin:0;overflow:visible;position:absolute;top:-10000px;transform:none;width:100%}.fb_dialog.fb_dialog_mobile.loading{background:url(https://static.xx.fbcdn.net/rsrc.php/v3/ya/r/3rhSv5V8j3o.gif) white no-repeat 50% 50%;min-height:100%;min-width:100%;overflow:hidden;position:absolute;top:0;z-index:10001}.fb_dialog.fb_dialog_mobile.loading.centered{background:none;height:auto;min-height:initial;min-width:initial;width:auto}.fb_dialog.fb_dialog_mobile.loading.centered #fb_dialog_loader_spinner{width:100%}.fb_dialog.fb_dialog_mobile.loading.centered .fb_dialog_content{background:none}.loading.centered #fb_dialog_loader_close{clear:both;color:#fff;display:block;font-size:18px;padding-top:20px}#fb-root #fb_dialog_ipad_overlay{background:rgba(0, 0, 0, .4);bottom:0;left:0;min-height:100%;position:absolute;right:0;top:0;width:100%;z-index:10000}#fb-root #fb_dialog_ipad_overlay.hidden{display:none}.fb_dialog.fb_dialog_mobile.loading iframe{visibility:hidden}.fb_dialog_mobile .fb_dialog_iframe{position:sticky;top:0}.fb_dialog_content .dialog_header{background:linear-gradient(from(#738aba), to(#2c4987));border-bottom:1px solid;border-color:#1d3c78;box-shadow:white 0 1px 1px -1px inset;color:#fff;font:bold 14px Helvetica, sans-serif;text-overflow:ellipsis;text-shadow:rgba(0, 30, 84, .296875) 0 -1px 0;vertical-align:middle;white-space:nowrap}.fb_dialog_content .dialog_header table{height:43px;width:100%}.fb_dialog_content .dialog_header td.header_left{font-size:12px;padding-left:5px;vertical-align:middle;width:60px}.fb_dialog_content .dialog_header td.header_right{font-size:12px;padding-right:5px;vertical-align:middle;width:60px}.fb_dialog_content .touchable_button{background:linear-gradient(from(#4267B2), to(#2a4887));background-clip:padding-box;border:1px solid #29487d;border-radius:3px;display:inline-block;line-height:18px;margin-top:3px;max-width:85px;padding:4px 12px;position:relative}.fb_dialog_content .dialog_header .touchable_button input{background:none;border:none;color:#fff;font:bold 12px Helvetica, sans-serif;margin:2px -12px;padding:2px 6px 3px 6px;text-shadow:rgba(0, 30, 84, .296875) 0 -1px 0}.fb_dialog_content .dialog_header .header_center{color:#fff;font-size:16px;font-weight:bold;line-height:18px;text-align:center;vertical-align:middle}.fb_dialog_content .dialog_content{background:url(https://static.xx.fbcdn.net/rsrc.php/v3/y9/r/jKEcVPZFk-2.gif) no-repeat 50% 50%;border:1px solid #4a4a4a;border-bottom:0;border-top:0;height:150px}.fb_dialog_content .dialog_footer{background:#f5f6f7;border:1px solid #4a4a4a;border-top-color:#ccc;height:40px}#fb_dialog_loader_close{float:left}.fb_dialog.fb_dialog_mobile .fb_dialog_close_button{text-shadow:rgba(0, 30, 84, .296875) 0 -1px 0}.fb_dialog.fb_dialog_mobile .fb_dialog_close_icon{visibility:hidden}#fb_dialog_loader_spinner{animation:rotateSpinner 1.2s linear infinite;background-color:transparent;background-image:url(https://static.xx.fbcdn.net/rsrc.php/v3/yD/r/t-wz8gw1xG1.png);background-position:50% 50%;background-repeat:no-repeat;height:24px;width:24px}@keyframes rotateSpinner{0%{transform:rotate(0deg)}100%{transform:rotate(360deg)}}
         .fb_iframe_widget{display:inline-block;position:relative}.fb_iframe_widget span{display:inline-block;position:relative;text-align:justify}.fb_iframe_widget iframe{position:absolute}.fb_iframe_widget_fluid_desktop,.fb_iframe_widget_fluid_desktop span,.fb_iframe_widget_fluid_desktop iframe{max-width:100%}.fb_iframe_widget_fluid_desktop iframe{min-width:220px;position:relative}.fb_iframe_widget_lift{z-index:1}.fb_iframe_widget_fluid{display:inline}.fb_iframe_widget_fluid span{width:100%}
         .fb_customer_chat_bounce_in_v2{animation-duration:300ms;animation-name:fb_bounce_in_v2;transition-timing-function:ease-in}.fb_customer_chat_bounce_out_v2{animation-duration:300ms;animation-name:fb_bounce_out_v2;transition-timing-function:ease-in}.fb_customer_chat_bounce_in_v2_mobile_chat_started{animation-duration:300ms;animation-name:fb_bounce_in_v2_mobile_chat_started;transition-timing-function:ease-in}.fb_customer_chat_bounce_out_v2_mobile_chat_started{animation-duration:300ms;animation-name:fb_bounce_out_v2_mobile_chat_started;transition-timing-function:ease-in}.fb_customer_chat_bubble_pop_in{animation-duration:250ms;animation-name:fb_customer_chat_bubble_bounce_in_animation}.fb_customer_chat_bubble_animated_no_badge{box-shadow:0 3px 12px rgba(0, 0, 0, .15);transition:box-shadow 150ms linear}.fb_customer_chat_bubble_animated_no_badge:hover{box-shadow:0 5px 24px rgba(0, 0, 0, .3)}.fb_customer_chat_bubble_animated_with_badge{box-shadow:-5px 4px 14px rgba(0, 0, 0, .15);transition:box-shadow 150ms linear}.fb_customer_chat_bubble_animated_with_badge:hover{box-shadow:-5px 8px 24px rgba(0, 0, 0, .2)}.fb_invisible_flow{display:inherit;height:0;overflow-x:hidden;width:0}.fb_mobile_overlay_active{background-color:#fff;height:100%;overflow:hidden;position:fixed;visibility:hidden;width:100%}@keyframes fb_bounce_in_v2{0%{opacity:0;transform:scale(0, 0);transform-origin:bottom right}50%{transform:scale(1.03, 1.03);transform-origin:bottom right}100%{opacity:1;transform:scale(1, 1);transform-origin:bottom right}}@keyframes fb_bounce_in_v2_mobile_chat_started{0%{opacity:0;top:20px}100%{opacity:1;top:0}}@keyframes fb_bounce_out_v2{0%{opacity:1;transform:scale(1, 1);transform-origin:bottom right}100%{opacity:0;transform:scale(0, 0);transform-origin:bottom right}}@keyframes fb_bounce_out_v2_mobile_chat_started{0%{opacity:1;top:0}100%{opacity:0;top:20px}}@keyframes fb_customer_chat_bubble_bounce_in_animation{0%{bottom:6pt;opacity:0;transform:scale(0, 0);transform-origin:center}70%{bottom:18pt;opacity:1;transform:scale(1.2, 1.2)}100%{transform:scale(1, 1)}}  */
      </style>


<style>
  
  .fb_hidden {
    position: absolute;
    top: -10000px;
    z-index: 10001
}

.fb_reposition {
    overflow: hidden;
    position: relative
}

.fb_invisible {
    display: none
}

.fb_reset {
    background: none;
    border: 0;
    border-spacing: 0;
    color: #000;
    cursor: auto;
    direction: ltr;
    font-family: "lucida grande", tahoma, verdana, arial, sans-serif;
    font-size: 11px;
    font-style: normal;
    font-variant: normal;
    font-weight: normal;
    letter-spacing: normal;
    line-height: 1;
    margin: 0;
    overflow: visible;
    padding: 0;
    text-align: left;
    text-decoration: none;
    text-indent: 0;
    text-shadow: none;
    text-transform: none;
    visibility: visible;
    white-space: normal;
    word-spacing: normal
}

.fb_reset>div {
    overflow: hidden
}

@keyframes fb_transform {
    from {
        opacity: 0;
        transform: scale(.95)
    }

    to {
        opacity: 1;
        transform: scale(1)
    }
}

.fb_animate {
    animation: fb_transform .3s forwards
}

.fb_dialog {
    background: rgba(82, 82, 82, .7);
    position: absolute;
    top: -10000px;
    z-index: 10001
}

.fb_dialog_advanced {
    border-radius: 8px;
    padding: 10px
}

.fb_dialog_content {
    background: #fff;
    color: #373737
}

.fb_dialog_close_icon {
    background: url(https://static.xx.fbcdn.net/rsrc.php/v3/yq/r/IE9JII6Z1Ys.png) no-repeat scroll 0 0 transparent;
    cursor: pointer;
    display: block;
    height: 15px;
    position: absolute;
    right: 18px;
    top: 17px;
    width: 15px
}

.fb_dialog_mobile .fb_dialog_close_icon {
    left: 5px;
    right: auto;
    top: 5px
}

.fb_dialog_padding {
    background-color: transparent;
    position: absolute;
    width: 1px;
    z-index: -1
}

.fb_dialog_close_icon:hover {
    background: url(https://static.xx.fbcdn.net/rsrc.php/v3/yq/r/IE9JII6Z1Ys.png) no-repeat scroll 0 -15px transparent
}

.fb_dialog_close_icon:active {
    background: url(https://static.xx.fbcdn.net/rsrc.php/v3/yq/r/IE9JII6Z1Ys.png) no-repeat scroll 0 -30px transparent
}

.fb_dialog_iframe {
    line-height: 0
}

.fb_dialog_content .dialog_title {
    background: #6d84b4;
    border: 1px solid #365899;
    color: #fff;
    font-size: 14px;
    font-weight: bold;
    margin: 0
}

.fb_dialog_content .dialog_title>span {
    background: url(https://static.xx.fbcdn.net/rsrc.php/v3/yd/r/Cou7n-nqK52.gif) no-repeat 5px 50%;
    float: left;
    padding: 5px 0 7px 26px
}

body.fb_hidden {
    height: 100%;
    left: 0;
    margin: 0;
    overflow: visible;
    position: absolute;
    top: -10000px;
    transform: none;
    width: 100%
}

.fb_dialog.fb_dialog_mobile.loading {
    background: url(https://static.xx.fbcdn.net/rsrc.php/v3/ya/r/3rhSv5V8j3o.gif) white no-repeat 50% 50%;
    min-height: 100%;
    min-width: 100%;
    overflow: hidden;
    position: absolute;
    top: 0;
    z-index: 10001
}

.fb_dialog.fb_dialog_mobile.loading.centered {
    background: none;
    height: auto;
    min-height: initial;
    min-width: initial;
    width: auto
}

.fb_dialog.fb_dialog_mobile.loading.centered #fb_dialog_loader_spinner {
    width: 100%
}

.fb_dialog.fb_dialog_mobile.loading.centered .fb_dialog_content {
    background: none
}

.loading.centered #fb_dialog_loader_close {
    clear: both;
    color: #fff;
    display: block;
    font-size: 18px;
    padding-top: 20px
}

#fb-root #fb_dialog_ipad_overlay {
    background: rgba(0, 0, 0, .4);
    bottom: 0;
    left: 0;
    min-height: 100%;
    position: absolute;
    right: 0;
    top: 0;
    width: 100%;
    z-index: 10000
}

#fb-root #fb_dialog_ipad_overlay.hidden {
    display: none
}

.fb_dialog.fb_dialog_mobile.loading iframe {
    visibility: hidden
}

.fb_dialog_mobile .fb_dialog_iframe {
    position: sticky;
    top: 0
}

.fb_dialog_content .dialog_header {
    background: linear-gradient(from(#738aba), to(#2c4987));
    border-bottom: 1px solid;
    border-color: #1d3c78;
    box-shadow: white 0 1px 1px -1px inset;
    color: #fff;
    font: bold 14px Helvetica, sans-serif;
    text-overflow: ellipsis;
    text-shadow: rgba(0, 30, 84, .296875) 0 -1px 0;
    vertical-align: middle;
    white-space: nowrap
}

.fb_dialog_content .dialog_header table {
    height: 43px;
    width: 100%
}

.fb_dialog_content .dialog_header td.header_left {
    font-size: 12px;
    padding-left: 5px;
    vertical-align: middle;
    width: 60px
}

.fb_dialog_content .dialog_header td.header_right {
    font-size: 12px;
    padding-right: 5px;
    vertical-align: middle;
    width: 60px
}

.fb_dialog_content .touchable_button {
    background: linear-gradient(from(#4267B2), to(#2a4887));
    background-clip: padding-box;
    border: 1px solid #29487d;
    border-radius: 3px;
    display: inline-block;
    line-height: 18px;
    margin-top: 3px;
    max-width: 85px;
    padding: 4px 12px;
    position: relative
}

.fb_dialog_content .dialog_header .touchable_button input {
    background: none;
    border: none;
    color: #fff;
    font: bold 12px Helvetica, sans-serif;
    margin: 2px -12px;
    padding: 2px 6px 3px 6px;
    text-shadow: rgba(0, 30, 84, .296875) 0 -1px 0
}

.fb_dialog_content .dialog_header .header_center {
    color: #fff;
    font-size: 16px;
    font-weight: bold;
    line-height: 18px;
    text-align: center;
    vertical-align: middle
}

.fb_dialog_content .dialog_content {
    background: url(https://static.xx.fbcdn.net/rsrc.php/v3/y9/r/jKEcVPZFk-2.gif) no-repeat 50% 50%;
    border: 1px solid #4a4a4a;
    border-bottom: 0;
    border-top: 0;
    height: 150px
}

.fb_dialog_content .dialog_footer {
    background: #f5f6f7;
    border: 1px solid #4a4a4a;
    border-top-color: #ccc;
    height: 40px
}

#fb_dialog_loader_close {
    float: left
}

.fb_dialog.fb_dialog_mobile .fb_dialog_close_button {
    text-shadow: rgba(0, 30, 84, .296875) 0 -1px 0
}

.fb_dialog.fb_dialog_mobile .fb_dialog_close_icon {
    visibility: hidden
}

#fb_dialog_loader_spinner {
    animation: rotateSpinner 1.2s linear infinite;
    background-color: transparent;
    background-image: url(https://static.xx.fbcdn.net/rsrc.php/v3/yD/r/t-wz8gw1xG1.png);
    background-position: 50% 50%;
    background-repeat: no-repeat;
    height: 24px;
    width: 24px
}

@keyframes rotateSpinner {
    0% {
        transform: rotate(0deg)
    }

    100% {
        transform: rotate(360deg)
    }
}

.fb_iframe_widget {
    display: inline-block;
    position: relative
}

.fb_iframe_widget span {
    display: inline-block;
    position: relative;
    text-align: justify
}

.fb_iframe_widget iframe {
    position: absolute
}

.fb_iframe_widget_fluid_desktop,
.fb_iframe_widget_fluid_desktop span,
.fb_iframe_widget_fluid_desktop iframe {
    max-width: 100%
}

.fb_iframe_widget_fluid_desktop iframe {
    min-width: 220px;
    position: relative
}

.fb_iframe_widget_lift {
    z-index: 1
}

.fb_iframe_widget_fluid {
    display: inline
}

.fb_iframe_widget_fluid span {
    width: 100%
}

.fb_customer_chat_bounce_in_v2 {
    animation-duration: 300ms;
    animation-name: fb_bounce_in_v2;
    transition-timing-function: ease-in
}

.fb_customer_chat_bounce_out_v2 {
    animation-duration: 300ms;
    animation-name: fb_bounce_out_v2;
    transition-timing-function: ease-in
}

.fb_customer_chat_bounce_in_v2_mobile_chat_started {
    animation-duration: 300ms;
    animation-name: fb_bounce_in_v2_mobile_chat_started;
    transition-timing-function: ease-in
}

.fb_customer_chat_bounce_out_v2_mobile_chat_started {
    animation-duration: 300ms;
    animation-name: fb_bounce_out_v2_mobile_chat_started;
    transition-timing-function: ease-in
}

.fb_customer_chat_bubble_pop_in {
    animation-duration: 250ms;
    animation-name: fb_customer_chat_bubble_bounce_in_animation
}

.fb_customer_chat_bubble_animated_no_badge {
    box-shadow: 0 3px 12px rgba(0, 0, 0, .15);
    transition: box-shadow 150ms linear
}

.fb_customer_chat_bubble_animated_no_badge:hover {
    box-shadow: 0 5px 24px rgba(0, 0, 0, .3)
}

.fb_customer_chat_bubble_animated_with_badge {
    box-shadow: -5px 4px 14px rgba(0, 0, 0, .15);
    transition: box-shadow 150ms linear
}

.fb_customer_chat_bubble_animated_with_badge:hover {
    box-shadow: -5px 8px 24px rgba(0, 0, 0, .2)
}

.fb_invisible_flow {
    display: inherit;
    height: 0;
    overflow-x: hidden;
    width: 0
}

.fb_mobile_overlay_active {
    background-color: #fff;
    height: 100%;
    overflow: hidden;
    position: fixed;
    visibility: hidden;
    width: 100%
}

@keyframes fb_bounce_in_v2 {
    0% {
        opacity: 0;
        transform: scale(0, 0);
        transform-origin: bottom right
    }

    50% {
        transform: scale(1.03, 1.03);
        transform-origin: bottom right
    }

    100% {
        opacity: 1;
        transform: scale(1, 1);
        transform-origin: bottom right
    }
}

@keyframes fb_bounce_in_v2_mobile_chat_started {
    0% {
        opacity: 0;
        top: 20px
    }

    100% {
        opacity: 1;
        top: 0
    }
}

@keyframes fb_bounce_out_v2 {
    0% {
        opacity: 1;
        transform: scale(1, 1);
        transform-origin: bottom right
    }

    100% {
        opacity: 0;
        transform: scale(0, 0);
        transform-origin: bottom right
    }
}

@keyframes fb_bounce_out_v2_mobile_chat_started {
    0% {
        opacity: 1;
        top: 0
    }

    100% {
        opacity: 0;
        top: 20px
    }
}

@keyframes fb_customer_chat_bubble_bounce_in_animation {
    0% {
        bottom: 6pt;
        opacity: 0;
        transform: scale(0, 0);
        transform-origin: center
    }

    70% {
        bottom: 18pt;
        opacity: 1;
        transform: scale(1.2, 1.2)
    }

    100% {
        transform: scale(1, 1)
    }
}



/*----------------------------------------------------------------*/



.appContainer_6475d {
    max-width: 550px;
    height: 100%
}

.appBgImage_fd065 {
    position: fixed;
    left: 550px;
    right: 0;
    background-size: cover;
    top: 0;
    bottom: 0;
}

.home_fed50 {
    height: 100%
}

.appToolbar_1ea26 {
    max-width: 550px;
    left: 0;
    top: 0;
    width: 100%;
    position: fixed;
    box-shadow: 0px 1px 4px 0px rgba(0, 0, 0, 0.3);
    z-index: 2
}

.homeToolbar_7b795 {
    display: flex;
    align-items: center;
    justify-content: space-between
}

.headerElement_af700 {
    display: flex;
    flex: 1
}

.left_a1d14 {
    justify-content: flex-start
}

.logo_32840 {
    height: 48px;
    padding: 8px
}

.right_c98d9 {
    justify-content: flex-end
}

.tab_4e2e6 {
    color: #fff;
    display: flex;
    flex-wrap: nowrap;
    overflow-x: auto;
    width: 100%;
    max-width: 550px;
    margin: auto;
    padding: 0 8px
}

.

/*tabItemSelected_765ac{border-bottom:solid 2px #fff !important;opacity:1 !important}*/
.tabItem_66759 {
    align-items: center;
    display: flex;
    flex: 1 0 auto;
    height: 48px;
    min-width: 80px;
    justify-content: center;
    cursor: pointer;
    transition: all ease-in 300ms;
    opacity: 0.6
}

.siteTab_56f2f {
    display: flex;
    justify-content: center;
    align-items: center
}

.siteTabText_ce5fe {
    text-transform: uppercase
}

.homeListContainer_55b59 {
    padding-top: 96px;
    height: 100%
}

.carouselContainer_cbc2d {
    position: relative
}

.carousel_db1fc {
    overflow: hidden
}

.carouselContent_4b30b {
    transition: all 300ms 0ms
}

.carouselContentStopAnimation_1677b {
    transition: none;
    will-change: transform
}

.homeList_029e0 {
    display: flex
}

.matchListContainer_ca5d2 {
    display: flex;
    flex-direction: column;
    max-width: 550px;
    -webkit-overflow-scrolling: touch;
    width: 100%;
    height: 100%;
    overflow-y: scroll;
    overflow-x: hidden
}

.feedBannerShell_6873c {
    display: flex;
    align-items: center;
    justify-content: center;
    background-color: #f4f4f4;
    background-clip: content-box;
    padding: 12px
}

.feedBannerDesktop_fee7d {
    height: 240px
}

.blockLoader_580b6 {
    margin: 12px auto
}

.loaderCircular_00f73 {
    animation: loader-rotate 2s linear infinite
}

.loaderPath_00e5f {
    animation: loader-stroke 1.5s ease-in-out infinite;
    stroke-dasharray: 1, 162;
    stroke-dashoffset: 0;
    stroke-linecap: round;
    stroke-width: 6
}

.black_7fbc4 {
    stroke: rgba(0, 0, 0, 0.5)
}

.headerContainer_b77fa {
    padding-left: 8px;
    width: 100%
}

.header_e8b8b {
    width: 100%;
    display: flex;
    justify-content: space-between;
    align-items: center;
    height: 40px
}

.card_690e1 {
    background-color: #fff;
    margin: 8px;
    box-shadow: 0 1px 2px 0 rgba(0, 0, 0, 0.3);
    border-radius: 2px;
    overflow: hidden
}

.matchCardDetail_c54ac {
    display: flex;
    justify-content: space-around;
    height: 120px;
    width: 100%
}

.matchCardInfo_9f857 {
    display: flex;
    flex-direction: column;
    align-items: center;
    height: 65px;
    justify-content: space-between
}

.empty_c9042 {
    height: 10px
}

.matchCard_868db {
    text-decoration: none;
    color: inherit
}

.gradient_28499 {
    background: linear-gradient(132deg, white 49%, #f4f4f4 49%)
}

.bigFlag_78f81 {
    max-width: 68px;
    max-height: 68px
}

.tourNameLabel_d619f {
    color: #9b9b9b;
    font-size: 10px;
    width: 150px;
    text-align: center
}

.timer_defb2 {
    color: #c61c23;
    font-family: monospace
}

.filterContainer_17b8d {
    display: flex;
    font-size: 10px
}

.feedbannerContainer_c08f0 {
    display: flex;
    flex-direction: row;
    padding: 8px
}

.feedBanner_52d71 {
    -webkit-overflow-scrolling: touch;
    overflow-x: hidden;
    padding: 12px
}

.feedBannerImage_01eb7 {
    height: 100%;
    width: 100%;
    border-radius: 8px
}

.carouselNavigatorButton_46966 {
    width: 36px;
    height: 36px;
    border-radius: 50%;
    display: flex;
    justify-content: center;
    align-items: center;
    position: absolute;
    top: 50%;
    transform: translateY(-50%);
    background-color: rgba(255, 255, 255, 0.5);
    margin: 0 4%;
    cursor: pointer
}

.carouselNavigatorButtonNext_b9b75 {
    right: 0
}

.carouselNavigationIndicatorContainer_b9ae4 {
    display: flex;
    justify-content: center
}

.carouselNavigationIndicator_5b004 {
    width: 12px;
    height: 2px;
    margin: 2px
}

.carouselNavigationIndicatorActive_21990 {
    background-color: rgb(123, 122, 122)
}

.carouselNavigationIndicatorInactive_43a73 {
    background-color: rgba(123, 122, 122, 0.3)
}

.loaderContainer_d2930 {
    display: flex;
    height: 100%;
    align-items: center
}

.fadeIn_73e97 {
    animation: fade-in .25s linear
}

.headerContainer_1725f {
    background: linear-gradient(104deg, #3c3c3c 47%, #323232 47%);
    display: flex;
    flex-direction: column;
    z-index: 2
}

.headerFixed_38df7 {
    position: fixed;
    top: 0;
    max-width: 550px;
    width: 100%
}

.defaultHeaderContent_00a63 {
    display: flex;
    justify-content: space-between;
    color: #FFF;
    height: 48px
}

.headerLeft_36c4e {
    display: flex;
    flex: 1 0 0;
    justify-content: flex-start;
    align-items: center
}

.headerCenter_4d6f0 {
    display: flex;
    flex: 1 0 0;
    justify-content: center;
    align-items: center
}

.headerRight_d1c5d {
    display: flex;
    flex: 1 0 0;
    justify-content: flex-end;
    align-items: center;
    margin-right: 12px
}

.guruIcon_0a307 {
    height: 24px;
    width: 24px;
    margin-right: 12px
}

.container_aa549 {
    display: flex;
    flex-direction: column;
    height: 136px
}

.maxInfoText_13e5b {
    font-size: 12px;
    color: #fff;
    display: flex;
    align-self: center;
    margin-bottom: 12px
}

.infoContent_0b612 {
    display: flex;
    justify-content: space-around
}

.playerSelectionContainerLoader_68e5b {
    display: flex;
    flex-direction: column;
    justify-content: space-evenly
}

.flagContainer_029e0 {
    display: flex
}

.squadOneText_3ad2c {
    display: flex;
    flex-direction: column;
    color: #acacac;
    margin-left: 4px
}

.squadTwoText_b9766 {
    display: flex;
    flex-direction: column;
    color: #acacac;
    margin-left: 4px;
    align-items: flex-end;
    margin-right: 4px
}

.infoLoaderProgressContainer_51138 {
    display: flex;
    justify-content: center;
    margin: 24px 16px 16px
}

.mainWrapper_8542d {
    background: #fafafa;
    padding-bottom: 90px;
    overflow-y: hidden
}

.tabsMainContainer_a916e {
    background: #fff;
    position: fixed;
    top: 184px;
    z-index: 2;
    max-width: 550px;
    width: 100%
}

.tabsWrapper_43944 {
    max-width: 550px;
    overflow-x: hidden
}

.createTeamTabsContainer_5ba85 {
    display: flex;
    flex: 1 0 0;
    justify-content: center;
    cursor: pointer
}

.roleTabItem_603ae {
    height: 48px;
    display: flex;
    align-items: center;
    justify-content: center;
    width: 100%;
    color: #9c9c9c;
    letter-spacing: 1px
}

.createTeamTabsHelpContainer_ce9c9 {
    height: 44px;
    display: flex;
    align-items: center;
    color: #000;
    justify-content: center;
    background-color: #efeff4
}

.ctSortingHeader_a6515 {
    display: flex;
    height: 36px;
    color: #acacac;
    font-size: 12px;
    border-bottom: 1px solid #e8e8e8;
    padding-left: 16px
}

.playerCardCell_bf9d8 {
    display: flex;
    align-items: center;
    white-space: nowrap;
    text-overflow: ellipsis;
    overflow: hidden
}

.playerCardAvatarCell_2b8d1 {
    flex: 0 0 60px
}

.playerCardInfoCell_ba412 {
    display: flex;
    flex-grow: 1
}

.playerCardNameCell_50086 {
    flex-grow: 3;
    flex-basis: 80px
}

.playerPointsCell_aa0e3 {
    flex-grow: 1;
    flex-basis: 60px;
    justify-content: center
}

.activeSortKey_c7202 {
    color: #000
}

.materialIcon_10a4f {
    font-family: Material Icons;
    font-weight: normal;
    font-style: normal;
    display: inline-block;
    line-height: 1;
    text-transform: none;
    letter-spacing: normal;
    word-wrap: normal;
    white-space: nowrap;
    direction: ltr
}

.sortingHeaderIconPlaceHolder_43273 {
    display: flex;
    flex-basis: 70px
}

.playerListContainer_e09a1 {
    margin-top: 312px;
    overflow-y: scroll
}

.playerCard_42b9d {
    background-color: #fff;
    display: flex;
    height: 72px;
    padding-left: 16px;
    transition: background-color 300ms cubic-bezier(0, 2, 1, 1)
}

.playerCardInfoContainer_d41f9 {
    border-bottom: 1px solid #e8e8e8
}

.playerCardIconContainer_65be8 {
    display: flex;
    flex-basis: 70px;
    justify-content: center;
    margin: 10px 0;
    border-left: 1px solid #e8e8e8
}

.footer_d9cd3 {
    height: 40px;
    position: fixed;
    margin-bottom: 16px;
    width: 100%;
    max-width: 550px;
    z-index: 3;
    bottom: 0px
}

.footerButtonContainer_b9ae4 {
    display: flex;
    justify-content: center
}

.disabledButton_cf79e {
    opacity: 0.5;
    cursor: not-allowed
}

.raisedGreenButton_20c05 {
    background: #25ba38;
    border: 0;
    cursor: pointer;
    margin: 0;
    text-decoration: none;
    text-align: center;
    font-family: inherit;
    display: flex;
    justify-content: center;
    align-items: center;
    color: #fff;
    font-weight: 500;
    font-size: 12px;
    height: 32px;
    padding: 8px 8px;
    text-transform: uppercase;
    width: 120px;
    border-radius: 4px;
    box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2);
}

.raisedGreenButtonDisabled_e0a23 {
    background: #dcdcdc;
    color: #969696;
    opacity: 1
}

.timer_3d48d {
    color: #fff
}

.floatingAnchorButton_fac02 {
    font-weight: 600;
    text-decoration: none;
    color: #3759a5
}

.helpLink_4c95c {
    display: flex;
    justify-content: center;
    align-items: center;
    height: 24px;
    width: 24px;
    border: solid 1px #acacac;
    border-radius: 50%;
    color: #acacac
}

.playerSelectionContainer_d8646 {
    display: flex;
    flex-direction: column;
    color: #acacac;
    font-size: 12px;
    margin-left: 16px
}

.squadTextContainer_3e550 {
    display: flex;
    font-size: 12px
}

.selectedCount_daee8 {
    font-size: 24px;
    color: #fff
}

.totalCount_c1f66 {
    padding-top: 10px
}

.flagContainer_47acd {
    display: flex;
    align-items: center;
    justify-content: space-around;
    margin: 0 4px
}

.flag_008b5 {
    width: 44px;
    height: 44px;
    border-radius: 50%
}

.teamName_a2024 {
    font-size: 12px
}

.teamCount_84ce0 {
    font-size: 16px;
    color: #fff;
    margin-top: 4px
}

.creditsContainer_e7f97 {
    display: flex;
    flex-direction: column;
    color: #acacac;
    font-size: 12px;
    margin-right: 16px
}

.creditsText_a4625 {
    color: #fff;
    font-size: 24px;
    display: flex;
    justify-content: flex-end
}

.progressContainer_00657 {
    margin: 24px 16px 16px
}

.stepperContainer_b9ae4 {
    display: flex;
    justify-content: center
}

.stepperBlock_8b62f {
    width: 36px;
    height: 16px;
    font-size: 12px;
    transform: skew(-20deg);
    border: 1px solid #323232;
    display: flex;
    justify-content: center;
    align-items: center
}

.inactiveStepper_4d390 {
    background-color: #fff
}

.lastStepper_2bce1 {
    font-size: 12px;
    color: #000;
    transform: skew(20deg)
}

.roleTabWrapper_a3522 {
    display: block;
    width: 100%
}

.createTeamTabTitle_99a5a {
    display: flex;
    justify-content: center;
    font-weight: 600;
    font-size: 16px
}

.createTeamTabsCount_19658 {
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 12px
}

.roleTabHighlight_ee4c9 {
    transform: skew(-20deg);
    height: 4px;
    width: 100%
}

.roleTabHighlightActive_28bb8 {
    background-color: #c51d23
}

.roleTabHighlightInactive_4d390 {
    background-color: #fff
}

.imageContainer_029e0 {
    display: flex
}

.playerImageProfile_43b1b {
    height: 48px;
    width: 48px
}

.playerImageContainer_6e52e {
    display: flex;
    flex-direction: column;
    overflow: hidden;
    height: 100%;
    width: 100%
}

.playerImage_f320d {
    width: 100%;
    flex: 1;
    background-size: cover;
    background-repeat: no-repeat;
    border-radius: 50%;
    background-color: #969696
}

.playerName_73cad {
    flex-basis: 44px;
    justify-content: center;
    color: #00a0ff
}

.playerTeamTitle_a2024 {
    font-size: 12px
}

.playerCardIcon_b8a19 {
    border-radius: 50%;
    color: #24ba38;
    align-self: center;
    border: 1px solid
}

.desktopTeamPreviewContainer_61fb1 {
    position: fixed;
    left: 550px;
    width: 550px;
    height: 100%;
    top: 0;
    max-width: 550px
}

.content_60710 {
    background-repeat: no-repeat;
    background-size: cover;
    background-position: center;
    min-height: 100%;
    display: flex;
    flex-direction: column;
    height: 100%
}

.toolbar_650b2 {
    width: 100%;
    background-color: transparent;
    flex: 0;
    position: fixed;
    height: 48px;
    z-index: 2;
    max-width: 550px
}

.toolbarElementMain_7948b {
    flex: 1;
    display: flex
}

.toolbarElementLeft_19260 {
    justify-content: flex-start;
    color: #fff;
    padding: 8px
}

.toolbarElementRight_c98d9 {
    justify-content: flex-end
}

.toolbarElementIcon_3d48d {
    color: #fff
}

.playerArea_eac11 {
    position: relative;
    height: 100%;
    overflow: scroll
}

.emptyStateWrapper_1b95a {
    display: flex;
    align-items: center;
    flex-direction: column;
    padding: 8px;
    background: #00000059;
    border-radius: 4px;
    position: absolute;
    left: 50%;
    top: 50%;
    transform: translate(-50%, -50%)
}

.emptyStateText_2c68c {
    padding: 8px;
    color: #fff;
    font-weight: bold;
    white-space: nowrap
}



</style>


   <body cz-shortcut-listen="true">
      <div>
         <div class="app-container appContainer_6475d">
            <div class="appBgImage_fd065"></div>
            <div class="home home_fed50">
               <div class="app-toolbar appToolbar_1ea26">
                  <div>
                     <div class="homeToolbar_7b795">
                        <div class="align-center">
                           <div class="headerElement_af700 left_a1d14"></div>
                           <!-- <img src="<?php //echo base_url('web_assets/image/logo.png')?>" > -->
                           <div style="margin-top: 20px;" class="logo_32840">UAB League</div> 
                           <div class="headerElement_af700 right_c98d9"></div>
                        </div>
                     </div>
                  </div>
                  <div class="tab js--tab tab_4e2e6">
                     <div class="tabItem_66759">
                        <div class="siteTab_56f2f">
                           <div id="fixture_click" class="siteTabText_ce5fe" onclick="openCity(event, 'fixture')">Fixture</div>
                        </div>
                     </div>
                     <div class="tabItem_66759">
                        <div class="siteTab_56f2f">
                           <div class="siteTabText_ce5fe" onclick="openCity(event, 'live')">Live</div>
                        </div>
                     </div>
                     <div class="tabItem_66759">
                        <div class="siteTab_56f2f">
                           <div class="siteTabText_ce5fe" onclick="openCity(event, 'result')">Result</div>
                        </div>
                     </div>
                  </div>
               </div>
               <div class="homeListContainer_55b59">
                  <div>
                     <div class="carouselContainer_cbc2d">
                        <div class="bounding-client-rect">
                           <div class="carousel_db1fc">
                              <div class="carouselContent_4b30b carouselContentStopAnimation_1677b" style="transform: translateX(0px);">
                                 <div class="homeList_029e0" style="width: 2750px;">
                                    <!-- <div class="matchListContainer_ca5d2">
                                       <div>
                                          <div>
                                             <div></div> -->
                                             <!--<div class="headerContainer_b77fa">-->
                                             <!--   <div class="header_e8b8b">-->
                                             <!--       <div>Pick an upcoming match</div> -->
                                             <!--      <button class="btn btn--flat">-->
                                             <!--         <div class="align-center">-->
                                             <!--            <div class="filterContainer_17b8d">-->
                                             <!--               <div></div>-->
                                             <!--               <div></div>-->
                                             <!--            </div>-->
                                             <!--         </div>-->
                                             <!--      </button>-->
                                             <!--   </div>-->
                                             <!--</div>-->
                                             <style type="text/css">
                                             	
                                             </style>
                                              <div class="matchListContainer_ca5d2">
                                       <div>
                                          <div>
                                             
                                             <div class="headerContainer_b77fa">
                                                <div class="header_e8b8b">
                                                	<div style="text-align: center; margin-top:20px;">
                                             	<?php if($this->session->flashdata('success'))
                                             	{?>
                                             		<div id="succ" class="alert alert-success">
													 <?php echo $this->session->flashdata('success'); ?>
													 </div>
                                             	<?php }else if($this->session->flashdata('error')){?>
                                             		<div id="err" class="alert alert-danger">
                                             			<?php echo $this->session->flashdata('error'); ?>
                                             		</div>
                                             	<?php } ?>
                                             </div>
                                                   <!-- <div>Pick an upcoming match</div> -->
                                                   <button class="btn btn--flat">
                                                      <div class="align-center">
                                                         <div class="filterContainer_17b8d">
                                                            <div></div>
                                                            <div></div>
                                                         </div>
                                                      </div>
                                                   </button>
                                                </div>
                                             </div>
                                             <div id="fixture" class="tabs_match">
                                             <?php if(count($fixture_match) > 0) { 
											$count = count($fixture_match);
											 $i = 0;
                                                                   $match_date = array();
											 foreach ($fixture_match as $fixture) {
												$match_date[$i]=$fixture['time'];
                                              $team_one =   $this->Website_model->get_team_by_id($fixture['teamid1']);
                                              $team_two =   $this->Website_model->get_team_by_id($fixture['teamid2']);
                                          
                                              ?>
                                                <a class="js--match-card matchCard_868db" href="<?php echo site_url('website/contest?match='.$fixture['match_id']); ?>">
                                                   <div class="card card_690e1">
                                                      <div class="gradient_28499">
                                                         <div class="matchCardDetail_c54ac">
                                                            <div>
                                                               <div class="lazy-loader lazy-loader--loaded" style="height: 68px; width: 68px; margin-top:11px;"><img class="lazy-loader__img lazy-loader__img--loaded" 
                                                                  src="<?php echo $team_one['team_image']; ?>">
                                                                  <br>
                                                                <span> <?php echo $team_one['team_name']; ?></span>  <br>
                                                            </div>
                                                            </div>
                                                            <div class="matchCardInfo_9f857" style="margin-top:19px;">
                                                               
                                                               <div class="timer_defb2" id="demo<?php echo $i; ?>"></div>
                                                               <div><?php echo $fixture['type']; ?></div>
                                                               <div class="empty_c9042"><?php echo $team_one['team_short_name']; ?> Vs <?php echo $team_two['team_short_name']; ?></div>
                                                            </div>
                                                            <div>
                                                               <div class="lazy-loader lazy-loader--loaded" style="height: 68px; width: 68px; margin-top:11px;"><img class="lazy-loader__img lazy-loader__img--loaded" src="<?php echo $team_two['team_image']; ?> ">
                                                                   <br>
                                                                <span> <?php echo $team_two['team_name']; ?></span> <br>
                                                               </div>
                                                            </div>
                                                         </div>
                                                      </div>
                                                   </div>
                                                </a>
                                                <?php 
 $i++;
                                             } } else{ ?>
                                             <div class="noContestInfo_95860">You haven't joined any contest</div>
                                             <?php  } ?>
                                             </div>

                                             <div id="live" class="tabs_match">
                                             <?php if(count($live_match) > 0) { foreach ($live_match as $live) {
                                              $team_one =   $this->Website_model->get_team_by_id($live['teamid1']);
                                              $team_two =   $this->Website_model->get_team_by_id($live['teamid2']);
                                            
                                              ?>
                                              
                                                <a class="js--match-card matchCard_868db" href="<?php echo site_url('website/contest?match='.$live['match_id']); ?>">
                                                   <div class="card card_690e1">
                                                      <div class="gradient_28499">
                                                         <div class="matchCardDetail_c54ac">
                                                            <div>
                                                               <div class="lazy-loader lazy-loader--loaded" style="height: 68px; width: 68px; margin-top:11px;"><img class="lazy-loader__img lazy-loader__img--loaded" src="<?php echo $team_one['team_image']; ?> ">
                                                                   <br>
                                                                <span> <?php echo $team_one['team_name']; ?></span>  <br>
                                                               </div>
                                                            </div>
                                                            <div class="matchCardInfo_9f857" style="margin-top : 19px;">
                                                               
                                                               <div class="timer_defb2">Live</div>
                                                               <div><?php echo $live['type']; ?></div>
                                                               <div class="empty_c9042"><?php echo $team_one['team_short_name']; ?> Vs <?php echo $team_two['team_short_name']; ?></div>
                                                            </div>
                                                            <div>
                                                               <div class="lazy-loader lazy-loader--loaded" style="height: 68px; width: 68px; margin-top:11px;"><img class="lazy-loader__img lazy-loader__img--loaded" src="<?php echo $team_two['team_image']; ?>  ">
                                                                   <br>
                                                                <span> <?php echo $team_two['team_name']; ?></span>  <br>
                                                               </div>
                                                            </div>
                                                         </div>
                                                      </div>
                                                   </div>
                                                </a>
                                                <?php 

                                             } } else{ ?>
                                             <div class="noContestInfo_95860">You haven't joined any contest</div>
                                             <?php  } ?>
                                             </div>


                                             <div id="result" class="tabs_match">
                                             <?php if(count($result_match) > 0) { foreach ($result_match as $result) {
                                              $team_one =   $this->Website_model->get_team_by_id($result['teamid1']);
                                              $team_two =   $this->Website_model->get_team_by_id($result['teamid2']);
                                            
                                              ?>
                                                <a class="js--match-card matchCard_868db" href="<?php echo site_url('website/contest?match='.$result['match_id']); ?>">
                                                   <div class="card card_690e1">
                                                      <div class="gradient_28499">
                                                         <div class="matchCardDetail_c54ac">
                                                            <div>
                                                               <div class="lazy-loader lazy-loader--loaded" style="height: 68px; width: 68px; margin-top:11px;"><img class="lazy-loader__img lazy-loader__img--loaded" src="<?php echo $team_one['team_image']; ?>">
                                                                   <br>
                                                                <span> <?php echo $team_one['team_name']; ?></span>  <br>

                                                               </div>
                                                            </div>
                                                            <div class="matchCardInfo_9f857" style="margin-top : 19px;">
                                                               
                                                               <div class="timer_defb2">Complete</div>
                                                               <div><?php echo $result['type']; ?></div>
                                                               <div class="empty_c9042"><?php echo $team_one['team_short_name']; ?> Vs <?php echo $team_two['team_short_name']; ?></div>
                                                            </div>
                                                            <div>
                                                               <div class="lazy-loader lazy-loader--loaded" style="height: 68px; width: 68px; margin-top:11px;"><img class="lazy-loader__img lazy-loader__img--loaded" src="<?php echo $team_two['team_image']; ?> ">
                                                                   <br>
                                                                <span> <?php echo $team_two['team_name']; ?></span>  <br>

                                                               </div>
                                                            </div>
                                                         </div>
                                                      </div>
                                                   </div>
                                                </a>
                                                <?php 

                                             } } else{ ?>
                                             <div class="noContestInfo_95860">You haven't joined any contest</div>
                                             <?php  } ?>
                                             </div>


                                          </div>
                                       </div>
                                    </div>
                              
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>

                <div class="bottom-nav js--bottom-nav wrapper_cb3ad">
                        <div>
                           <div class="bottom-nav__content">
                              <a class="bottom-nav__element bottom-nav__element--active" href="<?php echo base_url('website/leagues')?>">
                                 <div class="bottom-nav__element__icon"><i class="material-icons">home</i></div>
                                 <div class="bottom-nav__element__content__text">Home</div>
                              </a>
                              <a class="bottom-nav__element" href="<?php echo base_url('website/my_matches')?>">
                                 <div class="bottom-nav__element__icon"><i class="material-icons">star</i></div>
                                 <div class="bottom-nav__element__content__text">My Matches</div>
                              </a>
                              <a class="bottom-nav__element" href="<?php echo base_url('website/me')?>">
                                 <div class="bottom-nav__element__icon"><i class="material-icons">person</i></div>
                                 <div class="bottom-nav__element__content__text">Me</div>
                              </a>
                              <a class="bottom-nav__element" href="<?php echo base_url('website/more')?>">
                                 <div class="bottom-nav__element__icon"><i class="material-icons">more_horiz</i></div>
                                 <div class="bottom-nav__element__content__text">More</div>
                              </a>
                           </div>
                        </div>
                     </div>
               <div></div>
            </div>
         </div>
      </div>
      <noscript>
         <style>
            #app {
            display: none;
            }
            .noscript-header {
            height: 98px;
            background-color: #c51d23;
            display: flex;
            justify-content: center;
            }
            .logo {
            height: 48px;
            padding: 8px;
            }
            .noscript-message {
            color: #888;
            text-align: center;
            height: 400px;
            width: 80%;
            margin: 0 auto;
            display: flex;
            align-items: center;
            justify-content: center;
            }
            .noscript-container {
            max-width: 550px;
            height: 100%;
            }
            .app-bg {
           
            position: fixed;
            left: 550px;
            right: 0;
            background-size: cover;
            top: 0;
            bottom: 0;
            }
         </style>
         <div class="noscript-container">
           
            <div class="noscript-message">Your browser does not support JavaScript.<br>Please upgrade your browser or enable javascript in order to use our website. Thanks!</div>
         </div>
         <div class="app-bg"></div>
      </noscript>
      <div id="fb-root" class=" fb_reset">
         <div style="position: absolute; top: -10000px; width: 0px; height: 0px;">
           
            <div></div>
         </div>
      </div>
      <script type="text/javascript" src="<?php echo base_url('web_assets/js/jquery-3.2.1.js'); ?>"> </script>
      <script>

    $(document).ready(function(){
        $("#fixture_click").addClass("active tabItemSelected_765ac siteTabText_ce5fe") 
        $("#fixture_click").trigger('click');
    });

      function openCity(evt, cityName) {
      //	cityName.addClass("tabItemSelected_765ac");
      	//alert(cityName);   
        var i, tabcontent, tablinks;
        tabcontent = document.getElementsByClassName("tabs_match");
        for (i = 0; i < tabcontent.length; i++) {
          tabcontent[i].style.display = "none"; 
        }
        tablinks = document.getElementsByClassName("siteTabText_ce5fe");
        for (i = 0; i < tablinks.length; i++) {
          tablinks[i].className = tablinks[i].className.replace("active", "");
          tablinks[i].className = tablinks[i].className.replace("tabItemSelected_765ac", "");
        }
        document.getElementById(cityName).style.display = "block";
        evt.currentTarget.className += " active tabItemSelected_765ac siteTabText_ce5fe";
      }


var arr = [];
<?php foreach($match_date as $date){ ?>
arr.push("<?php echo $date; ?>");
<?php } ?>      
for(var i =0;i<arr.length;i++){
//alert(arr[i]);
countdown('demo'+i,arr[i]);

}

function countdown(element, mytime) {
    // Fetch the display element
    var el = document.getElementById(element);

    var countDownDate = new Date(mytime).getTime();

// Update the count down every 1 second
var x = setInterval(function() {

  // Get todays date and time
  var now = new Date().getTime();

  // Find the distance between now and the count down date
  var distance = countDownDate - now;

  // Time calculations for days, hours, minutes and seconds
  var days = Math.floor(distance / (1000 * 60 * 60 * 24));
  var hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
  var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
  var seconds = Math.floor((distance % (1000 * 60)) / 1000);

  // Display the result in the element with id="demo"
  document.getElementById(element).innerHTML = days + "d " + hours + "h "
  + minutes + "m " + seconds + "s ";

  // If the count down is finished, write some text 
  if (distance < 0) {
    clearInterval(x);
    document.getElementById(element).innerHTML = "EXPIRED";
  }
}, 1000);
}
</script>
   </script>
   </body>
</html>