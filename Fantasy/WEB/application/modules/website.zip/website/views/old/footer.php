 <footer>
      <div class="footer_top">
        <div class="footer_container">
          <div class="footer_inner">
            <div class="col1">
              <div class="right_col1">
                <div class="left_link_list">
                  <ul>
                    <li>
                      <a href="https://drive.google.com/open?id=1_FrE8Jx5FoYAkz8iXOF0NTjt95g7w7LT" target="_blank">Download App</a>
                    </li>
                    <li>
                       <a href="<?php echo base_url('/website/how_to_play')?>" target="_blank">How to Play</a>
                    </li>                    
                    <li>
                     <a href="<?php echo base_url('/website/pointsystem')?>" target="_blank">Fantasy Cricket</a>
                    </li>
                    
                  </ul>
                </div>
                <div class="right_link_list">
                  <ul>
                    <!--<li>-->
                    <!--  <a href="#" target="_blank">About Us</a> -->
                    <!--</li>-->
                    <li>
                      <a href="#" target="_blank">Careers</a>
                    </li>
                    <li>
                      <a href="#" target="_blank">Helpdesk</a>
                    </li>
                   
                  </ul>
                </div>
              </div>
              
               <div class="left_col1">
                <div class="footer_logo">
                  <center>
                  <a href="#">
                    <img src="<?php echo base_url('web_assets/image/logo.png')?> " width="134" height="128" alt="">
                  </a>
                  </center>
                </div>
                <div class="footer_social">
                  
                </div>
              </div>
              <!-- <div class="more_link">More</div> -->
            </div>
            
            <div class="col2">
              <div class="office_address">
            <!--<h3>CORPORATE OFFICE</h3>-->
            <!--<div class="address" style="text-align: center;">Da seing Apartments Narendra dam lane laban shillong 793001</div>-->
          </div>
              
            </div>
          </div>
          
          <div class="disclaimer_box">
            <h3>DISCLAIMER</h3>
            <div class="disclaimer">Unless otherwise explicitly specified, Cricaddaonline is not affiliated in any way to and claims no association, in any capacity whatsoever, with any sports governing bodies and leagues, including, but not limited to the Board of Control for Cricket in India (BCCI) or the Indian Premier League (IPL).</div>
          </div>
        </div>
      </div>
    </footer>
  </div>
</body></html>