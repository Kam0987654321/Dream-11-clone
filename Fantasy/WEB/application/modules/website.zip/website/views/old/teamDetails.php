
<!-- saved from url=(0071)https://www.dream11.com/cricket/leagues/womens-challenger-cup/956/13069 -->
<html lang="en"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
  
  
    <title>My teams</title>   

  <style>:root{COMMENT:// DEPRECATED: Use jssVariables instead;--color:#323232;--primary-bg-color:#c51d23;--primary-fg-color:#FFF;--primary-selected-bg-color:#ab1a1f;--secondary-fg-color:#888;--button-height:48px;--icon-color:var(--color);--primary-btn-color:#3759a5;--secondary-btn-color:#3759a5;--box-shadow-light:0px 1px 4px 0px rgba(0, 0, 0, 0.2);--box-shadow-dark:0 1px 2px 0 rgba(0, 0, 0, 0.3);--large-button-height:50px;--icon-size:24px;--font-x-small:10px;--font-small:12px;--font-medium:14px;--font-large:24px;--currency-font-color:inherit}</style>
  <style id="app-style">.appContainer_6475d{max-width:550px;height:100%}.appBgImage_fd065{position:fixed;left:550px;right:0;background-size:cover;top:0;bottom:0}.home_fed50{height:100%}.appToolbar_1ea26{max-width:550px;left:0;top:0;width:100%;position:fixed;box-shadow:0px 1px 4px 0px rgba(0, 0, 0, 0.3);z-index:2}.homeToolbar_7b795{display:flex;align-items:center;justify-content:space-between}.headerElement_af700{display:flex;flex:1}.left_a1d14{justify-content:flex-start}.logo_32840{height:48px;padding:8px}.right_c98d9{justify-content:flex-end}.tab_4e2e6{background-color:#c51d23;color:#fff;display:flex;flex-wrap:nowrap;overflow-x:auto;width:100%;max-width:550px;margin:auto;padding:0 8px}.tabItemSelected_765ac{border-bottom:solid 2px #fff !important;opacity:1 !important}.tabItem_66759{align-items:center;border-bottom:solid 2px #c51d23;display:flex;flex:1 0 auto;height:48px;min-width:80px;justify-content:center;cursor:pointer;transition:all ease-in 300ms;opacity:0.6}.siteTab_56f2f{display:flex;justify-content:center;align-items:center}.siteTabText_ce5fe{text-transform:uppercase}.homeListContainer_55b59{padding-top:96px;height:100%}.carouselContainer_cbc2d{position:relative}.carousel_db1fc{overflow:hidden}.carouselContent_4b30b{transition:all 300ms 0ms}.carouselContentStopAnimation_1677b{transition:none;will-change:transform}.homeList_029e0{display:flex}.matchListContainer_ca5d2{display:flex;flex-direction:column;max-width:550px;-webkit-overflow-scrolling:touch;width:100%;height:100%;overflow-y:scroll;overflow-x:hidden}.feedBannerShell_6873c{display:flex;align-items:center;justify-content:center;background-color:#f4f4f4;background-clip:content-box;padding:12px}.feedBannerDesktop_fee7d{height:240px}.blockLoader_580b6{margin:12px auto}.loaderCircular_00f73{animation:loader-rotate 2s linear infinite}.loaderPath_00e5f{animation:loader-stroke 1.5s ease-in-out infinite;stroke-dasharray:1, 162;stroke-dashoffset:0;stroke-linecap:round;stroke-width:6}.black_7fbc4{stroke:rgba(0, 0, 0, 0.5)}.headerContainer_b77fa{padding-left:8px;width:100%}.header_e8b8b{width:100%;display:flex;justify-content:space-between;align-items:center;height:40px}.card_690e1{background-color:#fff;margin:8px;box-shadow:0 1px 2px 0 rgba(0, 0, 0, 0.3);border-radius:2px;overflow:hidden}.matchCardDetail_c54ac{display:flex;justify-content:space-around;align-items:center;height:100px;width:100%}.matchCardInfo_9f857{display:flex;flex-direction:column;align-items:center;height:65px;justify-content:space-between}.empty_c9042{height:10px}.homeListContainerPadding_1b8cf{padding-bottom:55px}.filterContainer_17b8d{display:flex;font-size:10px}.matchCard_868db{text-decoration:none;color:inherit}.gradient_28499{background:linear-gradient(132deg, white 49%, #f4f4f4 49%)}.bigFlag_78f81{max-width:68px;max-height:68px}.tourNameLabel_d619f{color:#9b9b9b;font-size:10px;width:150px;text-align:center}.timer_defb2{color:#c61c23;font-family:monospace}.feedbannerContainer_c08f0{display:flex;flex-direction:row;padding:8px}.feedBanner_52d71{-webkit-overflow-scrolling:touch;overflow-x:hidden;padding:12px}.feedBannerImage_01eb7{height:100%;width:100%;border-radius:8px}.wrapper_cb3ad{max-width:550px;z-index:4;height:55px}.carouselNavigatorButton_46966{width:36px;height:36px;border-radius:50%;display:flex;justify-content:center;align-items:center;position:absolute;top:50%;transform:translateY(-50%);background-color:rgba(255, 255, 255, 0.5);margin:0 4%;cursor:pointer}.carouselNavigatorButtonNext_b9b75{right:0}.carouselNavigationIndicatorContainer_b9ae4{display:flex;justify-content:center}.carouselNavigationIndicator_5b004{width:12px;height:2px;margin:2px}.carouselNavigationIndicatorActive_21990{background-color:rgb(123, 122, 122)}.carouselNavigationIndicatorInactive_43a73{background-color:rgba(123, 122, 122, 0.3)}.loaderContainer_d2930{display:flex;height:100%;align-items:center}.fadeIn_73e97{animation:fade-in .25s linear}.contestHome_789e2{padding-top:100px;padding-bottom:50px;background-color:#efeff4;min-height:100%}
  .headerContainer_199c8{ background: linear-gradient(63deg, #00255c 42%,#00bcac 72%) !important;color:#FFF;z-index:2}
  .headerFixed_38df7{position:fixed;top:0;max-width:550px;width:100%}.headerRow_c14ad{display:flex;justify-content:space-between;height:50px}.headerLeft_36c4e{display:flex;flex:1 0 0;justify-content:flex-start;align-items:center}.headerCenter_4d6f0{display:flex;flex:1 0 0;justify-content:center;align-items:center}.headerTitle_fd62d{text-transform:uppercase;white-space:nowrap}.headerRight_ba2d2{display:flex;flex:1 0 0;justify-content:flex-end;align-items:center}
  .infobar_0dc07{ background: linear-gradient(63deg, #00255c 42%,#00bcac 72%) !important;height:50px;padding:8px}
  .infobarContent_628aa{background-color:#FFF;height:100%;color:#323232;border-radius:2px;display:flex;justify-content:center;align-items:center;padding:8px}.contestsHeader_16599{padding:12px;border-bottom:1px solid #dcdcdc}.playWithFriendsWrapper_3442c{display:flex;justify-content:space-between}.contestCountInfo_cc447{padding-top:16px;color:#969696}.segmentHeaderContainer_54896{position:sticky;top:100px;display:flex;background-color:#efeff4;z-index:1;align-items:center;justify-content:space-between;padding:0 12px}.row_404ce{align-items:center;display:flex;height:60px;text-decoration:none;color:#7b7a7a}.segmentHeaderShell_a64fc{display:flex;height:100%;flex-direction:column;justify-content:space-evenly}.headerTitle_ba6eb{color:#333232;font-weight:bold;font-size:16px}.headerText_d7966{font-size:12px;margin-top:2px}.contestCardWrapper_c83dd{border-radius:4px;display:block;margin:0 12px 16px 12px;box-shadow:0 1px 3px 0 rgba(0, 0, 0, 0.1), 0 4px 6px 0 rgba(0, 0, 0, 0.05);background-color:#fff;text-decoration:none}.contestSpecMoneyInfo_20124{width:100%;display:flex;flex-direction:column;padding:12px}.contestSpecRow_01429{display:flex;justify-content:space-between;align-items:center;padding-bottom:8px}.contestCardLabel_7ca40{font-size:12px;color:#969696}.prizePool_565d2{font-size:20px;font-weight:500;color:#282828}.contestProgressBarContainer_0efc1{padding:0 12px}.contestProgressBar_eba45{height:8px;display:flex;justify-content:flex-end;transform:skew(-20deg);background-image:linear-gradient(to right, #ffc81e, #e10000)}.contestProgressInner_ead13{background-color:#f2f2f2;height:8px}.idleProgressBar_3ec17{width:100%}.spotsContainer_9c427{padding:8px 12px 0 12px}.spotLefts_8d583{font-size:12px;font-weight:500}.totalSpots_b62ba{color:#969696;font-size:12px;font-weight:500}.contestSpec_a3ebb{background-color:#f8f8f8;border-top:1px solid #f4f4f4;padding:12px;font-size:12px;height:32px;display:flex;border-radius:0 0 4px 4px;align-items:center}.iconLabelGroup_f55e1{display:inline-flex;width:50%}.container_607ce{background-color:#3759a5;bottom:0;position:fixed;width:100%;max-width:550px;z-index:3;animation:contest-footer-animate-in 300ms cubic-bezier(0, 0, 0, 1)}.infobarContentRow_7ae93{display:flex;width:100%;font-size:12px}.infobarContentLeft_04a34{flex:1 0 0}.infobarContentCenter_5f791{flex:1 0 0;text-align:center}.timer_1aa54{font-family:monospace;display:flex;justify-content:center;align-items:center;color:#c51d23}.materialIcon_10a4f{font-family:Material Icons;font-weight:normal;font-style:normal;display:inline-block;line-height:1;text-transform:none;letter-spacing:normal;word-wrap:normal;white-space:nowrap;direction:ltr}.timeRemaining_96d65{margin-left:4px}.infobarContentRight_ac9bd{flex:1 0 0;text-align:right}.raisedWhiteButtonNew_08689{background:none;border:0;cursor:pointer;margin:0;text-decoration:none;text-align:center;font-family:inherit;display:flex;justify-content:center;align-items:center;color:inherit;font-weight:500;font-size:12px;height:32px;padding:0 8px;width:156px;border-radius:4px;background-color:#fff;box-shadow:0 1px 3px 0 rgba(0, 0, 0, 0.1), 0 4px 6px 0 rgba(0, 0, 0, 0.05)}.iconLabel_fe3d5{display:flex;align-item:center;justify-content:space-between;font-size:12px;width:100%}.iconContent_3cbfd{padding-left:4px}.flatGreenButton_fb7a7{background:none;border:0;cursor:pointer;margin:0;text-decoration:none;text-align:center;font-family:inherit;display:flex;justify-content:center;align-items:center;color:#fff;font-weight:500;font-size:12px;height:28px;padding:0 8px;width:76px;border-radius:4px;background-color:#00b137}.contestFilling_14509{color:#ffa01e}.iconLabelWrapper_43690{display:flex;justify-content:space-between;color:#969696}.squareWithTwoRoundCorner_1291a{width:20px;height:20px;padding:2px;font-size:12px;color:#969696;border:1px solid #969696;border-radius:2px 0 2px 0;display:flex;justify-content:center}.moreLink_570df{color:#00a0ff;justify-content:space-between;align-items:center;text-decoration:none;height:35px}.flexRow_029e0{display:flex}.allContestsButtonSegment_d9602{padding:10px 0;display:flex;flex-direction:column;align-items:center}.allContestsButtonSegmentHeader_a44f9{margin-bottom:16px;line-height:1.5}.innerContainer_b8f9b{padding:8px}.joinedContest_e8f66{padding-top:112px;min-height:100%;background-color:#efeff4}.headerShadow_22469{box-shadow:0px 1px 4px 0px rgba(0, 0, 0, 0.3)}.sharingBox_d2571{padding:8px 16px;display:flex;justify-content:space-between;color:#969696;background-color:#f8f8f8;font-size:14px;font-weight:normal;align-items:center;border-bottom:1px solid #f4f4f4}.noContestJoined_1d9ed{margin:16px 0}.headerContainer_1725f{background:linear-gradient(104deg, #3c3c3c 47%, #323232 47%);display:flex;flex-direction:column;z-index:2}.defaultHeaderContent_00a63{display:flex;justify-content:space-between;color:#FFF;height:48px}.headerRight_d1c5d{display:flex;flex:1 0 0;justify-content:flex-end;align-items:center;margin-right:12px}.guruIcon_0a307{height:24px;width:24px;margin-right:12px}.container_aa549{display:flex;flex-direction:column;height:136px}.maxInfoText_13e5b{font-size:12px;color:#fff;display:flex;align-self:center;margin-bottom:12px}.infoContent_0b612{display:flex;justify-content:space-around}.playerSelectionContainerLoader_68e5b{display:flex;flex-direction:column;justify-content:space-evenly}.flagContainer_029e0{display:flex}.squadOneText_3ad2c{display:flex;flex-direction:column;color:#acacac;margin-left:4px}.squadTwoText_b9766{display:flex;flex-direction:column;color:#acacac;margin-left:4px;align-items:flex-end;margin-right:4px}.infoLoaderProgressContainer_51138{display:flex;justify-content:center;margin:24px 16px 16px}.mainWrapper_8542d{background:#fafafa;padding-bottom:90px;overflow-y:hidden}.tabsMainContainer_a916e{background:#fff;position:fixed;top:184px;z-index:2;max-width:550px;width:100%}.tabsWrapper_43944{max-width:550px;overflow-x:hidden}.createTeamTabsContainer_5ba85{display:flex;flex:1 0 0;justify-content:center;cursor:pointer}.roleTabItem_603ae{height:48px;display:flex;align-items:center;justify-content:center;width:100%;color:#9c9c9c;letter-spacing:1px}.createTeamTabsHelpContainer_ce9c9{height:44px;display:flex;align-items:center;color:#000;justify-content:center;background-color:#efeff4}.ctSortingHeader_a6515{display:flex;height:36px;color:#acacac;font-size:12px;border-bottom:1px solid #e8e8e8;padding-left:16px}.playerCardCell_bf9d8{display:flex;align-items:center;white-space:nowrap;text-overflow:ellipsis;overflow:hidden}.playerCardAvatarCell_2b8d1{flex:0 0 60px}.playerCardInfoCell_ba412{display:flex;flex-grow:1}.playerCardNameCell_50086{flex-grow:3;flex-basis:80px}.playerPointsCell_aa0e3{flex-grow:1;flex-basis:60px;justify-content:center}.activeSortKey_c7202{color:#000}.sortingHeaderIconPlaceHolder_43273{display:flex;flex-basis:70px}.playerListContainer_e09a1{margin-top:312px;overflow-y:scroll}.playerCard_42b9d{background-color:#fff;display:flex;height:72px;padding-left:16px;transition:background-color 300ms cubic-bezier(0, 2, 1, 1)}.playerCardInfoContainer_d41f9{border-bottom:1px solid #e8e8e8}.playerCardIconContainer_65be8{display:flex;flex-basis:70px;justify-content:center;margin:10px 0;border-left:1px solid #e8e8e8}.footer_d9cd3{height:40px;position:fixed;margin-bottom:16px;width:100%;max-width:550px;z-index:3;bottom:0px}.footerButtonContainer_b9ae4{display:flex;justify-content:center}.disabledButton_cf79e{opacity:0.5;cursor:not-allowed}.raisedGreenButton_20c05{background:#25ba38;border:0;cursor:pointer;margin:0;text-decoration:none;text-align:center;font-family:inherit;display:flex;justify-content:center;align-items:center;color:#fff;font-weight:500;font-size:12px;height:32px;padding:8px 8px;text-transform:uppercase;width:120px;border-radius:4px;box-shadow:0 4px 8px 0 rgba(0, 0, 0, 0.2);}.raisedGreenButtonDisabled_e0a23{background:#dcdcdc;color:#969696;opacity:1}.timer_3d48d{color:#fff}.floatingAnchorButton_fac02{font-weight:600;text-decoration:none;color:#3759a5}.helpLink_4c95c{display:flex;justify-content:center;align-items:center;height:24px;width:24px;border:solid 1px #acacac;border-radius:50%;color:#acacac}.playerSelectionContainer_d8646{display:flex;flex-direction:column;color:#acacac;font-size:12px;margin-left:16px}.squadTextContainer_3e550{display:flex;font-size:12px}.selectedCount_daee8{font-size:24px;color:#fff}.totalCount_c1f66{padding-top:10px}.flagContainer_47acd{display:flex;align-items:center;justify-content:space-around;margin:0 4px}.flag_008b5{width:44px;height:44px;border-radius:50%}.teamName_a2024{font-size:12px}.teamCount_84ce0{font-size:16px;color:#fff;margin-top:4px}.creditsContainer_e7f97{display:flex;flex-direction:column;color:#acacac;font-size:12px;margin-right:16px}.creditsText_a4625{color:#fff;font-size:24px;display:flex;justify-content:flex-end}.progressContainer_00657{margin:24px 16px 16px}.stepperContainer_b9ae4{display:flex;justify-content:center}.stepperBlock_8b62f{width:36px;height:16px;font-size:12px;transform:skew(-20deg);border:1px solid #323232;display:flex;justify-content:center;align-items:center}.inactiveStepper_4d390{background-color:#fff}.lastStepper_2bce1{font-size:12px;color:#000;transform:skew(20deg)}.roleTabWrapper_a3522{display:block;width:100%}.createTeamTabTitle_99a5a{display:flex;justify-content:center;font-weight:600;font-size:16px}.createTeamTabsCount_19658{display:flex;align-items:center;justify-content:center;font-size:12px}.roleTabHighlight_ee4c9{transform:skew(-20deg);height:4px;width:100%}.roleTabHighlightActive_28bb8{background-color:#c51d23}.roleTabHighlightInactive_4d390{background-color:#fff}.imageContainer_029e0{display:flex}.playerImageProfile_43b1b{height:48px;width:48px}.playerImageContainer_6e52e{display:flex;flex-direction:column;overflow:hidden;height:100%;width:100%}.playerImage_f320d{width:100%;flex:1;background-size:cover;background-repeat:no-repeat;border-radius:50%;background-color:#969696}.playerName_73cad{flex-basis:44px;justify-content:center;color:#00a0ff}.playerTeamTitle_a2024{font-size:12px}.playerCardIcon_b8a19{border-radius:50%;color:#24ba38;align-self:center;border:1px solid}.desktopTeamPreviewContainer_61fb1{position:fixed;left:550px;width:550px;height:100%;top:0;max-width:550px}.content_60710{background-repeat:no-repeat;background-size:cover;background-position:center;min-height:100%;display:flex;flex-direction:column;height:100%}.toolbar_650b2{width:100%;background-color:transparent;flex:0;position:fixed;height:48px;z-index:2;max-width:550px}.toolbarElementMain_7948b{flex:1;display:flex}.toolbarElementLeft_19260{justify-content:flex-start;color:#fff;padding:8px}.toolbarElementRight_c98d9{justify-content:flex-end}.toolbarElementIcon_3d48d{color:#fff}.playerArea_eac11{position:relative;height:100%;overflow:scroll}.emptyStateWrapper_1b95a{display:flex;align-items:center;flex-direction:column;padding:8px;background:#00000059;border-radius:4px;position:absolute;left:50%;top:50%;transform:translate(-50%, -50%)}.emptyStateText_2c68c{padding:8px;color:#fff;font-weight:bold;white-space:nowrap}.leaderboard_c97e9{padding-top:100px}.spaceAround_64779{justify-content:space-around}.tall_56497{position:absolute;top:0;left:0;min-height:100%;width:100%;display:flex;flex-direction:column;justify-content:space-evenly;padding:24px 0 60px 0}.teamPreviewRowWrapper_0c54c{width:100%;padding-top:8px}.rowTitle_b91f3{margin-bottom:4px;text-align:center;color:#fff;text-transform:uppercase;font-size:var(--font-small);opacity:0.52}.rowContent_8aa5f{display:flex;justify-content:space-evenly;align-items:center;padding:8px 0;height:85px}.fieldPlayerMain_32975{display:flex;flex-direction:column;align-items:center}.playerImageProfile_0cc1f{height:38px;width:38px;border-radius:10px 0;position:relative}.imageProfileContainer_6e52e{display:flex;flex-direction:column;overflow:hidden;height:100%;width:100%}.fieldPlayerTitle_4ac32{width:65px;overflow:hidden;text-overflow:ellipsis;color:#fff;text-align:center;font-size:var(--font-small);white-space:nowrap;box-shadow:0 2px 2px 0 rgba(0, 0, 0, 0.25);border-radius:2px;padding:0 4px}.playerPoints_d4e06{white-space:nowrap;color:#fff;text-align:center;padding:2px;font-size:var(--font-small)}.activeStepper_2007e{background-color:#00a037}.activeNumber_89478{font-size:12px;color:#fff;transform:skew(20deg)}.playerCardSelected_ae508{background-color:#fff7ec}.playerCardIconSelected_4b666{color:#ffa500}.playerCardDisable_84b1d{opacity:0.5}.playerCardIconDisabled_a0371{color:#888}.lastStepperActive_3d48d{color:#fff}.eePage_1602f{max-width:550px;z-index:5}.roleSelector_d9dd6{max-width:550px}.content_5e15a{padding-bottom:90px}.titleBox_a1dab{max-width:550px;background-color:#efeff4;padding:16px;text-align:center;margin:auto;position:sticky;top:0}.titleBoxWebkit_3d076{position:-webkit-sticky}.rolesTitle_48372{text-transform:lowercase}.subtitleContainer_b9ae4{display:flex;justify-content:center}.roleSubtitle_62c2d{display:flex;padding:0 8px}.roleIcon_f75d0{width:24px;height:24px;border-radius:50%;display:flex;align-items:center;justify-content:center;border:1px solid #9b9b9b;color:#9b9b9b;font-size:10px;margin-right:8px}.roleMultiplierText_07275{color:#000;margin-top:4px}.sortingHeader_580ae{display:flex;padding-left:16px;color:#acacac;height:36px;font-size:12px;background-color:#fff;border-bottom:1px solid #e8e8e8}.playerCardAvatarCell_4541e{flex-basis:60px}.rolesContainer_7991a{display:flex;flex:0 0 100px;align-items:center}.playerCard_4a779{background-color:#fff;display:flex;height:72px;padding-left:16px}.roleIcon_b2caf{height:40px;width:40px;border-radius:50%;border:1px solid #9b9b9b;display:flex;color:#9b9b9b;justify-content:center;align-items:center}.roleSelected_961ad{background-color:#000;color:#fff}.dialog_fe4fb{max-width:550px;z-index:7}.loadingDialog_7ce16{display:flex;align-items:center}.loader_fdaf1{margin-right:12px}.contestFooterCount_bca66{background-color:#fff;border-radius:8px;color:#3759a5;height:15px;line-height:15px;margin:0 0 0 4px;width:16px}.joiningAmountText_db306{font-weight:700}.wrapper_de051{max-width:550px;z-index:8}.message_d58fc{color:#fff;padding:36px 8px 0px 8px;text-align:center}.success_152aa{background-color:#2eb13e}.currentUserRow_2fe09{background-color:#e5f1ff}.switchTeam_ecbc8{display:flex;padding:8px;justify-content:space-between;align-items:center;border-top:1px solid #e8e8e8}.entryFeeInfo_7de8d{font-size:14px;color:#969696}.teamRowSelected_ae508{background-color:#fff7ec}.largeButtonAnchor_fe158{background:none;border:0;cursor:pointer;margin:0;text-decoration:none;text-align:center;font-family:inherit;display:flex;justify-content:center;align-items:center;color:inherit;font-weight:500;font-size:14px;height:48px;padding:0 8px;width:48px}.whiteColoredButton_bb22b{background:none;border:0;cursor:pointer;margin:0;text-decoration:none;text-align:center;font-family:inherit;display:flex;justify-content:center;align-items:center;color:#FFF;font-weight:500;font-size:12px;height:32px;padding:0 8px;outline:none}.previewFooter_23016{position:fixed;bottom:0;right:0;height:56px;background:#323232;max-width:550px}.previewFooterDesktop_4721a{left:550px}.leaderboardPreviewFooter_3ec17{width:100%}.footerElement_4be2d{display:flex;justify-content:flex-start;width:100%}.footerPointsContainer_9f0ad{height:100%;display:flex;flex-direction:column;align-items:center;justify-content:space-around;padding:8px}.footerElementValue_bfa59{font-size:16px;color:#fff}.footerElementKey_415ad{font-size:8px;color:#ADADAD;text-transform:uppercase;text-align:center}.white_bec4c{stroke:#fff}.error_a70e4{background-color:#f68323}.eePageFixed_47676{position:fixed;height:100%;width:100%;top:0;left:0}.eePageContent_28f9a{height:100%;background-color:#fafafa;box-shadow:0 1px 2px 0 rgba(0, 0, 0, 0.3)}.wrapper_d9dd6{max-width:550px}.topSection_083bc{display:flex;justify-content:space-between;align-items:center;padding:8px}.bottomSection_d41f9{border-bottom:1px solid #e8e8e8}.buttonBar_09c83{display:flex;justify-content:space-between;align-items:center}.leftPad_ef490{padding-left:8px}.resetButton_62ab8{background:none;border:0;cursor:pointer;margin:0;text-decoration:none;text-align:center;font-family:inherit;display:flex;justify-content:center;align-items:center;color:inherit;font-weight:500;font-size:14px;height:32px;padding:0 8px}.primaryButtonAlign_02538{display:flex;align-items:center;font-size:12px;color:#3759a5;outline:none}.footer_d9dd6{max-width:550px}.lowBalanceDialogNote_cdbae{margin-top:4px;font-size:10px}</style>

  <!-- iPhone shortcut icon -->
  <!--PRELOAD-->
  <link rel="preload" as="style" href="<?php echo base_url('web_assets/css/montserrat-400,500,600-v2.css');?>">
  <link rel="preload" as="font" href="<?php echo base_url('web_assets/css/MaterialIcons-Regular.woff2')?>">
  <link rel="preload" as="script" href="<?php echo base_url('web_assets/js/vendors_main-94f6173ba06a2c8ab3e4-chunktemp.js')?>">
  <link rel="preload" as="script" href="<?php echo base_url('web_assets/js/main-16b8e4fad8086ea0f5a0-chunktemp.js')?>">
 
  <link rel="stylesheet" href="<?php echo base_url('web_assets/css/main-896fb0a9b3dd7a48c082-chunktemp.css'); ?>">
  <link href="<?php echo base_url('web_assets/css/montserrat-400,500,600-v2.css'); ?>" rel="stylesheet">
  <script>if('serviceWorker' in navigator) navigator.serviceWorker.register('/sw.js')</script>
<meta http-equiv="google-site-verification" content="h6JUgqX9dMFO0C4E5VqUOBK7lb6vuDQOyebWaxUzBEc"><script type="text/javascript" charset="utf8" async="" src="./teamlist_files/platform.js.download" gapi_processed="true"></script><style type="text/css">.fb_hidden{position:absolute;top:-10000px;z-index:10001}.fb_reposition{overflow:hidden;position:relative}.fb_invisible{display:none}.fb_reset{background:none;border:0;border-spacing:0;color:#000;cursor:auto;direction:ltr;font-family:"lucida grande", tahoma, verdana, arial, sans-serif;font-size:11px;font-style:normal;font-variant:normal;font-weight:normal;letter-spacing:normal;line-height:1;margin:0;overflow:visible;padding:0;text-align:left;text-decoration:none;text-indent:0;text-shadow:none;text-transform:none;visibility:visible;white-space:normal;word-spacing:normal}.fb_reset>div{overflow:hidden}@keyframes fb_transform{from{opacity:0;transform:scale(.95)}to{opacity:1;transform:scale(1)}}.fb_animate{animation:fb_transform .3s forwards}
.fb_dialog{background:rgba(82, 82, 82, .7);position:absolute;top:-10000px;z-index:10001}.fb_dialog_advanced{border-radius:8px;padding:10px}.fb_dialog_content{background:#fff;color:#373737}.fb_dialog_close_icon{background:url(https://static.xx.fbcdn.net/rsrc.php/v3/yq/r/IE9JII6Z1Ys.png) no-repeat scroll 0 0 transparent;cursor:pointer;display:block;height:15px;position:absolute;right:18px;top:17px;width:15px}.fb_dialog_mobile .fb_dialog_close_icon{left:5px;right:auto;top:5px}.fb_dialog_padding{background-color:transparent;position:absolute;width:1px;z-index:-1}.fb_dialog_close_icon:hover{background:url(https://static.xx.fbcdn.net/rsrc.php/v3/yq/r/IE9JII6Z1Ys.png) no-repeat scroll 0 -15px transparent}.fb_dialog_close_icon:active{background:url(https://static.xx.fbcdn.net/rsrc.php/v3/yq/r/IE9JII6Z1Ys.png) no-repeat scroll 0 -30px transparent}.fb_dialog_iframe{line-height:0}.fb_dialog_content .dialog_title{background:#6d84b4;border:1px solid #365899;color:#fff;font-size:14px;font-weight:bold;margin:0}.fb_dialog_content .dialog_title>span{background:url(https://static.xx.fbcdn.net/rsrc.php/v3/yd/r/Cou7n-nqK52.gif) no-repeat 5px 50%;float:left;padding:5px 0 7px 26px}body.fb_hidden{height:100%;left:0;margin:0;overflow:visible;position:absolute;top:-10000px;transform:none;width:100%}.fb_dialog.fb_dialog_mobile.loading{background:url(https://static.xx.fbcdn.net/rsrc.php/v3/ya/r/3rhSv5V8j3o.gif) white no-repeat 50% 50%;min-height:100%;min-width:100%;overflow:hidden;position:absolute;top:0;z-index:10001}.fb_dialog.fb_dialog_mobile.loading.centered{background:none;height:auto;min-height:initial;min-width:initial;width:auto}.fb_dialog.fb_dialog_mobile.loading.centered #fb_dialog_loader_spinner{width:100%}.fb_dialog.fb_dialog_mobile.loading.centered .fb_dialog_content{background:none}.loading.centered #fb_dialog_loader_close{clear:both;color:#fff;display:block;font-size:18px;padding-top:20px}#fb-root #fb_dialog_ipad_overlay{background:rgba(0, 0, 0, .4);bottom:0;left:0;min-height:100%;position:absolute;right:0;top:0;width:100%;z-index:10000}#fb-root #fb_dialog_ipad_overlay.hidden{display:none}.fb_dialog.fb_dialog_mobile.loading iframe{visibility:hidden}.fb_dialog_mobile .fb_dialog_iframe{position:sticky;top:0}.fb_dialog_content .dialog_header{background:linear-gradient(from(#738aba), to(#2c4987));border-bottom:1px solid;border-color:#1d3c78;box-shadow:white 0 1px 1px -1px inset;color:#fff;font:bold 14px Helvetica, sans-serif;text-overflow:ellipsis;text-shadow:rgba(0, 30, 84, .296875) 0 -1px 0;vertical-align:middle;white-space:nowrap}.fb_dialog_content .dialog_header table{height:43px;width:100%}.fb_dialog_content .dialog_header td.header_left{font-size:12px;padding-left:5px;vertical-align:middle;width:60px}.fb_dialog_content .dialog_header td.header_right{font-size:12px;padding-right:5px;vertical-align:middle;width:60px}.fb_dialog_content .touchable_button{background:linear-gradient(from(#4267B2), to(#2a4887));background-clip:padding-box;border:1px solid #29487d;border-radius:3px;display:inline-block;line-height:18px;margin-top:3px;max-width:85px;padding:4px 12px;position:relative}.fb_dialog_content .dialog_header .touchable_button input{background:none;border:none;color:#fff;font:bold 12px Helvetica, sans-serif;margin:2px -12px;padding:2px 6px 3px 6px;text-shadow:rgba(0, 30, 84, .296875) 0 -1px 0}.fb_dialog_content .dialog_header .header_center{color:#fff;font-size:16px;font-weight:bold;line-height:18px;text-align:center;vertical-align:middle}.fb_dialog_content .dialog_content{background:url(https://static.xx.fbcdn.net/rsrc.php/v3/y9/r/jKEcVPZFk-2.gif) no-repeat 50% 50%;border:1px solid #4a4a4a;border-bottom:0;border-top:0;height:150px}.fb_dialog_content .dialog_footer{background:#f5f6f7;border:1px solid #4a4a4a;border-top-color:#ccc;height:40px}#fb_dialog_loader_close{float:left}.fb_dialog.fb_dialog_mobile .fb_dialog_close_button{text-shadow:rgba(0, 30, 84, .296875) 0 -1px 0}.fb_dialog.fb_dialog_mobile .fb_dialog_close_icon{visibility:hidden}#fb_dialog_loader_spinner{animation:rotateSpinner 1.2s linear infinite;background-color:transparent;background-image:url(https://static.xx.fbcdn.net/rsrc.php/v3/yD/r/t-wz8gw1xG1.png);background-position:50% 50%;background-repeat:no-repeat;height:24px;width:24px}@keyframes rotateSpinner{0%{transform:rotate(0deg)}100%{transform:rotate(360deg)}}
.fb_iframe_widget{display:inline-block;position:relative}.fb_iframe_widget span{display:inline-block;position:relative;text-align:justify}.fb_iframe_widget iframe{position:absolute}.fb_iframe_widget_fluid_desktop,.fb_iframe_widget_fluid_desktop span,.fb_iframe_widget_fluid_desktop iframe{max-width:100%}.fb_iframe_widget_fluid_desktop iframe{min-width:220px;position:relative}.fb_iframe_widget_lift{z-index:1}.fb_iframe_widget_fluid{display:inline}.fb_iframe_widget_fluid span{width:100%}
.fb_customer_chat_bounce_in_v2{animation-duration:300ms;animation-name:fb_bounce_in_v2;transition-timing-function:ease-in}.fb_customer_chat_bounce_out_v2{animation-duration:300ms;animation-name:fb_bounce_out_v2;transition-timing-function:ease-in}.fb_customer_chat_bounce_in_v2_mobile_chat_started{animation-duration:300ms;animation-name:fb_bounce_in_v2_mobile_chat_started;transition-timing-function:ease-in}.fb_customer_chat_bounce_out_v2_mobile_chat_started{animation-duration:300ms;animation-name:fb_bounce_out_v2_mobile_chat_started;transition-timing-function:ease-in}.fb_customer_chat_bubble_pop_in{animation-duration:250ms;animation-name:fb_customer_chat_bubble_bounce_in_animation}.fb_customer_chat_bubble_animated_no_badge{box-shadow:0 3px 12px rgba(0, 0, 0, .15);transition:box-shadow 150ms linear}.fb_customer_chat_bubble_animated_no_badge:hover{box-shadow:0 5px 24px rgba(0, 0, 0, .3)}.fb_customer_chat_bubble_animated_with_badge{box-shadow:-5px 4px 14px rgba(0, 0, 0, .15);transition:box-shadow 150ms linear}.fb_customer_chat_bubble_animated_with_badge:hover{box-shadow:-5px 8px 24px rgba(0, 0, 0, .2)}.fb_invisible_flow{display:inherit;height:0;overflow-x:hidden;width:0}.fb_mobile_overlay_active{background-color:#fff;height:100%;overflow:hidden;position:fixed;visibility:hidden;width:100%}@keyframes fb_bounce_in_v2{0%{opacity:0;transform:scale(0, 0);transform-origin:bottom right}50%{transform:scale(1.03, 1.03);transform-origin:bottom right}100%{opacity:1;transform:scale(1, 1);transform-origin:bottom right}}@keyframes fb_bounce_in_v2_mobile_chat_started{0%{opacity:0;top:20px}100%{opacity:1;top:0}}@keyframes fb_bounce_out_v2{0%{opacity:1;transform:scale(1, 1);transform-origin:bottom right}100%{opacity:0;transform:scale(0, 0);transform-origin:bottom right}}@keyframes fb_bounce_out_v2_mobile_chat_started{0%{opacity:1;top:0}100%{opacity:0;top:20px}}@keyframes fb_customer_chat_bubble_bounce_in_animation{0%{bottom:6pt;opacity:0;transform:scale(0, 0);transform-origin:center}70%{bottom:18pt;opacity:1;transform:scale(1.2, 1.2)}100%{transform:scale(1, 1)}}</style>
<!-- <script type="text/javascript" charset="utf8" async="" src="./teamlist_files/abtest-bundle.js"></script>
<script type="text/javascript" src="./teamlist_files/a" rel="nofollow" async=""></script>
<script type="text/javascript" src="./teamlist_files/a(1)" rel="nofollow" async=""></script>
<script type="text/javascript" src="./teamlist_files/a(2)" rel="nofollow" async=""></script>
<style type="text/css" id="qual_style-mzj"></style><style type="text/css" id="qual_style-meu"></style>
<script type="text/javascript" src="./teamlist_files/a(3)" rel="nofollow" async=""></script>
<script charset="utf-8" src="./teamlist_files/0-54e9e8efa031d24c9636-chunktemp.js"></script>
<script charset="utf-8" src="./teamlist_files/1-9762da8c30255aacc832-chunktemp.js"></script>
<script charset="utf-8" src="./teamlist_files/20-37f107844db624cded63-chunktemp.js"></script>
<script charset="utf-8" src="./teamlist_files/24-33258cc99bac52b66b43-chunktemp.js"></script>
<script charset="utf-8" src="./teamlist_files/25-ba493b2e7609c3f403d5-chunktemp.js"></script>
<script type="text/javascript" src="./teamlist_files/a(4)" rel="nofollow" async=""></script>
<script charset="utf-8" src="./teamlist_files/23-72ba053f9782310b4439-chunktemp.js"></script>
<script type="text/javascript" src="./teamlist_files/a(5)" rel="nofollow" async=""></script>
<script type="text/javascript" src="./teamlist_files/a(6)" rel="nofollow" async=""></script>
<script type="text/javascript" src="./teamlist_files/a(7)" rel="nofollow" async=""></script>
<script type="text/javascript" src="./teamlist_files/a(8)" rel="nofollow" async=""></script>
<script type="text/javascript" src="./teamlist_files/a(9)" rel="nofollow" async=""></script>
<script type="text/javascript" src="./teamlist_files/a(10)" rel="nofollow" async=""></script>
<script type="text/javascript" src="./teamlist_files/a(11)" rel="nofollow" async=""></script>
<script type="text/javascript" src="./teamlist_files/a(12)" rel="nofollow" async=""></script>
<script type="text/javascript" src="./teamlist_files/a(13)" rel="nofollow" async=""></script>
<script type="text/javascript" src="./teamlist_files/a(14)" rel="nofollow" async=""></script>
<script type="text/javascript" src="./teamlist_files/a(15)" rel="nofollow" async=""></script> -->
</head>
<body cz-shortcut-listen="true" class="no-scroll">
  <div><div class="app-container appContainer_6475d">
    <div class="appBgImage_fd065"></div>
    <div class="lazy-container-contest-home">
      <div class="lazy-contest-home">
        <div class="contest-home-for-view js--contest-home contestHome_789e2">
          <div>
            <div class="match-header">
            <div class="headerContainer_199c8 headerFixed_38df7">
            <div class="row-1 headerRow_c14ad">
              <div class="headerLeft_36c4e">
                <button class="btn btn--icon">
                	<a href="<?php echo base_url('website/contest?match='.$match['match_id'].''); ?>">
                  <div class="align-center"><i style="color: #FFF;" class="material-icons">arrow_back</i></div></a>
                </button>
                <div class="js--match-header-home-btn">
                  <a class="btn btn--icon" href="<?php echo base_url('website/leagues');?>"><i class="material-icons">home</i></a>
                </div>
              </div>
                <div class="headerCenter_4d6f0">
                  <div class="headerTitle_fd62d">Team Details</div>
              </div>
              <div class="headerRight_ba2d2">
                <button class="btn btn--icon">
                  <div class="align-center">
                  </div>
                </button>
              </div>
            </div>
            <div class="info-bar infobar_0dc07">
              <div class="infobarContent_628aa">
                <div class="infobarContentRow_7ae93">
                  <div class="js--match-header-title infobarContentLeft_04a34"><?php echo $match['title']; ?> </div>
                  <div class="infobarContentCenter_5f791"><div class="timer_1aa54">
                    <i class="materialIcon_10a4f" style="height: 16px; width: 16px; font-size: 16px;">access_time</i>
                    <span class="timeRemaining_96d65">
                      <div class="timer_defb2" id="demo"></div>
                    </span>
                  </div>
                </div>
                <div class="js--guru-link infobarContentRight_ac9bd">
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="account-dialog"></div>
      </div>
      <div>
      </div>
      <div>
        <div class="contestsHeader_16599">
          <div class="playWithFriendsWrapper_3442c">
            <div>
              <button class="new-button raisedWhiteButtonNew_08689">
                <div class="iconLabel_fe3d5">
                  <span class="iconContent_3cbfd">Enter Contest Code</span>
                  <i class="materialIcon_10a4f" style="height: 14px; width: 14px; font-size: 14px;">input</i>
                </div>
              </button>
            </div>
            <div>
             
              </div>
            </div>
            <div class="contestCountInfo_cc447">99 contests available</div>
          </div>
          <div>
            <div class="segmentHeaderContainer_54896"><a class="row_404ce"><div><div class="">
              <div class="headerTitle_ba6eb">Team Details</div>
              <div class="headerText_d7966">Get ready for mega winnings!</div>
            </div>
          </div>
        </a>
        
          <div class="ee-page eePage_1602f eePageFixed_47676">
            <div class="page__ee-animation--enter eePageContent_28f9a">
              <div class="my-teams">
                <div>
          <div class="match-header">
            <div class="headerContainer_199c8 headerFixed_38df7 headerShadow_22469">
              <div class="row-1 headerRow_c14ad">
                <div class="headerLeft_36c4e">
                  <button class="btn btn--icon">
                    <div class="align-center">
                      <i class="material-icons">close</i>
                    </div>
                  </button>
                  </div>
                  <div class="headerCenter_4d6f0">
                    <div class="headerTitle_fd62d">my teams</div>
                  </div>
                  <div class="headerRight_ba2d2"></div>
                </div>
                <div class="info-bar infobar_0dc07">
                  <div class="infobarContent_628aa">
                    <div class="infobarContentRow_7ae93">
                      <div class="js--match-header-title infobarContentLeft_04a34">INW-R vs INW-G</div>
                      <div class="infobarContentCenter_5f791">
                        <div class="timer_1aa54">
                          <i class="materialIcon_10a4f" style="height: 16px; width: 16px; font-size: 16px;">access_time</i>
                          <span class="timeRemaining_96d65">
                            <div class="timer_defb2">18h 54m 02s</div>
                          </span>
                        </div>
                      </div>
                      <div class="js--guru-link infobarContentRight_ac9bd"></div>
                    </div>
                </div>
              </div>
            </div>
            <div class="account-dialog"></div>
          </div>

          <div class="scroll">
            <div class="my-teams__body">
              <div class="my-teams__title">
              	<?php if($this->session->flashdata('success') !="")
              	{?>
              		<div class="alert alert-success">              			
					 <?php echo $this->session->flashdata('success'); ?>
					 </div>
					 <?php 
              	} ?>
              </div>

              <?php $i = 1; foreach ($teams as $team) {
                $where = array('my_team_id' =>$team['id'],'is_captain'=>'1');
                $where1 = array('my_team_id' =>$team['id'],'is_vicecaptain'=>'1');
                $table = 'my_team_player';
                $captainid = $this->Website_model->get_where($where,$table);
                $vicecaptainid = $this->Website_model->get_where($where1,$table);

                $where_captain = array('id' =>$captainid['player_id']);
                $where_vicecaptain = array('id' =>$vicecaptainid['player_id']);
                $tablename = 'players';
                $captain = $this->Website_model->get_where($where_captain,$tablename);
                $vicecaptain = $this->Website_model->get_where($where_vicecaptain,$tablename);


                ?>
                  <div class="my-teams">
                <div class="my-teams__team">
                  <div class="topSection_083bc">
                    <div>Team: <?php echo $i; ?></div>
                  </div>
                  <div>
                    <div class="my-teams__bottom-section bottomSection_d41f9">
                      <div class="my-teams__role-entity"><div>
                        <div class="my-teams__role-entity__title my-teams__role-entity--even">Captain</div>
                        <div class="my-teams__role-entity__player-name"><?php echo $captain['name']; ?></div>
                      </div>
                      </div>
                      <div class="my-teams__role-entity">
                        <div>
                          <div class="my-teams__role-entity__title my-teams__role-entity--odd">Vice Captain</div>
                          <div class="my-teams__role-entity__player-name"><?php echo $vicecaptain['name']; ?></div>
                        </div>
                      </div>
                      <div class="my-teams__role-entity">
                        <div>
                          <div style="float: right" class="my-teams__role-entity__title my-teams__role-entity--odd"><a style="text-decoration: none;" href="<?php echo base_url('website/join_contest/'.$team['id']); ?>">Join</a> </div>
                          <div class="my-teams__role-entity__player-name"></div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="buttonBar_09c83">
                    <a class="js--icon-edit resetButton_62ab8" href="<?php echo base_url('website/editteam/'.$team['id']); ?>">
                      <div class="primaryButtonAlign_02538">
                        <i class="materialIcon_10a4f" style="height: 14px; width: 14px; font-size: 14px;">edit</i>
                        <span class="iconContent_3cbfd">EDIT</span>
                      </div>
                    </a>
                      <div class="js--my-teams-team-preview-btn">
                        <button class="new-button resetButton_62ab8">
                          <div class="primaryButtonAlign_02538" onclick="team_view(<?php echo $team['id'];?>);">
                            <i class="materialIcon_10a4f" style="height: 14px; width: 14px; font-size: 14px;">remove_red_eye</i>
                            <span class="iconContent_3cbfd">PREVIEW</span>
                          </div>
                        </button>
                      </div>
                      <a class="js--icon-content_copy resetButton_62ab8" href="<?php echo base_url('website/cloneTeam/'.$team['id']); ?>"><div class="primaryButtonAlign_02538">
                        <i class="materialIcon_10a4f" style="height: 14px; width: 14px; font-size: 14px;">content_copy</i>
                        <span class="iconContent_3cbfd">CLONE</span>
                      </div>
                    </a>
                  </div>
                </div>
              </div>
                <?php 
             $i++; } ?>
              


              <div class="my-teams__footer footer_d9dd6">
             
                <a class="btn btn--raised btn--white" href="<?php echo base_url('website/create_team?match='.$match['match_id'].''); ?>">Create Team </a>
              </div>
            </div>
          </div>
        </div>
       <div id="team_preview"></div>
                          </div>
                          </div>
                        </div>
                        </div>
                          </div>
                          <div class="contest-joiner"></div>
                        </div>
                        </div>
                      </div>
                      </div>
                      </div>
                    </div>



  <!--   <script src="./teamlist_files/vendors_main-94f6173ba06a2c8ab3e4-chunktemp.js.download"></script><script src="./teamlist_files/main-16b8e4fad8086ea0f5a0-chunktemp.js.download"></script><script type="text/javascript" id="">var gsvMeta=document.createElement("meta");gsvMeta.httpEquiv="google-site-verification";gsvMeta.content="h6JUgqX9dMFO0C4E5VqUOBK7lb6vuDQOyebWaxUzBEc";document.getElementsByTagName("head")[0].appendChild(gsvMeta);</script>
 -->

    <!-- <script>!function(){var t=window.analytics=window.analytics||[];if(!t.initialize)if(t.invoked)window.console&&console.error&&console.error("Segment snippet included twice.");else{t.invoked=!0,t.methods="trackSubmit trackClick trackLink trackForm pageview identify reset group track ready alias debug page once off on".split(" "),t.factory=function(e){return function(){var n=Array.prototype.slice.call(arguments);return n.unshift(e),t.push(n),t}};for(var e=0;e<t.methods.length;e++){var n=t.methods[e];t[n]=t.factory(n)}t.load=function(t){var e=document.createElement("script");e.type="text/javascript",e.defer=!0,e.src=("https:"===document.location.protocol?"https://":"http://")+"cdn.segment.com/analytics.js/v1/"+t+"/analytics.min.js",t=document.getElementsByTagName("script")[0], window.addEventListener('load', function(event) {setTimeout(function(){t.parentNode.insertBefore(e,t)},1e3)})},t.SNIPPET_VERSION="4.0.0",t.load("0Kfjdo2cBx1jVR7FJF2CbpdsmA8AAB2V"),t.page()}}();</script>
    <script type="text/javascript">
       var clevertap = {event:[], profile:[], account:[], onUserLogin:[], notifications:[]};
       clevertap.account.push({"id": "W4R-49K-494Z"});
       (function () {
           var wzrk = document.createElement('script');
           wzrk.type = 'text/javascript';
           wzrk.defer = true;
           wzrk.src = ('https:' == document.location.protocol ? 'https://d2r1yp2w7bby2u.cloudfront.net' : 'http://static.clevertap.com') + '/js/a.js';
           var s = document.getElementsByTagName('script')[0];
           window.addEventListener('load', function(event) {setTimeout(function(){s.parentNode.insertBefore(wzrk, s)},1e3)})
        })();
      </script> -->
    
<noscript>
  <style>
    #app {
      display: none;
    }
    .noscript-header {
      height: 98px;
      background-color: #c51d23;
      display: flex;
      justify-content: center;
    }
    .logo {
      height: 48px;
      padding: 8px;
    }
    .noscript-message {
      color: #888;
      text-align: center;
      height: 400px;
      width: 80%;
      margin: 0 auto;
      display: flex;
      align-items: center;
      justify-content: center;
    }
    .noscript-container {
      max-width: 550px;
      height: 100%;
    }
    .app-bg {
      background-image: url('/public/imgs/desktop-pwa_2.jpg');
      position: fixed;
      left: 550px;
      right: 0;
      background-size: cover;
      top: 0;
      bottom: 0;
    }
  </style>  
</noscript>


<div id="fb-root" class=" fb_reset"><div style="position: absolute; top: -10000px; width: 0px; height: 0px;"><div><iframe name="fb_xdm_frame_https" frameborder="0" allowtransparency="true" allowfullscreen="true" scrolling="no" allow="encrypted-media" id="fb_xdm_frame_https" aria-hidden="true" title="Facebook Cross Domain Communication Frame" tabindex="-1" src="./teamlist_files/j-GHT1gpo6-.html" style="border: none;"></iframe></div><div></div></div></div><iframe src="./teamlist_files/start.html" style="display:none"></iframe>
<iframe id="ssIFrame_google" sandbox="allow-scripts allow-same-origin" aria-hidden="true" frame-border="0" src="./teamlist_files/iframe.html" style="position: absolute; width: 1px; height: 1px; left: -9999px; top: -9999px; right: -9999px; bottom: -9999px; display: none;"></iframe><iframe id="qualaroo_dnt_frame" src="./teamlist_files/frame.html" style="width: 1px; height: 1px; display: none; opacity: 0;"></iframe><script type="text/javascript" id="">var gsvMeta=document.createElement("meta");gsvMeta.httpEquiv="google-site-verification";gsvMeta.content="h6JUgqX9dMFO0C4E5VqUOBK7lb6vuDQOyebWaxUzBEc";document.getElementsByTagName("head")[0].appendChild(gsvMeta);</script>


</body></html>
 <script>
      countdown('demo',"<?php echo $match['match_date_time'] ?>");
        function countdown(element, mytime) {
    // Fetch the display element
    var el = document.getElementById(element);

    var countDownDate = new Date(mytime).getTime();

// Update the count down every 1 second
var x = setInterval(function() {

  // Get todays date and time
  var now = new Date().getTime();

  // Find the distance between now and the count down date
  var distance = countDownDate - now;

  // Time calculations for days, hours, minutes and seconds
  var days = Math.floor(distance / (1000 * 60 * 60 * 24));
  var hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
  var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
  var seconds = Math.floor((distance % (1000 * 60)) / 1000);

  // Display the result in the element with id="demo"
  document.getElementById(element).innerHTML = days + "d " + hours + "h "
  + minutes + "m " + seconds + "s ";

  // If the count down is finished, write some text 
  if (distance < 0) {
    clearInterval(x);
    document.getElementById(element).innerHTML = "EXPIRED";
  }
}, 1000);
}
      </script>

<script type="text/javascript">
  function team_view(id)
  {
    var id = id;
    $.ajax({
            type : 'post',       
            url: SITE_URL+'website/team_preview',
            data : { id : id},
            success : function(data) {
                   $('#team_preview').html(data);
              }
        });
  }
</script>

//