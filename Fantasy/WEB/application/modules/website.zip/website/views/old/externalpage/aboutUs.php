
 <style>

@media (max-width: 767px){
.tab-content h2 {
    font-size: 20px!important;
    margin: 50px 0!important;
    line-height: 30px;
    text-align:left;
}

  .tab-content p {
    font-size: 16px!important;
    line-height: 22px !important;
    margin-top: -16px;
    text-align: left;
}

.sec_container{
  

  padding:25px; 


}

}
</style>   


    <section class="banner">
      <div class="banner_tab_content">
       <!--  <div class="banner_box story tab-content active" id="d11-our-story">
          <img alt="story" class="desktop_banner" src="http://localhost/cricket_manager_web/web_assets/image/story.png ">
          <img alt="story" class="mobile_banner" src="./About Us - UAB League _ India_files/story_mobile.png">
        </div> -->
        <div class="banner_box leaders tab-content" id="d11-our-leaders">
         <!--  <img alt="leaders" class="desktop_banner" src="./About Us - UAB League _ India_files/leaders.png">
          <img alt="leaders" class="mobile_banner" src="./About Us - UAB League _ India_files/leaders_mobile.png"> -->
        </div>
        <div class="banner_box partners tab-content" id="d11-our-partners">
          <!-- <img alt="partners" class="desktop_banner" src="./About Us - UAB League _ India_files/partners.png">
          <img alt="partners" class="mobile_banner" src="./About Us - UAB League _ India_files/partners_mobile.png"> -->
        </div>
      </div>
    </section>
<section class="banner">
      <div class="banner_tab_content">
        <div class="banner_box story tab-content active" id="d11-our-story">
          <img alt="story" class="desktop_banner" src="<?php echo base_url('web_assets/image/story.png');?> ">
       <!--    <img alt="story" class="mobile_banner" src="./About Us - UAB League _ India_files/story_mobile.png">
        </div> -->
        <div class="banner_box leaders tab-content" id="d11-our-leaders">
         <!--  <img alt="leaders" class="desktop_banner" src="./About Us - UAB League _ India_files/leaders.png">
          <img alt="leaders" class="mobile_banner" src="./About Us - UAB League _ India_files/leaders_mobile.png"> -->
        </div>
        <div class="banner_box partners tab-content" id="d11-our-partners">
         <!--  <img alt="partners" class="desktop_banner" src="./About Us - UAB League _ India_files/partners.png">
          <img alt="partners" class="mobile_banner" src="./About Us - UAB League _ India_files/partners_mobile.png"> -->
        </div>
      </div>
    </section>
    <section>
      
      <div class="sec_container" style="max-width:1130px; text-align-last: left; margin-top:50px; margin-bottom: 50px;">
        <div class="tab-content current" id="our-story">
          <div class="story_content">
            <h2 margin="">THE JOURNEY</h2>
            <p>UAB League is India’s Biggest Sports Gaming platform with 4 crore+ users playing Fantasy Cricket. It is a Game of Skill that offers Indian sports fans a platform to showcase their sports knowledge. Fans can create their own team made up of real-life players from upcoming matches, score points based on their on-field performance and compete with other fans.</p>
            <br>
            <p>UAB League helps sports fans increase their engagement and connect deeper with the sport they love by being a team owner, not just a spectator. UAB League is also the Official Partner of the top sports leagues in the world such as the Hero CPL</p>
            <br>
            <p>A Series D funded startup, UAB League was founded in 2012 by Harsh Jain and Bhavit Sheth. Kalaari Capital, Think Investments, Multiples Equity &amp; Tencent are the marquee investors in UAB League.</p>
            <br>
          </div>
        </div>
      </div>
    </section>
   