
    	
    <div class="container-fluid">	
    <div class="main-bg-img" style="background-image: url('<?php echo base_url('design/img/background/main_bg_img.jpg') ?>')"></div>
    		<div class="col-sm-12 pzero">

    				<div class="row">	

    					<div class="col-sm-5 pzero	">

    						<div class="col-sm-12 pzero">

    							<div class="top-header sticky-top">

    								<div class="site-title">

    									

    								</div>	
    								<!--END-SITE-TITLE-->	

    								<div class="short-nav-bar">

    									<div class="row">

    									  <div class="col-sm-4 col-4"><a href="">FIXTURE</div>
		                    <div class="col-sm-4 col-4"><a href="">LIVE</a></div>
		                    <div class="col-sm-4 col-4"><a href="">RESULT</a></div>

    									</div>
    									<!--ROW=END-->	

    								</div>
    								<!--SHHORT-NAV-BAR-->	
    							</div>	
    							<!--HEADER-END-->


    							<div class="col-sm-12 pzero">
    									
    								<div class="match-list-slider">	

    									<div class="fixed-col">
    										
    										<div id="style-15" class="scroll-col style-15">
    										
    										 <!--MATCH-SLIDE-->		
    								         <div class="match-slide">

    								          <a href="contest.html">	
					                              <div class="col-sm-12 col-12 ">
					                                  <div class="row">
					                                    
					                                    <div class="col-sm-4 col-3">

					                                      <div class="img-container">
					                                          
					                                          <img src="https://cricket.entitysport.com/assets/uploads/2016/01/afghanistan.png">

					                                      </div>

					                                    </div>

					                                    <div class="col-sm-4 col-6">

					                                        <div class="col-12">

					                                          <div class="time" style="height:20px; font-size: 13px;">1d 19h 11m 37s </div>
					                                          <div class="IOD">OID</div>
					                                          <div class="vstext">AFG Vs IRE</div>
					                                        

					                                        </div> 
					                                    </div>

					                                    <div class="col-sm-4 col-3">

					                                      <div class="img-container">
					                                        
					                                        <img src="https://cricket.entitysport.com/assets/uploads/2016/01/afghanistan.png">

					                                      </div>

					                                    </div>

					                                  </div>


					                               </div> 
				                           </a>
				                           <!--LINK-END-->
				                           </div> 
				                           <!--MATCH-SLIDE-->

				                    	   <!--MATCH-SLIDE-->		
    								         <div class="match-slide">

    								          <a href="contest.html">	
					                              <div class="col-sm-12 col-12 ">
					                                  <div class="row">
					                                    
					                                    <div class="col-sm-4 col-3">

					                                      <div class="img-container">
					                                          
					                                          <img src="https://cricket.entitysport.com/assets/uploads/2016/01/afghanistan.png">

					                                      </div>

					                                    </div>

					                                    <div class="col-sm-4 col-6">

					                                        <div class="col-12">

					                                          <div class="time" style="height:20px; font-size: 13px;">1d 19h 11m 37s </div>
					                                          <div class="IOD">OID</div>
					                                          <div class="vstext">AFG Vs IRE</div>
					                                        

					                                        </div> 
					                                    </div>

					                                    <div class="col-sm-4 col-3">

					                                      <div class="img-container">
					                                        
					                                        <img src="https://cricket.entitysport.com/assets/uploads/2016/01/afghanistan.png">

					                                      </div>

					                                    </div>

					                                  </div>


					                               </div> 
				                           </a>
				                           <!--LINK-END-->
				                           </div> 
				                           <!--MATCH-SLIDE-->
				                           
				                           <!--MATCH-SLIDE-->		
    								         <div class="match-slide">

    								          <a href="contest.html">	
					                              <div class="col-sm-12 col-12 ">
					                                  <div class="row">
					                                    
					                                    <div class="col-sm-4 col-3">

					                                      <div class="img-container">
					                                          
					                                          <img src="https://cricket.entitysport.com/assets/uploads/2016/01/afghanistan.png">

					                                      </div>

					                                    </div>

					                                    <div class="col-sm-4 col-6">

					                                        <div class="col-12">

					                                          <div class="time" style="height:20px; font-size: 13px;">1d 19h 11m 37s </div>
					                                          <div class="IOD">OID</div>
					                                          <div class="vstext">AFG Vs IRE</div>
					                                        

					                                        </div> 
					                                    </div>

					                                    <div class="col-sm-4 col-3">

					                                      <div class="img-container">
					                                        
					                                        <img src="https://cricket.entitysport.com/assets/uploads/2016/01/afghanistan.png">

					                                      </div>

					                                    </div>

					                                  </div>


					                               </div> 
				                           </a>
				                           <!--LINK-END-->
				                           </div> 
				                           <!--MATCH-SLIDE-->
				                           
				                           
				                           <!--MATCH-SLIDE-->		
    								         <div class="match-slide">

    								          <a href="contest.html">	
					                              <div class="col-sm-12 col-12 ">
					                                  <div class="row">
					                                    
					                                    <div class="col-sm-4 col-3">

					                                      <div class="img-container">
					                                          
					                                          <img src="https://cricket.entitysport.com/assets/uploads/2016/01/afghanistan.png">

					                                      </div>

					                                    </div>

					                                    <div class="col-sm-4 col-6">

					                                        <div class="col-12">

					                                          <div class="time" style="height:20px; font-size: 13px;">1d 19h 11m 37s </div>
					                                          <div class="IOD">OID</div>
					                                          <div class="vstext">AFG Vs IRE</div>
					                                        

					                                        </div> 
					                                    </div>

					                                    <div class="col-sm-4 col-3">

					                                      <div class="img-container">
					                                        
					                                        <img src="https://cricket.entitysport.com/assets/uploads/2016/01/afghanistan.png">

					                                      </div>

					                                    </div>

					                                  </div>


					                               </div> 
				                           </a>
				                           <!--LINK-END-->
				                           </div> 
				                           <!--MATCH-SLIDE-->
				                           
				                           <!--MATCH-SLIDE-->		
    								         <div class="match-slide">

    								          <a href="contest.html">	
					                              <div class="col-sm-12 col-12 ">
					                                  <div class="row">
					                                    
					                                    <div class="col-sm-4 col-3">

					                                      <div class="img-container">
					                                          
					                                          <img src="https://cricket.entitysport.com/assets/uploads/2016/01/afghanistan.png">

					                                      </div>

					                                    </div>

					                                    <div class="col-sm-4 col-6">

					                                        <div class="col-12">

					                                          <div class="time" style="height:20px; font-size: 13px;">1d 19h 11m 37s </div>
					                                          <div class="IOD">OID</div>
					                                          <div class="vstext">AFG Vs IRE</div>
					                                        

					                                        </div> 
					                                    </div>

					                                    <div class="col-sm-4 col-3">

					                                      <div class="img-container">
					                                        
					                                        <img src="https://cricket.entitysport.com/assets/uploads/2016/01/afghanistan.png">

					                                      </div>

					                                    </div>

					                                  </div>


					                               </div> 
				                           </a>
				                           <!--LINK-END-->
				                           </div> 
				                           <!--MATCH-SLIDE-->
				                           
				                           <!--MATCH-SLIDE-->		
    								         <div class="match-slide">

    								          <a href="contest.html">	
					                              <div class="col-sm-12 col-12 ">
					                                  <div class="row">
					                                    
					                                    <div class="col-sm-4 col-3">

					                                      <div class="img-container">
					                                          
					                                          <img src="https://cricket.entitysport.com/assets/uploads/2016/01/afghanistan.png">

					                                      </div>

					                                    </div>

					                                    <div class="col-sm-4 col-6">

					                                        <div class="col-12">

					                                          <div class="time" style="height:20px; font-size: 13px;">1d 19h 11m 37s </div>
					                                          <div class="IOD">OID</div>
					                                          <div class="vstext">AFG Vs IRE</div>
					                                        

					                                        </div> 
					                                    </div>

					                                    <div class="col-sm-4 col-3">

					                                      <div class="img-container">
					                                        
					                                        <img src="https://cricket.entitysport.com/assets/uploads/2016/01/afghanistan.png">

					                                      </div>

					                                    </div>

					                                  </div>


					                               </div> 
				                           </a>
				                           <!--LINK-END-->
				                           </div> 
				                           <!--MATCH-SLIDE-->
				                           
				                           
				                           <!--MATCH-SLIDE-->		
    								         <div class="match-slide">

    								          <a href="contest.html">	
					                              <div class="col-sm-12 col-12 ">
					                                  <div class="row">
					                                    
					                                    <div class="col-sm-4 col-3">

					                                      <div class="img-container">
					                                          
					                                          <img src="https://cricket.entitysport.com/assets/uploads/2016/01/afghanistan.png">

					                                      </div>

					                                    </div>

					                                    <div class="col-sm-4 col-6">

					                                        <div class="col-12">

					                                          <div class="time" style="height:20px; font-size: 13px;">1d 19h 11m 37s </div>
					                                          <div class="IOD">OID</div>
					                                          <div class="vstext">AFG Vs IRE</div>
					                                        

					                                        </div> 
					                                    </div>

					                                    <div class="col-sm-4 col-3">

					                                      <div class="img-container">
					                                        
					                                        <img src="https://cricket.entitysport.com/assets/uploads/2016/01/afghanistan.png">

					                                      </div>

					                                    </div>

					                                  </div>


					                               </div> 
				                           </a>
				                           <!--LINK-END-->
				                           </div> 
				                           <!--MATCH-SLIDE-->
				                           
				                           <!--MATCH-SLIDE-->		
    								         <div class="match-slide">

    								          <a href="contest.html">	
					                              <div class="col-sm-12 col-12 ">
					                                  <div class="row">
					                                    
					                                    <div class="col-sm-4 col-3">

					                                      <div class="img-container">
					                                          
					                                          <img src="https://cricket.entitysport.com/assets/uploads/2016/01/afghanistan.png">

					                                      </div>

					                                    </div>

					                                    <div class="col-sm-4 col-6">

					                                        <div class="col-12">

					                                          <div class="time" style="height:20px; font-size: 13px;">1d 19h 11m 37s </div>
					                                          <div class="IOD">OID</div>
					                                          <div class="vstext">AFG Vs IRE</div>
					                                        

					                                        </div> 
					                                    </div>

					                                    <div class="col-sm-4 col-3">

					                                      <div class="img-container">
					                                        
					                                        <img src="https://cricket.entitysport.com/assets/uploads/2016/01/afghanistan.png">

					                                      </div>

					                                    </div>

					                                  </div>


					                               </div> 
				                           </a>
				                           <!--LINK-END-->
				                           </div> 
				                           <!--MATCH-SLIDE-->
				                           
				                           
				                           <!--MATCH-SLIDE-->		
    								         <div class="match-slide">

    								          <a href="contest.html">	
					                              <div class="col-sm-12 col-12 ">
					                                  <div class="row">
					                                    
					                                    <div class="col-sm-4 col-3">

					                                      <div class="img-container">
					                                          
					                                          <img src="https://cricket.entitysport.com/assets/uploads/2016/01/afghanistan.png">

					                                      </div>

					                                    </div>

					                                    <div class="col-sm-4 col-6">

					                                        <div class="col-12">

					                                          <div class="time" style="height:20px; font-size: 13px;">1d 19h 11m 37s </div>
					                                          <div class="IOD">OID</div>
					                                          <div class="vstext">AFG Vs IRE</div>
					                                        

					                                        </div> 
					                                    </div>

					                                    <div class="col-sm-4 col-3">

					                                      <div class="img-container">
					                                        
					                                        <img src="https://cricket.entitysport.com/assets/uploads/2016/01/afghanistan.png">

					                                      </div>

					                                    </div>

					                                  </div>


					                               </div> 
				                           </a>
				                           <!--LINK-END-->
				                           </div> 
				                           <!--MATCH-SLIDE-->
				                           
				                           <!--MATCH-SLIDE-->		
    								         <div class="match-slide">

    								          <a href="contest.html">	
					                              <div class="col-sm-12 col-12 ">
					                                  <div class="row">
					                                    
					                                    <div class="col-sm-4 col-3">

					                                      <div class="img-container">
					                                          
					                                          <img src="https://cricket.entitysport.com/assets/uploads/2016/01/afghanistan.png">

					                                      </div>

					                                    </div>

					                                    <div class="col-sm-4 col-6">

					                                        <div class="col-12">

					                                          <div class="time" style="height:20px; font-size: 13px;">1d 19h 11m 37s </div>
					                                          <div class="IOD">OID</div>
					                                          <div class="vstext">AFG Vs IRE</div>
					                                        

					                                        </div> 
					                                    </div>

					                                    <div class="col-sm-4 col-3">

					                                      <div class="img-container">
					                                        
					                                        <img src="https://cricket.entitysport.com/assets/uploads/2016/01/afghanistan.png">

					                                      </div>

					                                    </div>

					                                  </div>


					                               </div> 
				                           </a>
				                           <!--LINK-END-->
				                           </div> 
				                           <!--MATCH-SLIDE-->
				                           
				                           
				                           
				                           
				                           
    										</div>
    										<!--SCROLL-COL-->



    											
    									</div>
    									<!--FIXED-COL-->	
    								</div>
    								<!--MATCH-LIST-SLIDER-END-->	
    							</div>
    							<!--COL-SM-12-END-->
    						</div>
    						<!--COL-SM-12-->	

    						<div class="col-sm-12 pzero">

    							<!--BOTTOM-BAR-NAV-START-->
	    						<div class="bottom-nav-bar">
	    							
	    							<a  href="lug.html"> 

	    								<div class="bottom-menu-item ">
	    									<div class="icon-container">
	    										
	    										<i class="fas fa-home"></i>

	    									</div>
	    									<!--ICON-CONTAINER-->
	    									<div class="menu-nam">
	    										
	    										<span>Home</span>

	    									</div>
	    									<!--ICON-CONTAINER-->
	    								</div>
	    								<!--BOTTOM-MENU-ITEEM-->	
	    							</a>
	    							<!--NAV-ITEM-END-->


	    							<a  href="http://getexploremore.com/m/c/login.html"> 

	    								<div class="bottom-menu-item">
	    									<div class="icon-container">
	    										
	    										<i class="fas fa-star"></i>

	    									</div>
	    									<!--ICON-CONTAINER-->
	    									<div class="menu-nam">
	    										
	    										<span>MATCH</span>

	    									</div>
	    									<!--ICON-CONTAINER-->
	    								</div>
	    								<!--BOTTOM-MENU-ITEEM-->	
	    							</a>
	    							<!--NAV-ITEM-END-->


	    							<a  href="register.html"> 

	    								<div class="bottom-menu-item">
	    									<div class="icon-container">
	    										
	    										<i class="fas fa-home"></i>

	    									</div>
	    									<!--ICON-CONTAINER-->
	    									<div class="menu-nam">
	    										
	    										<span>ME</span>

	    									</div>
	    									<!--ICON-CONTAINER-->
	    								</div>
	    								<!--BOTTOM-MENU-ITEEM-->	
	    							</a>
	    							<!--NAV-ITEM-END-->

	    							<a  href="OTP.html"> 

	    								<div class="bottom-menu-item">
	    									<div class="icon-container">
	    										
	    										<i class="fas fa-home"></i>

	    									</div>
	    									<!--ICON-CONTAINER-->
	    									<div class="menu-nam">
	    										
	    										<span>MORE</span>

	    									</div>
	    									<!--ICON-CONTAINER-->
	    								</div>
	    								<!--BOTTOM-MENU-ITEEM-->	
	    							</a>
	    							<!--NAV-ITEM-END-->



	    						</div>
	    						<!--BOTTOM-BAR-NAV-END-->

    						</div>	
    						<!--COL-SM-12-END-->
    					<div>
    					<!--COL-SM-5-END-->	
    						
    					<div class="col-sm-7">
    						

    					</div>	
    					<!--COL-SM-7-END-->	
    						
    				</div>
    				<!--ROW-END-->	
    		</div>
    		<!--END-COL-SM-12-->	
    </div>	
    <!--BODY-CONTAINER-FLUID-END--> 

 